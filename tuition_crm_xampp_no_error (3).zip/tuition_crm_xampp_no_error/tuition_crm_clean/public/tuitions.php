<?php
// public/tuitions.php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$q = trim((string)($_GET['q'] ?? ''));

if ($q !== '') {
  $stmt = db()->prepare("
    SELECT 
      t.*,
      s.name AS student_name,
      te.name AS teacher_name
    FROM tuitions t
    JOIN students s ON s.id = t.student_id
    JOIN teachers te ON te.id = t.teacher_id
    WHERE s.name LIKE ? OR te.name LIKE ? OR t.status LIKE ?
    ORDER BY t.id DESC
  ");
  $like = "%{$q}%";
  $stmt->execute([$like, $like, $like]);
  $rows = $stmt->fetchAll();
} else {
  $rows = db()->query("
    SELECT 
      t.*,
      s.name AS student_name,
      te.name AS teacher_name
    FROM tuitions t
    JOIN students s ON s.id = t.student_id
    JOIN teachers te ON te.id = t.teacher_id
    ORDER BY t.id DESC
  ")->fetchAll();
}

$pageTitle = 'Tuitions';
require __DIR__ . '/_layout_top.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h2 class="mb-0">Tuitions</h2>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-light" href="<?= e(url('dashboard.php')) ?>">Dashboard</a>
    <a class="btn btn-success" href="<?= e(url('tuition_form.php')) ?>">+ Add Tuition</a>
  </div>
</div>

<form class="row g-2 mb-3" method="get" action="<?= e(url('tuitions.php')) ?>">
  <div class="col-md-10">
    <input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Search by student, teacher, status">
  </div>
  <div class="col-md-2 d-grid">
    <button class="btn btn-primary" type="submit">Search</button>
  </div>
</form>

<div class="card p-3">
  <div class="table-responsive">
    <table class="table table-dark table-hover align-middle">
      <thead>
        <tr>
          <th>ID</th>
          <th>Date</th>
          <th>Student</th>
          <th>Teacher</th>
          <th>Monthly Fee</th>
          <th>Company %</th>
          <th>Company Amount</th>
          <th>Paid</th>
          <th>Pending</th>
          <th>Status</th>
          <th style="width:190px;">Actions</th>
        </tr>
      </thead>

      <tbody>
        <?php if (!$rows): ?>
          <tr>
            <td colspan="11" class="text-center text-secondary">No records</td>
          </tr>
        <?php else: ?>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td><?= e((string)$r['id']) ?></td>
              <td><?= e((string)$r['tuition_date']) ?></td>
              <td><?= e((string)$r['student_name']) ?></td>
              <td><?= e((string)$r['teacher_name']) ?></td>
              <td><?= e((string)$r['monthly_fee']) ?></td>
              <td><?= e((string)$r['company_share_percent']) ?>%</td>
              <td><?= e((string)$r['company_share_amount']) ?></td>
              <td><?= e((string)$r['paid_to_company']) ?></td>
              <td><?= e((string)$r['pending_to_company']) ?></td>
              <td>
                <span class="badge bg-<?= 
                  $r['status']==='Paid'?'success':($r['status']==='Partial'?'warning':'secondary') ?>">
                  <?= e($r['status']) ?>
                </span>
              </td>

              <td>
                <a class="btn btn-sm btn-warning"
                   href="<?= e(url('tuition_form.php?id=' . (int)$r['id'])) ?>">
                  Edit
                </a>

                <form class="d-inline"
                      method="post"
                      action="<?= e(url('actions/tuitions/delete.php')) ?>"
                      onsubmit="return confirm('Delete this tuition?')">
                  <?= csrf_field() ?>
                  <input type="hidden" name="id" value="<?= e((string)$r['id']) ?>">
                  <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/_layout_bottom.php'; ?>
