<?php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$q = trim((string)($_GET['q'] ?? ''));

if ($q !== '') {
  $stmt = db()->prepare("SELECT * FROM students WHERE name LIKE ? OR reg_no LIKE ? OR city LIKE ? ORDER BY id DESC");
  $like = "%$q%";
  $stmt->execute([$like, $like, $like]);
  $rows = $stmt->fetchAll();
} else {
  $rows = db()->query("SELECT * FROM students ORDER BY id DESC")->fetchAll();
}

$pageTitle = 'Students';
require __DIR__ . '/_layout_top.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h2 class="mb-0">Students</h2>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-light" href="<?= e(url('dashboard.php')) ?>">Dashboard</a>
    <a class="btn btn-success" href="<?= e(url('student_form.php')) ?>">+ Add Student</a>
  </div>
</div>

<form class="row g-2 mb-3" method="get">
  <div class="col-md-10">
    <input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Search by name, reg no, city">
  </div>
  <div class="col-md-2 d-grid">
    <button class="btn btn-primary">Search</button>
  </div>
</form>

<div class="card p-3">
  <div class="table-responsive">
    <table class="table table-dark table-hover align-middle">
      <thead>
        <tr>
          <th>ID</th>
          <th>Date</th>
          <th>Reg No</th>
          <th>Name</th>
          <th>Phone</th>
          <th>City</th>
          <th>Home -Address</th>
          <th>Class</th>
          <th>Mode</th>
          <th style="width:180px;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= e((string)$r['id']) ?></td>
            <td><?= e((string)$r['record_date']) ?></td>
            <td><?= e((string)($r['reg_no'] ?? '')) ?></td>
            <td><?= e((string)$r['name']) ?></td>
            <td><?= e((string)($r['phoneno'] ?? '')) ?></td>
            <td><?= e((string)$r['city']) ?></td>
            <td><?= e((string)$r['home_address']) ?></td>
            <td><?= e((string)$r['class']) ?></td>
            <td><?= e((string)$r['mode']) ?></td>
            <td>
              <a class="btn btn-sm btn-warning" href="<?= e(url('student_form.php?id='.(int)$r['id'])) ?>">Edit</a>
              <form class="d-inline" method="post" action="<?= e(url('actions/students/delete.php')) ?>" onsubmit="return confirm('Delete this student?')">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= e((string)$r['id']) ?>">
                <button class="btn btn-sm btn-danger">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?>
          <tr><td colspan="9" class="text-center text-secondary">No records</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/_layout_bottom.php'; ?>
