<?php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$id = (int)($_GET['id'] ?? 0);
$row = null;

if ($id) {
  $stmt = db()->prepare("SELECT * FROM teachers WHERE id=?");
  $stmt->execute([$id]);
  $row = $stmt->fetch();
  if (!$row) { flash_set('danger','Teacher not found.'); redirect('teachers.php'); }
}

$pageTitle = $id ? 'Edit Teacher' : 'Add Teacher';
require __DIR__ . '/_layout_top.php';

function v($key, $default='') {
  global $row;
  return $row[$key] ?? $default;
}
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h2 class="mb-0"><?= e($pageTitle) ?></h2>
  <a class="btn btn-outline-light" href="<?= e(url('teachers.php')) ?>">Back</a>
</div>

<div class="card p-4">
  <form method="post" enctype="multipart/form-data"
        action="<?= e(url($id ? 'actions/teachers/update.php' : 'actions/teachers/create.php')) ?>">
    <?= csrf_field() ?>
    <?php if ($id): ?><input type="hidden" name="id" value="<?= e((string)$id) ?>"><?php endif; ?>

    <div class="row g-3">
      <div class="col-md-3">
        <label class="form-label">Record Date</label>
        <input class="form-control" type="date" name="record_date" value="<?= e((string)v('record_date', date('Y-m-d'))) ?>" required>
      </div>
      <div class="col-md-3">
        <label class="form-label">Reg No</label>
        <input class="form-control" name="reg_no" value="<?= e((string)v('reg_no','')) ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Name</label>
        <input class="form-control" name="name" value="<?= e((string)v('name','')) ?>" required>
      </div>

      <div class="col-md-4">
        <label class="form-label">Phone</label>
        <input class="form-control" name="phoneno" value="<?= e((string)v('phoneno','')) ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Email</label>
        <input class="form-control" name="email" value="<?= e((string)v('email','')) ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Qualification</label>
        <input class="form-control" name="qualification" value="<?= e((string)v('qualification','')) ?>">
      </div>

      <div class="col-md-3">
        <label class="form-label">Experience Years</label>
        <input class="form-control" type="number" min="0" max="60" name="experience_years" value="<?= e((string)v('experience_years','')) ?>">
      </div>
      <div class="col-md-9">
        <label class="form-label">Subjects</label>
        <input class="form-control" name="subjects" value="<?= e((string)v('subjects','')) ?>" required>
      </div>

      <div class="col-md-6">
        <label class="form-label">City</label>
        <input class="form-control" name="city" value="<?= e((string)v('city','')) ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Home Address</label>
        <input class="form-control" name="home_address" value="<?= e((string)v('home_address','')) ?>">
      </div>

      <div class="col-md-4">
        <label class="form-label">Fee Range</label>
        <input class="form-control" name="fee_range" value="<?= e((string)v('fee_range','')) ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Availability</label>
        <input class="form-control" name="availability" value="<?= e((string)v('availability','')) ?>">
      </div>

      <div class="col-md-2">
        <label class="form-label">Mode</label>
        <select class="form-select" name="mode" required>
          <?php $m = (string)v('mode','online'); ?>
          <option value="online" <?= $m==='online'?'selected':'' ?>>Online</option>
          <option value="home" <?= $m==='home'?'selected':'' ?>>Home</option>
        </select>
      </div>

      <div class="col-md-2">
        <label class="form-label">Device</label>
        <select class="form-select" name="device" required>
          <?php $d = (string)v('device','laptop'); ?>
          <option value="laptop" <?= $d==='laptop'?'selected':'' ?>>Laptop</option>
          <option value="mobile" <?= $d==='mobile'?'selected':'' ?>>Mobile</option>
        </select>
      </div>

      <div class="col-md-6">
        <label class="form-label">Teacher ID Card (png, jpg, pdf)</label>
        <input class="form-control" type="file" name="teacher_id">
        <?php if (!empty($row['teacher_id_file'])): ?>
          <div class="mt-2 small text-secondary">Existing: <?= e((string)$row['teacher_id_file']) ?></div>
        <?php endif; ?>
      </div>

      <div class="col-md-6">
        <label class="form-label">Teacher Document (pdf, doc, docx)</label>
        <input class="form-control" type="file" name="teacher_doc">
        <?php if (!empty($row['teacher_doc_file'])): ?>
          <div class="mt-2 small text-secondary">Existing: <?= e((string)$row['teacher_doc_file']) ?></div>
        <?php endif; ?>
      </div>
    </div>

    <div class="mt-4">
      <button class="btn btn-primary"><?= $id ? 'Update' : 'Create' ?></button>
    </div>
  </form>
</div>
<?php require __DIR__ . '/_layout_bottom.php'; ?>
