<?php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$id = (int)($_GET['id'] ?? 0);
$row = null;

if ($id) {
  $stmt = db()->prepare("SELECT * FROM students WHERE id=?");
  $stmt->execute([$id]);
  $row = $stmt->fetch();
  if (!$row) { flash_set('danger','Student not found.'); redirect('students.php'); }
}

$pageTitle = $id ? 'Edit Student' : 'Add Student';
require __DIR__ . '/_layout_top.php';

function v($key, $default='') {
  global $row;
  return $row[$key] ?? $default;
}
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h2 class="mb-0"><?= e($pageTitle) ?></h2>
  <a class="btn btn-outline-light" href="<?= e(url('students.php')) ?>">Back</a>
</div>

<div class="card p-4">
  <form method="post" action="<?= e(url($id ? 'actions/students/update.php' : 'actions/students/create.php')) ?>">
    <?= csrf_field() ?>
    <?php if ($id): ?><input type="hidden" name="id" value="<?= e((string)$id) ?>"><?php endif; ?>

    <div class="row g-3">
      <div class="col-md-3">
        <label class="form-label">Record Date</label>
        <input class="form-control" type="date" name="record_date" value="<?= e((string)v('record_date', date('Y-m-d'))) ?>" required>
      </div>
      <div class="col-md-3">
        <label class="form-label">Reg No</label>
        <input class="form-control" name="reg_no" value="<?= e((string)v('reg_no','')) ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Name</label>
        <input class="form-control" name="name" value="<?= e((string)v('name','')) ?>" required>
      </div>

      <div class="col-md-4">
        <label class="form-label">Phone</label>
        <input class="form-control" name="phoneno" value="<?= e((string)v('phoneno','')) ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">School</label>
        <input class="form-control" name="school_name" value="<?= e((string)v('school_name','')) ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Class</label>
        <input class="form-control" name="class" value="<?= e((string)v('class','')) ?>" required>
      </div>

      <div class="col-md-6">
        <label class="form-label">Subjects</label>
        <input class="form-control" name="subjects" value="<?= e((string)v('subjects','')) ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">City</label>
        <input class="form-control" name="city" value="<?= e((string)v('city','')) ?>" required>
      </div>

      <div class="col-md-12">
        <label class="form-label">Home Address</label>
        <input class="form-control" name="home_address" value="<?= e((string)v('home_address','')) ?>">
      </div>

      <div class="col-md-4">
        <label class="form-label">Fee Range</label>
        <input class="form-control" name="fee_range" value="<?= e((string)v('fee_range','')) ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Location</label>
        <input class="form-control" name="location" value="<?= e((string)v('location','')) ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Location Link</label>
        <input class="form-control" name="location_link" value="<?= e((string)v('location_link','')) ?>">
      </div>

      <div class="col-md-6">
        <label class="form-label">Mode</label>
        <select class="form-select" name="mode" required>
          <?php $m = (string)v('mode','online'); ?>
          <option value="online" <?= $m==='online'?'selected':'' ?>>Online</option>
          <option value="home" <?= $m==='home'?'selected':'' ?>>Home</option>
        </select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Device</label>
        <select class="form-select" name="device" required>
          <?php $d = (string)v('device','laptop'); ?>
          <option value="laptop" <?= $d==='laptop'?'selected':'' ?>>Laptop</option>
          <option value="mobile" <?= $d==='mobile'?'selected':'' ?>>Mobile</option>
        </select>
      </div>
    </div>

    <div class="mt-4">
      <button class="btn btn-primary"><?= $id ? 'Update' : 'Create' ?></button>
    </div>
  </form>
</div>
<?php require __DIR__ . '/_layout_bottom.php'; ?>
