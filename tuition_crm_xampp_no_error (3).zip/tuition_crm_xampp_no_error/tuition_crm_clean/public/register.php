
<?php
// ========================================
// FILE: /public/register.php (NEW FILE)
// ========================================
require_once __DIR__ . '/../app/bootstrap.php';

auth_start_session();
if (auth_user()) {
    redirect('dashboard.php');
}

$pageTitle = 'Register';
require __DIR__ . '/_layout_top.php';
?>
<div class="row justify-content-center">
  <div class="col-md-7 col-lg-6">
    <div class="card p-3">
      <div class="p-3">
        <h2 class="mb-3">Register</h2>

        <form method="post" action="<?= e(url('actions/auth/register_post.php')) ?>">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label class="form-label">Name</label>
            <input class="form-control" name="name" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Email</label>
            <input class="form-control" type="email" name="email" required autocomplete="username">
          </div>

          <div class="mb-3">
            <label class="form-label">Password</label>
            <input class="form-control" type="password" name="password" required minlength="6" autocomplete="new-password">
          </div>

          <div class="mb-3">
            <label class="form-label">Confirm Password</label>
            <input class="form-control" type="password" name="password2" required minlength="6" autocomplete="new-password">
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-success">Create Account</button>
            <a class="btn btn-outline-light" href="<?= e(url('login.php')) ?>">Back to Login</a>
          </div>
        </form>

        <div class="text-secondary small mt-3">
          Note: First registered user becomes <b>admin</b> automatically.
        </div>
      </div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/_layout_bottom.php'; ?>
