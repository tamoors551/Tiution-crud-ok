<?php
// C:\Xampp-3\htdocs\tuition_crm_xampp_no_error\tuition_crm_clean\public\tuitions
require_once __DIR__ . '/../../app/bootstrap.php';
require_auth();
csrf_verify();

$monthly = (int)$_POST['monthly_fee'];
$percent = (int)$_POST['company_share_percent'];
$paid    = (int)$_POST['paid_to_company'];

$company_amount = (int) round($monthly * $percent / 100);
$pending = max(0, $company_amount - $paid);

$status = $paid <= 0 ? 'Pending' : ($paid >= $company_amount ? 'Paid' : 'Partial');

$stmt = db()->prepare("
INSERT INTO tuitions
(tuition_date, student_id, teacher_id, monthly_fee,
 company_share_percent, company_share_amount,
 paid_to_company, pending_to_company, status, notes)
VALUES (?,?,?,?,?,?,?,?,?,?)
");

$stmt->execute([
  $_POST['tuition_date'],
  $_POST['student_id'],
  $_POST['teacher_id'],
  $monthly,
  $percent,
  $company_amount,
  $paid,
  $pending,
  $status,
  $_POST['notes'] ?: null
]);

flash_set('success','Tuition added');
redirect(url('tuitions.php'));
