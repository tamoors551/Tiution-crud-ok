<?php
require_once __DIR__ . '/../../app/bootstrap.php';
require_auth();
csrf_verify();

$monthly = (int)$_POST['monthly_fee'];
$percent = (int)$_POST['company_share_percent'];
$paid    = (int)$_POST['paid_to_company'];

$company_amount = (int) round($monthly * $percent / 100);
$pending = max(0, $company_amount - $paid);

$status = $paid <= 0 ? 'Pending' : ($paid >= $company_amount ? 'Paid' : 'Partial');

$stmt = db()->prepare("
UPDATE tuitions SET
tuition_date=?, student_id=?, teacher_id=?,
monthly_fee=?, company_share_percent=?, company_share_amount=?,
paid_to_company=?, pending_to_company=?, status=?, notes=?
WHERE id=?
");

$stmt->execute([
  $_POST['tuition_date'],
  $_POST['student_id'],
  $_POST['teacher_id'],
  $monthly,
  $percent,
  $company_amount,
  $paid,
  $pending,
  $status,
  $_POST['notes'] ?: null,
  $_POST['id']
]);

flash_set('success','Tuition updated');
redirect(url('tuitions.php'));
