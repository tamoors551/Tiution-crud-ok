<?php
// "C:\Xampp-3\htdocs\tuition_crm_xampp_no_error\tuition_crm_clean\public\tuition_form.php"
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$id = (int)($_GET['id'] ?? 0);
$isEdit = $id > 0;

$students = db()->query("SELECT id, name FROM students ORDER BY name")->fetchAll();
$teachers = db()->query("SELECT id, name FROM teachers ORDER BY name")->fetchAll();

$data = [
  'tuition_date' => date('Y-m-d'),
  'student_id' => '',
  'teacher_id' => '',
  'monthly_fee' => '',
  'company_share_percent' => '',
  'paid_to_company' => '',
  'status' => 'Pending',
  'notes' => ''
];

if ($isEdit) {
  $stmt = db()->prepare("SELECT * FROM tuitions WHERE id = ?");
  $stmt->execute([$id]);
  $data = $stmt->fetch() ?: $data;
}

$pageTitle = $isEdit ? 'Edit Tuition' : 'Add Tuition';
require __DIR__ . '/_layout_top.php';
?>

<h2 class="mb-3"><?= e($pageTitle) ?></h2>

<div class="card p-3">
<form method="post" action="<?= e(url($isEdit ? 'tuitions/update.php' : 'tuitions/create.php')) ?>">
<?= csrf_field() ?>
<?php if ($isEdit): ?><input type="hidden" name="id" value="<?= e($id) ?>"><?php endif; ?>

<div class="row g-3">
  <div class="col-md-3">
    <label class="form-label">Date</label>
    <input type="date" name="tuition_date" class="form-control" required value="<?= e($data['tuition_date']) ?>">
  </div>

  <div class="col-md-3">
    <label class="form-label">Student</label>
    <select name="student_id" class="form-select" required>
      <option value="">Select</option>
      <?php foreach ($students as $s): ?>
        <option value="<?= $s['id'] ?>" <?= $s['id']==$data['student_id']?'selected':'' ?>>
          <?= e($s['name']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="col-md-3">
    <label class="form-label">Teacher</label>
    <select name="teacher_id" class="form-select" required>
      <option value="">Select</option>
      <?php foreach ($teachers as $t): ?>
        <option value="<?= $t['id'] ?>" <?= $t['id']==$data['teacher_id']?'selected':'' ?>>
          <?= e($t['name']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="col-md-3">
    <label class="form-label">Monthly Fee</label>
    <input type="number" name="monthly_fee" class="form-control" required value="<?= e($data['monthly_fee']) ?>">
  </div>

  <div class="col-md-3">
    <label class="form-label">Company Share %</label>
    <input type="number" name="company_share_percent" class="form-control" required value="<?= e($data['company_share_percent']) ?>">
  </div>

  <div class="col-md-3">
    <label class="form-label">Paid to Company</label>
    <input type="number" name="paid_to_company" class="form-control" required value="<?= e($data['paid_to_company']) ?>">
  </div>

  <div class="col-md-3">
    <label class="form-label">Status</label>
    <select name="status" class="form-select">
      <?php foreach (['Pending','Partial','Paid'] as $st): ?>
        <option <?= $data['status']===$st?'selected':'' ?>><?= $st ?></option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="col-12">
    <label class="form-label">Notes</label>
    <textarea name="notes" class="form-control"><?= e($data['notes']) ?></textarea>
  </div>
</div>

<button class="btn btn-primary mt-3"><?= $isEdit?'Update':'Save' ?></button>
<a class="btn btn-outline-light mt-3" href="<?= e(url('tuitions.php')) ?>">Cancel</a>
</form>
</div>

<?php require __DIR__ . '/_layout_bottom.php'; ?>
