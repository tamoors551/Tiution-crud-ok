<?php

// ========================================
// FILE: /public/actions/auth/logout_post.php (REPLACE FILE)
// ========================================
require_once __DIR__ . '/../../../app/bootstrap.php';

auth_start_session();
csrf_verify();

auth_logout();
flash_set('success', 'Logged out.');
redirect('login.php');

