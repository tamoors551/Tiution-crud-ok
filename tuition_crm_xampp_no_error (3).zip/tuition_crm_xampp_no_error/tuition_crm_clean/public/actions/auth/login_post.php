<?php

// ========================================
// FILE: /public/actions/auth/login_post.php (REPLACE FILE)
// ========================================
/*
POST: email, password
*/
require_once __DIR__ . '/../../../app/bootstrap.php';

auth_start_session();
csrf_verify();

$email = trim((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');

if ($email === '' || $password === '') {
    flash_set('danger', 'Email and password are required.');
    redirect('login.php');
}

$stmt = db()->prepare("SELECT id, password_hash FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row || !auth_password_verify($password, (string)$row['password_hash'])) {
    flash_set('danger', 'Invalid email or password.');
    redirect('login.php');
}

auth_login((int)$row['id']);
flash_set('success', 'Logged in successfully.');
redirect('dashboard.php');
