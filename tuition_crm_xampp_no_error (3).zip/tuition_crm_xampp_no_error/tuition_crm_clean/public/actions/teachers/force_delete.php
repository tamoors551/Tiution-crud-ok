<?php
require_once __DIR__ . '/../../app/bootstrap.php';
require_auth();

$user = auth_user();
if (($user['role'] ?? '') !== 'admin') {
  flash_set('error', 'Permission denied.');
  redirect('teachers_trash.php');
  exit;
}

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
  flash_set('error', 'Invalid teacher ID.');
  redirect('teachers_trash.php');
  exit;
}

/* Block if linked tuitions exist */
$cnt = db()->prepare("SELECT COUNT(*) FROM tuitions WHERE teacher_id=?");
$cnt->execute([$id]);
if ($cnt->fetchColumn() > 0) {
  flash_set('error', 'Cannot permanently delete. Linked tuitions exist.');
  redirect('teachers_trash.php');
  exit;
}

db()->prepare("DELETE FROM teachers WHERE id=?")->execute([$id]);
flash_set('success', 'Teacher permanently deleted.');
redirect('teachers_trash.php');
