<?php
require_once __DIR__ . '/../../../app/bootstrap.php';
require_auth();
csrf_verify();

try {
  $idFile = store_upload('teacher_id', 'teacher_id', ['png','jpg','jpeg','pdf']);
  $docFile = store_upload('teacher_doc', 'teacher_docs', ['pdf','doc','docx']);
} catch (Throwable $e) {
  flash_set('danger', $e->getMessage());
  redirect('teacher_form.php');
}

$data = [
  'record_date' => $_POST['record_date'] ?? '',
  'reg_no' => $_POST['reg_no'] ?? null,
  'name' => $_POST['name'] ?? '',
  'phoneno' => $_POST['phoneno'] ?? null,
  'email' => $_POST['email'] ?? null,
  'qualification' => $_POST['qualification'] ?? null,
  'experience_years' => ($_POST['experience_years'] ?? '') !== '' ? (int)$_POST['experience_years'] : null,
  'subjects' => $_POST['subjects'] ?? '',
  'city' => $_POST['city'] ?? '',
  'home_address' => $_POST['home_address'] ?? null,
  'fee_range' => $_POST['fee_range'] ?? null,
  'availability' => $_POST['availability'] ?? null,
  'mode' => $_POST['mode'] ?? 'online',
  'device' => $_POST['device'] ?? 'laptop',
  'teacher_id_file' => $idFile,
  'teacher_doc_file' => $docFile,
];

$stmt = db()->prepare("
  INSERT INTO teachers
  (record_date, reg_no, name, phoneno, email, qualification, experience_years, subjects, city, home_address, fee_range, availability, mode, device, teacher_id_file, teacher_doc_file)
  VALUES
  (:record_date, :reg_no, :name, :phoneno, :email, :qualification, :experience_years, :subjects, :city, :home_address, :fee_range, :availability, :mode, :device, :teacher_id_file, :teacher_doc_file)
");
$stmt->execute($data);

flash_set('success', 'Teacher created.');
redirect('teachers.php');


// * ---- /public/actions/teachers/create.php (after successful insert) ---- */

require_once __DIR__ . '/../../../app/bootstrap.php';
require_auth();

// ... existing validation + insert ...
// assume $newId is the inserted teacher id
audit('create', 'teacher', (int)$newId, json_encode([
    'name' => $name ?? null,
    'reg_no' => $reg_no ?? null,
]));

// redirect as you already do