<?php
require_once __DIR__ . '/../../app/bootstrap.php';
require_auth();

$user = auth_user();
if (($user['role'] ?? '') !== 'admin') {
  flash_set('error', 'Permission denied.');
  redirect('teachers_trash.php');
  exit;
}

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
  flash_set('error', 'Invalid teacher ID.');
  redirect('teachers_trash.php');
  exit;
}

db()->prepare("
  UPDATE teachers SET deleted_at = NULL WHERE id = ?
")->execute([$id]);

flash_set('success', 'Teacher restored successfully.');
redirect('teachers_trash.php');
