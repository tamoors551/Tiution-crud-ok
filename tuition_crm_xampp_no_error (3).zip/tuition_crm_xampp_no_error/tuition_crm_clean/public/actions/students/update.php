<?php
require_once __DIR__ . '/../../../app/bootstrap.php';
require_auth();
csrf_verify();

$id = (int)($_POST['id'] ?? 0);
if (!$id) { flash_set('danger','Invalid request.'); redirect('students.php'); }

$data = [
  'id' => $id,
  'record_date' => $_POST['record_date'] ?? '',
  'reg_no' => $_POST['reg_no'] ?? null,
  'name' => $_POST['name'] ?? '',
  'phoneno' => $_POST['phoneno'] ?? null,
  'school_name' => $_POST['school_name'] ?? null,
  'class' => $_POST['class'] ?? '',
  'subjects' => $_POST['subjects'] ?? '',
  'city' => $_POST['city'] ?? '',
  'home_address' => $_POST['home_address'] ?? null,
  'fee_range' => $_POST['fee_range'] ?? null,
  'location' => $_POST['location'] ?? null,
  'location_link' => $_POST['location_link'] ?? null,
  'mode' => $_POST['mode'] ?? 'online',
  'device' => $_POST['device'] ?? 'laptop',
];

$stmt = db()->prepare("
  UPDATE students SET
    record_date=:record_date,
    reg_no=:reg_no,
    name=:name,
    phoneno=:phoneno,
    school_name=:school_name,
    class=:class,
    subjects=:subjects,
    city=:city,
    home_address=:home_address,
    fee_range=:fee_range,
    location=:location,
    location_link=:location_link,
    mode=:mode,
    device=:device
  WHERE id=:id
");
$stmt->execute($data);

flash_set('success', 'Student updated.');
redirect('students.php');
