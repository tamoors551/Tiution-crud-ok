<?php
require_once __DIR__ . '/../../../app/bootstrap.php';
require_auth();
csrf_verify();

$id = (int)($_POST['id'] ?? 0);
if ($id) {
  $stmt = db()->prepare("DELETE FROM students WHERE id=?");
  $stmt->execute([$id]);
}

flash_set('success', 'Student deleted.');
redirect('students.php');
