<?php
require_once __DIR__ . '/../../../app/bootstrap.php';
require_auth();
csrf_verify();

$data = [
  'record_date' => $_POST['record_date'] ?? '',
  'reg_no' => $_POST['reg_no'] ?? null,
  'name' => $_POST['name'] ?? '',
  'phoneno' => $_POST['phoneno'] ?? null,
  'school_name' => $_POST['school_name'] ?? null,
  'class' => $_POST['class'] ?? '',
  'subjects' => $_POST['subjects'] ?? '',
  'city' => $_POST['city'] ?? '',
  'home_address' => $_POST['home_address'] ?? null,
  'fee_range' => $_POST['fee_range'] ?? null,
  'location' => $_POST['location'] ?? null,
  'location_link' => $_POST['location_link'] ?? null,
  'mode' => $_POST['mode'] ?? 'online',
  'device' => $_POST['device'] ?? 'laptop',
];

$stmt = db()->prepare("
  INSERT INTO students
  (record_date, reg_no, name, phoneno, school_name, class, subjects, city, home_address, fee_range, location, location_link, mode, device)
  VALUES
  (:record_date, :reg_no, :name, :phoneno, :school_name, :class, :subjects, :city, :home_address, :fee_range, :location, :location_link, :mode, :device)
");
$stmt->execute($data);

flash_set('success', 'Student created.');
redirect('students.php');
