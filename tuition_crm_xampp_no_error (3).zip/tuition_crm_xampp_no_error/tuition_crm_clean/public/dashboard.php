<?php
// /public/dashboard.php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$u         = auth_user();
$pageTitle = 'Dashboard';
$is_admin  = $u && strtolower((string)($u['role'] ?? '')) === 'admin';

/*
|--------------------------------------------------------------------------
| Helpers (safe + readable)
|--------------------------------------------------------------------------
*/
function pct_int($num, $den): int {
  $den = max(1, (int)$den);
  return (int) round(((int)$num / $den) * 100);
}
function safe_ym($ym): string {
  return preg_match('/^\d{4}\-\d{2}$/', (string)$ym) ? (string)$ym : date('Y-m');
}
function safe_date($d, $fallback): string {
  return preg_match('/^\d{4}\-\d{2}\-\d{2}$/', (string)$d) ? (string)$d : (string)$fallback;
}
function human_when($ts): string {
  $t = strtotime((string)$ts);
  if (!$t) return (string)$ts;

  $days = (int) floor((time() - $t) / 86400);
  if ($days <= 0) return 'Today';
  if ($days === 1) return 'Yesterday';
  return $days . ' days ago';
}
function money_fmt($n): string {
  return number_format((float)$n, 0, '.', ',');
}
function clamp_int($v, $min, $max): int {
  $v = (int)$v;
  if ($v < $min) return $min;
  if ($v > $max) return $max;
  return $v;
}
function badge_for_status($status): string {
  if ($status === 'Paid') return 'success';
  if ($status === 'Partial') return 'warning';
  return 'secondary';
}
function build_qs(array $override = []): string {
  $cur = $_GET ?? [];
  foreach ($override as $k => $v) {
    if ($v === null) unset($cur[$k]);
    else $cur[$k] = $v;
  }
  return http_build_query($cur);
}
function ui_badge($text, $variant = 'secondary'): string {
  $text = (string)$text;
  $variant = preg_match('/^(primary|secondary|success|danger|warning|info|light|dark)$/', (string)$variant) ? $variant : 'secondary';
  return '<span class="badge text-bg-'.$variant.'">'.e($text).'</span>';
}
function ui_icon($name): string {
  // Inline SVG icons (no external dependency)
  $icons = [
    'grid' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 4h7v7H4V4Zm9 0h7v7h-7V4ZM4 13h7v7H4v-7Zm9 0h7v7h-7v-7Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    'users' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z" stroke="currentColor" stroke-width="1.6"/><path d="M22 21v-2a4 4 0 0 0-3-3.87" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M16 3.13a4 4 0 0 1 0 7.75" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    'teacher' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 2l10 6-10 6L2 8l10-6Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M22 8v6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M6 12v6c0 1 3 3 6 3s6-2 6-3v-6" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    'money' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 1v22" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7H14a3.5 3.5 0 0 1 0 7H6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    'trend' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 17l6-6 4 4 7-8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M21 7v6h-6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    'alert' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 9v4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M12 17h.01" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>',
    'file' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M14 2v6h6" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    'logout' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M16 17l5-5-5-5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M21 12H9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    'download' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M7 10l5 5 5-5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 15V3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    'search' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z" stroke="currentColor" stroke-width="1.6"/><path d="M21 21l-4.35-4.35" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
  ];
  return $icons[$name] ?? '';
}

/*
|--------------------------------------------------------------------------
| Inputs
|--------------------------------------------------------------------------
| mode=month&ym=YYYY-MM
| mode=range&from=YYYY-MM-DD&to=YYYY-MM-DD
| preset=month|last30|this_week|last_week|this_year
| tab=overview|finance|risks|health|activity
| q=quick search
| status=Paid|Partial|Pending|(blank for all)
| export=1 (CSV summary)
| export_rows=1 (CSV rows for tuitions in period)
|--------------------------------------------------------------------------
*/
$mode = trim((string)($_GET['mode'] ?? 'month'));
if (!in_array($mode, ['month', 'range'], true)) $mode = 'month';

$tab = trim((string)($_GET['tab'] ?? 'overview'));
if (!in_array($tab, ['overview','finance','risks','health','activity'], true)) $tab = 'overview';

$preset = trim((string)($_GET['preset'] ?? ''));
if (!in_array($preset, ['','month','last30','this_week','last_week','this_year'], true)) $preset = '';

$status = trim((string)($_GET['status'] ?? ''));
$allowed_status = ['','Paid','Partial','Pending'];
if (!in_array($status, $allowed_status, true)) $status = '';

$ym = safe_ym(trim((string)($_GET['ym'] ?? date('Y-m'))));
$from = trim((string)($_GET['from'] ?? ''));
$to   = trim((string)($_GET['to'] ?? ''));

$q = trim((string)($_GET['q'] ?? ''));
$q_like = '%' . $q . '%';

$export = (int)($_GET['export'] ?? 0);
$export_rows = (int)($_GET['export_rows'] ?? 0);

/*
|--------------------------------------------------------------------------
| Resolve period by preset
|--------------------------------------------------------------------------
*/
$today = date('Y-m-d');

if ($preset === 'last30') {
  $mode = 'range';
  $period_end = $today;
  $period_start = date('Y-m-d', strtotime($today . ' -29 days'));
} elseif ($preset === 'this_week') {
  $mode = 'range';
  $monday = date('Y-m-d', strtotime('monday this week'));
  $sunday = date('Y-m-d', strtotime('sunday this week'));
  $period_start = $monday;
  $period_end = $sunday;
} elseif ($preset === 'last_week') {
  $mode = 'range';
  $monday = date('Y-m-d', strtotime('monday last week'));
  $sunday = date('Y-m-d', strtotime('sunday last week'));
  $period_start = $monday;
  $period_end = $sunday;
} elseif ($preset === 'this_year') {
  $mode = 'range';
  $period_start = date('Y-01-01');
  $period_end = date('Y-12-31');
} else {
  if ($mode === 'range') {
    $period_start = safe_date($from, date('Y-m-01'));
    $period_end   = safe_date($to, date('Y-m-t'));
  } else {
    $period_start = $ym . '-01';
    $period_end   = date('Y-m-t', strtotime($period_start));
  }
}

$prev_month_ym = date('Y-m', strtotime($period_start . ' -1 month'));
$next_month_ym = date('Y-m', strtotime($period_start . ' +1 month'));
$this_month_ym = date('Y-m');

$last_start = date('Y-m-01', strtotime($period_start . ' -1 month'));
$last_end   = date('Y-m-t',  strtotime($last_start));
$last7_start = date('Y-m-d', strtotime($today . ' -6 days'));

/*
|--------------------------------------------------------------------------
| Export CSV (Dashboard summary)
|--------------------------------------------------------------------------
*/
if ($export === 1) {
  $students_total = $teachers_total = $tuitions_total = 0;
  $fee_total = $share_total = $paid_total = $pending_total = 0;
  $c_paid = $c_partial = $c_pending = 0;

  try { $students_total = (int) db()->query("SELECT COUNT(*) FROM students")->fetchColumn(); } catch (Throwable $e) {}
  try { $teachers_total = (int) db()->query("SELECT COUNT(*) FROM teachers")->fetchColumn(); } catch (Throwable $e) {}
  try { $tuitions_total = (int) db()->query("SELECT COUNT(*) FROM tuitions")->fetchColumn(); } catch (Throwable $e) {}

  try {
    $stmt = db()->prepare("
      SELECT
        COALESCE(SUM(monthly_fee),0) AS fee_total,
        COALESCE(SUM(company_share_amount),0) AS share_total,
        COALESCE(SUM(paid_to_company),0) AS paid_total,
        COALESCE(SUM(pending_to_company),0) AS pending_total,
        COALESCE(SUM(CASE WHEN status='Paid' THEN 1 ELSE 0 END),0) AS c_paid,
        COALESCE(SUM(CASE WHEN status='Partial' THEN 1 ELSE 0 END),0) AS c_partial,
        COALESCE(SUM(CASE WHEN status='Pending' THEN 1 ELSE 0 END),0) AS c_pending
      FROM tuitions
      WHERE tuition_date BETWEEN ? AND ?
        AND ( ? = '' OR status = ? )
    ");
    $stmt->execute([$period_start, $period_end, $status, $status]);
    $r = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    $fee_total     = (int)($r['fee_total'] ?? 0);
    $share_total   = (int)($r['share_total'] ?? 0);
    $paid_total    = (int)($r['paid_total'] ?? 0);
    $pending_total = (int)($r['pending_total'] ?? 0);
    $c_paid        = (int)($r['c_paid'] ?? 0);
    $c_partial     = (int)($r['c_partial'] ?? 0);
    $c_pending     = (int)($r['c_pending'] ?? 0);
  } catch (Throwable $e) {}

  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="dashboard_summary.csv"');
  $out = fopen('php://output', 'w');

  fputcsv($out, ['Dashboard Summary']);
  fputcsv($out, ['Period Start', $period_start]);
  fputcsv($out, ['Period End', $period_end]);
  fputcsv($out, ['Status Filter', $status === '' ? 'All' : $status]);
  fputcsv($out, []);

  fputcsv($out, ['Students Total', $students_total]);
  fputcsv($out, ['Teachers Total', $teachers_total]);
  fputcsv($out, ['Tuitions Total', $tuitions_total]);
  fputcsv($out, []);

  fputcsv($out, ['Fee Total', $fee_total]);
  fputcsv($out, ['Company Share Total', $share_total]);
  fputcsv($out, ['Paid to Company', $paid_total]);
  fputcsv($out, ['Pending to Company', $pending_total]);
  fputcsv($out, []);

  fputcsv($out, ['Paid Count', $c_paid]);
  fputcsv($out, ['Partial Count', $c_partial]);
  fputcsv($out, ['Pending Count', $c_pending]);

  fclose($out);
  exit;
}

/*
|--------------------------------------------------------------------------
| Export CSV (Tuition rows in selected period)
|--------------------------------------------------------------------------
*/
if ($export_rows === 1) {
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="tuitions_period_rows.csv"');
  $out = fopen('php://output', 'w');

  fputcsv($out, ['Tuition Rows Export']);
  fputcsv($out, ['Period Start', $period_start]);
  fputcsv($out, ['Period End', $period_end]);
  fputcsv($out, ['Status Filter', $status === '' ? 'All' : $status]);
  fputcsv($out, []);
  fputcsv($out, ['ID','Date','Student','Teacher','Fee','Company Share','Paid','Pending','Status']);

  try {
    $stmt = db()->prepare("
      SELECT t.id, t.tuition_date, s.name AS student_name, te.name AS teacher_name,
             t.monthly_fee, t.company_share_amount, t.paid_to_company, t.pending_to_company, t.status
      FROM tuitions t
      JOIN students s ON s.id = t.student_id
      JOIN teachers te ON te.id = t.teacher_id
      WHERE t.tuition_date BETWEEN ? AND ?
        AND ( ? = '' OR t.status = ? )
      ORDER BY t.tuition_date DESC, t.id DESC
      LIMIT 5000
    ");
    $stmt->execute([$period_start, $period_end, $status, $status]);
    while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
      fputcsv($out, [
        $r['id'],
        $r['tuition_date'],
        $r['student_name'],
        $r['teacher_name'],
        $r['monthly_fee'],
        $r['company_share_amount'],
        $r['paid_to_company'],
        $r['pending_to_company'],
        $r['status'],
      ]);
    }
  } catch (Throwable $e) {
    fputcsv($out, ['ERROR', 'Could not export rows']);
  }

  fclose($out);
  exit;
}

/*
|--------------------------------------------------------------------------
| Defaults
|--------------------------------------------------------------------------
*/
$students_total = $teachers_total = $tuitions_total = 0;

$fee_total = $share_total = $paid_total = $pending_total = 0;
$c_paid = $c_partial = $c_pending = 0;

$today_count = $today_fee = $today_share = $today_pending = 0;

$last_fee_total = $last_share_total = $last_paid_total = $last_pending_total = 0;

$top_share_teachers = [];
$top_pending_teachers = [];
$top_students_fee = [];
$risk_pending_rows = [];
$recent_tuitions = [];
$recent_logs = [];

$teachers_missing_docs = 0;
$teachers_missing_phone = 0;
$students_missing_phone = 0;
$students_missing_location_link = 0;

$teachers_missing_docs_list = [];
$city_students = [];
$city_teachers = [];

$search_hits_students = [];
$search_hits_teachers = [];

/* Trend & snapshot */
$trend_days = [];
$trend_company = [];
$trend_paid = [];
$trend_pending = [];

$best_day = ['d' => '', 'fee' => 0];
$worst_day = ['d' => '', 'fee' => 0];

$last7 = [
  'cnt' => 0,
  'fee' => 0,
  'share' => 0,
  'paid' => 0,
  'pending' => 0,
];

/* New KPIs */
$period_rows_cnt = 0;
$avg_fee = 0;
$avg_share = 0;
$avg_pending = 0;
$zero_fee_days = [];
$high_pending_count = 0;

/*
|--------------------------------------------------------------------------
| Totals
|--------------------------------------------------------------------------
*/
try { $students_total = (int) db()->query("SELECT COUNT(*) FROM students")->fetchColumn(); } catch (Throwable $e) {}
try { $teachers_total = (int) db()->query("SELECT COUNT(*) FROM teachers")->fetchColumn(); } catch (Throwable $e) {}
try { $tuitions_total = (int) db()->query("SELECT COUNT(*) FROM tuitions")->fetchColumn(); } catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Period summary (status aware)
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT
      COALESCE(SUM(monthly_fee),0) AS fee_total,
      COALESCE(SUM(company_share_amount),0) AS share_total,
      COALESCE(SUM(paid_to_company),0) AS paid_total,
      COALESCE(SUM(pending_to_company),0) AS pending_total,
      COALESCE(SUM(CASE WHEN status='Paid' THEN 1 ELSE 0 END),0) AS c_paid,
      COALESCE(SUM(CASE WHEN status='Partial' THEN 1 ELSE 0 END),0) AS c_partial,
      COALESCE(SUM(CASE WHEN status='Pending' THEN 1 ELSE 0 END),0) AS c_pending,
      COALESCE(COUNT(*),0) AS rows_cnt,
      COALESCE(AVG(monthly_fee),0) AS avg_fee,
      COALESCE(AVG(company_share_amount),0) AS avg_share,
      COALESCE(AVG(pending_to_company),0) AS avg_pending
    FROM tuitions
    WHERE tuition_date BETWEEN ? AND ?
      AND ( ? = '' OR status = ? )
  ");
  $stmt->execute([$period_start, $period_end, $status, $status]);
  $r = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
  $fee_total     = (int)($r['fee_total'] ?? 0);
  $share_total   = (int)($r['share_total'] ?? 0);
  $paid_total    = (int)($r['paid_total'] ?? 0);
  $pending_total = (int)($r['pending_total'] ?? 0);
  $c_paid        = (int)($r['c_paid'] ?? 0);
  $c_partial     = (int)($r['c_partial'] ?? 0);
  $c_pending     = (int)($r['c_pending'] ?? 0);

  $period_rows_cnt = (int)($r['rows_cnt'] ?? 0);
  $avg_fee = (int) round((float)($r['avg_fee'] ?? 0));
  $avg_share = (int) round((float)($r['avg_share'] ?? 0));
  $avg_pending = (int) round((float)($r['avg_pending'] ?? 0));
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Last month comparison (status aware)
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT
      COALESCE(SUM(monthly_fee),0) AS fee_total,
      COALESCE(SUM(company_share_amount),0) AS share_total,
      COALESCE(SUM(paid_to_company),0) AS paid_total,
      COALESCE(SUM(pending_to_company),0) AS pending_total
    FROM tuitions
    WHERE tuition_date BETWEEN ? AND ?
      AND ( ? = '' OR status = ? )
  ");
  $stmt->execute([$last_start, $last_end, $status, $status]);
  $r = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
  $last_fee_total     = (int)($r['fee_total'] ?? 0);
  $last_share_total   = (int)($r['share_total'] ?? 0);
  $last_paid_total    = (int)($r['paid_total'] ?? 0);
  $last_pending_total = (int)($r['pending_total'] ?? 0);
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Today (status aware)
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT
      COUNT(*) AS cnt,
      COALESCE(SUM(monthly_fee),0) AS fee_total,
      COALESCE(SUM(company_share_amount),0) AS share_total,
      COALESCE(SUM(pending_to_company),0) AS pending_total
    FROM tuitions
    WHERE tuition_date = ?
      AND ( ? = '' OR status = ? )
  ");
  $stmt->execute([$today, $status, $status]);
  $r = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
  $today_count   = (int)($r['cnt'] ?? 0);
  $today_fee     = (int)($r['fee_total'] ?? 0);
  $today_share   = (int)($r['share_total'] ?? 0);
  $today_pending = (int)($r['pending_total'] ?? 0);
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Last 7 days snapshot (status aware)
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT
      COUNT(*) AS cnt,
      COALESCE(SUM(monthly_fee),0) AS fee_total,
      COALESCE(SUM(company_share_amount),0) AS share_total,
      COALESCE(SUM(paid_to_company),0) AS paid_total,
      COALESCE(SUM(pending_to_company),0) AS pending_total
    FROM tuitions
    WHERE tuition_date BETWEEN ? AND ?
      AND ( ? = '' OR status = ? )
  ");
  $stmt->execute([$last7_start, $today, $status, $status]);
  $r = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
  $last7['cnt']     = (int)($r['cnt'] ?? 0);
  $last7['fee']     = (int)($r['fee_total'] ?? 0);
  $last7['share']   = (int)($r['share_total'] ?? 0);
  $last7['paid']    = (int)($r['paid_total'] ?? 0);
  $last7['pending'] = (int)($r['pending_total'] ?? 0);
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Trend lines in selected period (status aware)
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT
      tuition_date,
      COALESCE(SUM(monthly_fee),0) AS fee_total,
      COALESCE(SUM(company_share_amount),0) AS share_total,
      COALESCE(SUM(paid_to_company),0) AS paid_total,
      COALESCE(SUM(pending_to_company),0) AS pending_total
    FROM tuitions
    WHERE tuition_date BETWEEN ? AND ?
      AND ( ? = '' OR status = ? )
    GROUP BY tuition_date
    ORDER BY tuition_date ASC
  ");
  $stmt->execute([$period_start, $period_end, $status, $status]);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  foreach ($rows as $rr) {
    $d = (string)$rr['tuition_date'];
    $trend_days[$d] = (int)$rr['fee_total'];
    $trend_company[$d] = (int)$rr['share_total'];
    $trend_paid[$d] = (int)$rr['paid_total'];
    $trend_pending[$d] = (int)$rr['pending_total'];
  }

  foreach ($trend_days as $d => $v) {
    if ($best_day['d'] === '' || $v > $best_day['fee']) $best_day = ['d' => $d, 'fee' => $v];
    if ($worst_day['d'] === '' || $v < $worst_day['fee']) $worst_day = ['d' => $d, 'fee' => $v];
  }

  foreach ($trend_days as $d => $v) {
    if ((int)$v === 0) $zero_fee_days[] = $d;
  }
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Top teachers + students (status aware)
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT te.id, te.name, COALESCE(SUM(t.company_share_amount),0) AS share_sum
    FROM tuitions t
    JOIN teachers te ON te.id = t.teacher_id
    WHERE t.tuition_date BETWEEN ? AND ?
      AND ( ? = '' OR t.status = ? )
    GROUP BY te.id, te.name
    ORDER BY share_sum DESC
    LIMIT 5
  ");
  $stmt->execute([$period_start, $period_end, $status, $status]);
  $top_share_teachers = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $stmt = db()->prepare("
    SELECT te.id, te.name, COALESCE(SUM(t.pending_to_company),0) AS pending_sum
    FROM tuitions t
    JOIN teachers te ON te.id = t.teacher_id
    WHERE t.tuition_date BETWEEN ? AND ?
      AND ( ? = '' OR t.status = ? )
    GROUP BY te.id, te.name
    ORDER BY pending_sum DESC
    LIMIT 5
  ");
  $stmt->execute([$period_start, $period_end, $status, $status]);
  $top_pending_teachers = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $stmt = db()->prepare("
    SELECT s.id, s.name, COALESCE(SUM(t.monthly_fee),0) AS fee_sum
    FROM tuitions t
    JOIN students s ON s.id = t.student_id
    WHERE t.tuition_date BETWEEN ? AND ?
      AND ( ? = '' OR t.status = ? )
    GROUP BY s.id, s.name
    ORDER BY fee_sum DESC
    LIMIT 5
  ");
  $stmt->execute([$period_start, $period_end, $status, $status]);
  $top_students_fee = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Risk: highest pending rows (global, but status-aware when status set)
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT t.id, t.tuition_date, s.name AS student_name, te.name AS teacher_name,
           t.pending_to_company, t.status, te.id AS teacher_id, s.id AS student_id
    FROM tuitions t
    JOIN students s ON s.id = t.student_id
    JOIN teachers te ON te.id = t.teacher_id
    WHERE t.pending_to_company > 0
      AND ( ? = '' OR t.status = ? )
    ORDER BY t.pending_to_company DESC, t.tuition_date DESC
    LIMIT 10
  ");
  $stmt->execute([$status, $status]);
  $risk_pending_rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  $high_pending_count = count($risk_pending_rows);
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Recent tuitions + logs
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT t.id, t.tuition_date, s.name AS student_name, te.name AS teacher_name,
           s.id AS student_id, te.id AS teacher_id,
           t.monthly_fee, t.company_share_amount, t.paid_to_company, t.pending_to_company, t.status
    FROM tuitions t
    JOIN students s ON s.id = t.student_id
    JOIN teachers te ON te.id = t.teacher_id
    WHERE t.tuition_date BETWEEN ? AND ?
      AND ( ? = '' OR t.status = ? )
    ORDER BY t.tuition_date DESC, t.id DESC
    LIMIT 10
  ");
  $stmt->execute([$period_start, $period_end, $status, $status]);
  $recent_tuitions = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $stmt = db()->query("
    SELECT al.created_at, al.action, al.entity, al.entity_id, al.details, al.ip,
           u.name AS user_name
    FROM activity_log al
    LEFT JOIN users u ON u.id = al.user_id
    ORDER BY al.created_at DESC, al.id DESC
    LIMIT 10
  ");
  $recent_logs = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Health
|--------------------------------------------------------------------------
*/
try {
  $teachers_missing_docs = (int) db()->query("
    SELECT COUNT(*)
    FROM teachers
    WHERE (teacher_id_file IS NULL OR teacher_id_file = '')
       OR (teacher_doc_file IS NULL OR teacher_doc_file = '')
  ")->fetchColumn();
} catch (Throwable $e) {}

try {
  $teachers_missing_phone = (int) db()->query("
    SELECT COUNT(*) FROM teachers WHERE phoneno IS NULL OR phoneno = ''
  ")->fetchColumn();
} catch (Throwable $e) {}

try {
  $students_missing_phone = (int) db()->query("
    SELECT COUNT(*) FROM students WHERE phoneno IS NULL OR phoneno = ''
  ")->fetchColumn();
} catch (Throwable $e) {}

try {
  $students_missing_location_link = (int) db()->query("
    SELECT COUNT(*) FROM students WHERE location_link IS NULL OR location_link = ''
  ")->fetchColumn();
} catch (Throwable $e) {}

try {
  $stmt = db()->query("
    SELECT id, name, reg_no, city, teacher_id_file, teacher_doc_file
    FROM teachers
    WHERE (teacher_id_file IS NULL OR teacher_id_file = '')
       OR (teacher_doc_file IS NULL OR teacher_doc_file = '')
    ORDER BY record_date DESC, id DESC
    LIMIT 8
  ");
  $teachers_missing_docs_list = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $stmt = db()->query("
    SELECT city, COUNT(*) AS cnt
    FROM students
    GROUP BY city
    ORDER BY cnt DESC, city ASC
    LIMIT 5
  ");
  $city_students = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $stmt = db()->query("
    SELECT city, COUNT(*) AS cnt
    FROM teachers
    GROUP BY city
    ORDER BY cnt DESC, city ASC
    LIMIT 5
  ");
  $city_teachers = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Quick search
|--------------------------------------------------------------------------
*/
if ($q !== '') {
  try {
    $stmt = db()->prepare("
      SELECT id, reg_no, name, phoneno, city
      FROM students
      WHERE name LIKE ? OR reg_no LIKE ? OR phoneno LIKE ? OR city LIKE ?
      ORDER BY id DESC
      LIMIT 6
    ");
    $stmt->execute([$q_like, $q_like, $q_like, $q_like]);
    $search_hits_students = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {}

  try {
    $stmt = db()->prepare("
      SELECT id, reg_no, name, phoneno, city
      FROM teachers
      WHERE name LIKE ? OR reg_no LIKE ? OR phoneno LIKE ? OR city LIKE ?
      ORDER BY id DESC
      LIMIT 6
    ");
    $stmt->execute([$q_like, $q_like, $q_like, $q_like]);
    $search_hits_teachers = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {}
}

/*
|--------------------------------------------------------------------------
| Derived KPIs + Insights
|--------------------------------------------------------------------------
*/
$period_count = max(1, ($c_paid + $c_partial + $c_pending));
$paid_pct    = pct_int($c_paid, $period_count);
$partial_pct = pct_int($c_partial, $period_count);
$pending_pct = pct_int($c_pending, $period_count);

$collect_den = max(1, ($paid_total + $pending_total));
$collect_pct = pct_int($paid_total, $collect_den);

$share_pct_of_fee   = pct_int($share_total, max(1, $fee_total));
$pending_pct_of_sh  = pct_int($pending_total, max(1, $share_total));
$paid_pct_of_sh     = pct_int($paid_total, max(1, $share_total));

$delta_fee     = $fee_total - $last_fee_total;
$delta_share   = $share_total - $last_share_total;
$delta_paid    = $paid_total - $last_paid_total;
$delta_pending = $pending_total - $last_pending_total;

function delta_style($d): array {
  if ($d > 0) return ['text-success', '↑ ' . money_fmt($d)];
  if ($d < 0) return ['text-danger', '↓ ' . money_fmt(abs($d))];
  return ['text-secondary', '0'];
}

/* Health score */
$score = 100;
$score -= min(35, $teachers_missing_docs * 3);
$score -= min(20, $teachers_missing_phone * 2);
$score -= min(20, $students_missing_phone * 2);
$score -= min(25, $students_missing_location_link * 2);
$score = clamp_int($score, 0, 100);

/* Auto alerts */
$alerts = [];
if ($pending_total > 0) $alerts[] = "Pending amount exists in this period (company money stuck).";
if ($collect_pct < 60 && ($paid_total + $pending_total) > 0) $alerts[] = "Collection rate is low. Consider follow ups.";
if ($teachers_missing_docs > 0) $alerts[] = "Some teachers have missing documents.";
if ($teachers_missing_phone > 0) $alerts[] = "Some teachers are missing phone numbers.";
if ($students_missing_phone > 0) $alerts[] = "Some students are missing phone numbers.";
if ($students_missing_location_link > 0) $alerts[] = "Some students have missing location links.";
if (count($zero_fee_days) > 0) $alerts[] = "There are days with 0 fee in the selected period (check missing records).";

/* Insights */
$insights = [];
if ($pending_total > 0 && $pending_pct_of_sh >= 40) $insights[] = "A large portion of company share is still pending. This usually needs payment follow up.";
if ($paid_pct >= 70) $insights[] = "Payment status looks strong. Most records are Paid in this period.";
if ($partial_pct >= 35) $insights[] = "Many records are Partial. Consider confirming the remaining balance dates.";
if ($teachers_missing_docs > 0) $insights[] = "File health is not clean. Missing documents can cause problems during verification.";
if ($best_day['d'] !== '' && $worst_day['d'] !== '' && $best_day['d'] !== $worst_day['d']) {
  $insights[] = "Best day: {$best_day['d']} (Fee " . money_fmt($best_day['fee']) . "). Worst day: {$worst_day['d']} (Fee " . money_fmt($worst_day['fee']) . ").";
}

/*
|--------------------------------------------------------------------------
| MINI TREND BAR CALC
|--------------------------------------------------------------------------
*/
$trend_dates = array_keys($trend_days);
$trend_count = count($trend_dates);
$trend_slice = [];
if ($trend_count > 0) {
  $trend_slice = array_slice($trend_dates, max(0, $trend_count - 14));
}
$max_fee_day = 0;
foreach ($trend_slice as $d) {
  $max_fee_day = max($max_fee_day, (int)($trend_days[$d] ?? 0));
}
$max_fee_day = max(1, $max_fee_day);

require __DIR__ . '/_layout_top.php';
?>

<style>
  /* Professional dark glass UI (works with Bootstrap) */
  :root{
    --dash-bg1: rgba(0,0,0,.62);
    --dash-bg2: rgba(0,0,0,.28);
    --dash-stroke: rgba(255,255,255,.10);
    --dash-stroke2: rgba(255,255,255,.14);
    --dash-text: rgba(245,222,179,.95);
    --dash-sub: rgba(245,222,179,.72);
    --dash-sub2: rgba(245,222,179,.58);
    --dash-shadow: 0 18px 40px rgba(0,0,0,.35);
    --dash-radius: 18px;
  }

  .dash-wrap { max-width: 1400px; margin: 0 auto; }
  .dash-title { color: var(--dash-text); letter-spacing: .2px; }
  .dash-sub { color: var(--dash-sub) !important; }
  .dash-sub2 { color: var(--dash-sub2) !important; }

  .dash-surface{
    background: linear-gradient(180deg, var(--dash-bg1), var(--dash-bg2));
    border: 1px solid var(--dash-stroke);
    border-radius: var(--dash-radius);
    box-shadow: var(--dash-shadow);
  }

  .dash-topbar{
    position: sticky;
    top: 0;
    z-index: 40;
    backdrop-filter: blur(10px);
  }
  .dash-topbar-inner{
    background: linear-gradient(180deg, rgba(0,0,0,.58), rgba(0,0,0,.25));
    border: 1px solid var(--dash-stroke);
    border-radius: var(--dash-radius);
    box-shadow: 0 10px 24px rgba(0,0,0,.25);
  }

  .dash-pill{
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding: 6px 12px;
    border-radius: 999px;
    border: 1px solid var(--dash-stroke2);
    background: rgba(255,255,255,.07);
    color: var(--dash-text);
    font-size: .86rem;
    line-height: 1;
    white-space: nowrap;
  }
  .dash-pill svg { opacity: .9; }

  .dash-btn{
    border-radius: 14px;
    padding: 10px 12px;
    display:inline-flex;
    gap:10px;
    align-items:center;
    font-weight: 650;
  }

  .dash-kpi{
    border-radius: var(--dash-radius);
    border: 1px solid var(--dash-stroke);
    background: rgba(255,255,255,.06);
    padding: 14px;
    height: 100%;
  }
  .dash-kpi .kpi-top{
    display:flex;
    justify-content: space-between;
    align-items:flex-start;
    gap: 10px;
    margin-bottom: 8px;
  }
  .dash-kpi .kpi-ico{
    width: 38px;
    height: 38px;
    border-radius: 14px;
    border: 1px solid var(--dash-stroke2);
    background: rgba(255,255,255,.08);
    display:flex;
    align-items:center;
    justify-content:center;
    color: var(--dash-text);
  }
  .dash-kpi-label { color: var(--dash-sub2); font-size: .92rem; }
  .dash-kpi-val { color: var(--dash-text); font-weight: 900; font-size: 1.35rem; letter-spacing: .2px; }

  .dash-section-title{
    display:flex;
    align-items:center;
    gap:10px;
    color: var(--dash-text);
    margin: 0;
  }
  .dash-section-title .ico{
    width: 34px;
    height: 34px;
    border-radius: 14px;
    border: 1px solid var(--dash-stroke2);
    background: rgba(255,255,255,.08);
    display:flex;
    align-items:center;
    justify-content:center;
  }

  .dash-input label { color: var(--dash-text); font-weight: 700; }
  .dash-input input.form-control,
  .dash-input select.form-select{
    border-radius: 14px;
    background: rgba(0,0,0,.55) !important;
    color: var(--dash-text) !important;
    border: 1px solid var(--dash-stroke2) !important;
  }
  .dash-input input.form-control::placeholder { color: rgba(245,222,179,.55) !important; }
  .dash-input .form-control:focus,
  .dash-input .form-select:focus{
    box-shadow: 0 0 0 .22rem rgba(245,222,179,.12);
  }

  .dash-divider { border-top: 1px solid var(--dash-stroke); margin: 14px 0; }

  .dash-tabs .btn{ border-radius: 14px; padding: 10px 12px; font-weight: 750; display:inline-flex; gap:10px; align-items:center; }
  .dash-tabs .btn svg{ opacity: .95; }

  .dash-search .form-control{
    background: rgba(0,0,0,.55) !important;
    color: var(--dash-text) !important;
    border-radius: 16px;
    border: 1px solid var(--dash-stroke2) !important;
    padding: 12px 14px;
  }
  .dash-search .btn{ border-radius: 16px; font-weight: 800; padding: 12px 14px; }

  .dash-table{
    border-radius: var(--dash-radius);
    border: 1px solid var(--dash-stroke);
    background: rgba(0,0,0,.18);
    overflow: hidden;
  }
  .dash-table .table{ margin: 0; }
  .dash-table .table thead th{
    color: rgba(245,222,179,.78) !important;
    font-weight: 800;
    border-color: rgba(255,255,255,.10) !important;
    background: rgba(0,0,0,.35);
  }
  .dash-table .table td{
    border-color: rgba(255,255,255,.09) !important;
    color: rgba(245,222,179,.92) !important;
    vertical-align: middle;
  }
  .dash-table .table-hover tbody tr:hover{
    background: rgba(255,255,255,.06) !important;
  }

  .progress{
    background: rgba(255,255,255,.12);
    height: 10px;
    border-radius: 999px;
  }
  .progress-bar{
    border-radius: 999px;
  }

  .meter{
    display:grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
  }
  @media (max-width: 991px){
    .meter{ grid-template-columns: 1fr; }
  }

  .mini-bars{
    display:grid;
    grid-template-columns: repeat(14, 1fr);
    gap: 8px;
    align-items:end;
    min-height: 78px;
  }
  .mini-bars .bar{
    background: rgba(245,222,179,.18);
    border: 1px solid rgba(255,255,255,.12);
    border-radius: 12px;
    overflow: hidden;
    height: 78px;
  }
  .mini-bars .bar span{
    display:block;
    width:100%;
    height:100%;
    border-radius: 12px;
    background: rgba(245,222,179,.68);
  }
  .mini-note{ font-size: .9rem; color: rgba(245,222,179,.70); }

  .dash-alert{
    border: 1px solid var(--dash-stroke2);
    background: rgba(255,255,255,.06);
    border-radius: 16px;
    padding: 12px 14px;
  }
  .dash-alert .title{
    display:flex;
    align-items:center;
    gap:10px;
    margin-bottom: 6px;
    color: var(--dash-text);
    font-weight: 850;
  }
  .dash-alert ul{ margin: 0; padding-left: 18px; }
  .dash-alert li{ color: rgba(245,222,179,.86); margin: 6px 0; }

  .chip-row{ display:flex; flex-wrap: wrap; gap: 8px; }
  .chip{ display:inline-flex; align-items:center; gap:8px; padding: 8px 10px; border-radius: 999px; border: 1px solid var(--dash-stroke2); background: rgba(255,255,255,.06); color: var(--dash-text); font-size: .9rem; }

  .btn-outline-light{ border-color: rgba(255,255,255,.22) !important; }
  .btn-outline-light:hover{ background: rgba(255,255,255,.08) !important; }

  .dash-muted{ color: rgba(245,222,179,.62) !important; }
</style>

<!-- Sticky Header (shrinks on scroll) -->
<div id="dashSticky" class="dash-sticky mb-3">
  <div class="dash-sticky-inner">

    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center">
      <div class="me-3">
        <h2 class="mb-1 dash-title dash-title-big">Dashboard</h2>

        <!-- This line will auto-hide when header shrinks -->
        <div class="dash-sub hide-on-shrink">
          Welcome, <?= e($u['name'] ?? 'User') ?><?= isset($u['role']) && $u['role'] ? ' ('.e($u['role']).')' : '' ?>
          <span class="ms-2 dash-pill">Health score: <?= e((string)$score) ?>/100</span>
          <span class="ms-2 dash-pill">Period rows: <?= e((string)$period_rows_cnt) ?></span>
          <span class="ms-2 dash-pill">Status: <?= e($status === '' ? 'All' : $status) ?></span>
        </div>
      </div>

      <div class="d-flex gap-2 mt-2 mt-sm-0">
        <a class="btn btn-outline-light btn-sm-on-shrink"
           href="?<?= e(build_qs(['export' => 1, 'export_rows' => null])) ?>">Export Summary CSV</a>

        <a class="btn btn-outline-light btn-sm-on-shrink"
           href="?<?= e(build_qs(['export_rows' => 1, 'export' => null])) ?>">Export Tuition Rows CSV</a>

        <a class="btn btn-outline-light btn-sm-on-shrink"
           href="<?= e(url('logout.php')) ?>">Logout</a>
      </div>
    </div>

  </div>
</div>

<!-- <div class="dash-wrap"> -->

  <!-- Sticky top header -->
  <!-- <div class="dash-topbar mb-3">
    <div class="dash-topbar-inner p-3">
      <div class="d-flex flex-wrap justify-content-between align-items-start gap-3">
        <div class="me-2">
          <div class="d-flex align-items-center gap-2">
            <div class="dash-pill">
              <?= ui_icon('grid') ?>
              <span>Dashboard</span>
            </div>
            <div class="dash-pill">
              <span class="dash-muted">Period</span>
              <strong><?= e($period_start) ?></strong>
              <span class="dash-muted">to</span>
              <strong><?= e($period_end) ?></strong>
            </div>
            <div class="dash-pill">
              <span class="dash-muted">Status</span>
              <strong><?= e($status === '' ? 'All' : $status) ?></strong>
            </div>
          </div>

          <div class="mt-2 dash-sub">
            Welcome, <strong><?= e($u['name'] ?? 'User') ?></strong><?= isset($u['role']) && $u['role'] ? ' ('.e($u['role']).')' : '' ?>
            <span class="ms-2"><?= ui_badge('Health '.$score.'/100', $score >= 80 ? 'success' : ($score >= 55 ? 'warning' : 'danger')) ?></span>
            <span class="ms-2"><?= ui_badge('Rows '.$period_rows_cnt, 'info') ?></span>
          </div>
        </div>

        <div class="d-flex flex-wrap gap-2">
          <a class="btn btn-outline-light dash-btn" href="?<?= e(build_qs(['export' => 1, 'export_rows' => null])) ?>">
            <?= ui_icon('download') ?><span>Export Summary</span>
          </a>
          <a class="btn btn-outline-light dash-btn" href="?<?= e(build_qs(['export_rows' => 1, 'export' => null])) ?>">
            <?= ui_icon('file') ?><span>Export Rows</span>
          </a>
          <a class="btn btn-outline-light dash-btn" href="<?= e(url('logout.php')) ?>">
            <?= ui_icon('logout') ?><span>Logout</span>
          </a>
        </div>
      </div> -->

      <!-- <div class="dash-divider"></div> -->

      <!-- Quick actions -->
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
        <div class="d-flex flex-wrap gap-2">
          <a class="btn btn-primary dash-btn" href="<?= e(url('students.php')) ?>"><?= ui_icon('users') ?><span>Students</span></a>
          <a class="btn btn-primary dash-btn" href="<?= e(url('teachers.php')) ?>"><?= ui_icon('teacher') ?><span>Teachers</span></a>
          <a class="btn btn-primary dash-btn" href="<?= e(url('tuitions.php')) ?>"><?= ui_icon('money') ?><span>Tuitions</span></a>
          <a class="btn btn-outline-light dash-btn" href="<?= e(url('reports.php')) ?>"><?= ui_icon('trend') ?><span>Reports</span></a>
          <a class="btn btn-outline-light dash-btn" href="<?= e(url('reports.php')) ?>?from=<?= e($period_start) ?>&to=<?= e($period_end) ?>">
            <?= ui_icon('trend') ?><span>Reports for period</span>
          </a>
        </div>

        <?php if ($is_admin): ?>
          <div class="d-flex flex-wrap gap-2">
            <a class="btn btn-success dash-btn" href="<?= e(url('student_form.php')) ?>">+ Add Student</a>
            <a class="btn btn-success dash-btn" href="<?= e(url('teacher_form.php')) ?>">+ Add Teacher</a>
            <a class="btn btn-success dash-btn" href="<?= e(url('tuition_form.php')) ?>">+ Add Tuition</a>
          </div>
        <?php endif; ?>
      </div>

      <div class="dash-divider"></div>

      <!-- Mini KPI row -->
      <div class="row g-2">
        <div class="col-md-3">
          <div class="dash-kpi">
            <div class="kpi-top">
              <div>
                <div class="dash-kpi-label">Last 7 days fee</div>
                <div class="dash-kpi-val"><?= e(money_fmt($last7['fee'])) ?></div>
              </div>
              <div class="kpi-ico"><?= ui_icon('money') ?></div>
            </div>
            <div class="dash-sub2">Total fee recorded in the last 7 days</div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="dash-kpi">
            <div class="kpi-top">
              <div>
                <div class="dash-kpi-label">Last 7 days share</div>
                <div class="dash-kpi-val"><?= e(money_fmt($last7['share'])) ?></div>
              </div>
              <div class="kpi-ico"><?= ui_icon('trend') ?></div>
            </div>
            <div class="dash-sub2">Company share inside the last 7 days</div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="dash-kpi">
            <div class="kpi-top">
              <div>
                <div class="dash-kpi-label">Last 7 days paid</div>
                <div class="dash-kpi-val"><?= e(money_fmt($last7['paid'])) ?></div>
              </div>
              <div class="kpi-ico"><?= ui_icon('file') ?></div>
            </div>
            <div class="dash-sub2">Paid to company within 7 days</div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="dash-kpi">
            <div class="kpi-top">
              <div>
                <div class="dash-kpi-label">Last 7 days pending</div>
                <div class="dash-kpi-val"><?= e(money_fmt($last7['pending'])) ?></div>
              </div>
              <div class="kpi-ico"><?= ui_icon('alert') ?></div>
            </div>
            <div class="dash-sub2">Pending to company within 7 days</div>
          </div>
        </div>
      </div>

      <div class="dash-divider"></div>

      <!-- Presets and status chips -->
      <div class="d-flex flex-wrap gap-2 justify-content-between">
        <div class="chip-row">
          <a class="btn <?= $preset==='month' || ($preset==='' && $mode==='month') ? 'btn-info' : 'btn-outline-light' ?>"
             href="?<?= e(build_qs(['preset'=>'month','mode'=>'month','ym'=>$this_month_ym,'from'=>null,'to'=>null])) ?>">
            This month
          </a>
          <a class="btn <?= $preset==='last30' ? 'btn-info' : 'btn-outline-light' ?>"
             href="?<?= e(build_qs(['preset'=>'last30','mode'=>'range','ym'=>null])) ?>">
            Last 30 days
          </a>
          <a class="btn <?= $preset==='this_week' ? 'btn-info' : 'btn-outline-light' ?>"
             href="?<?= e(build_qs(['preset'=>'this_week','mode'=>'range','ym'=>null])) ?>">
            This week
          </a>
          <a class="btn <?= $preset==='last_week' ? 'btn-info' : 'btn-outline-light' ?>"
             href="?<?= e(build_qs(['preset'=>'last_week','mode'=>'range','ym'=>null])) ?>">
            Last week
          </a>
          <a class="btn <?= $preset==='this_year' ? 'btn-info' : 'btn-outline-light' ?>"
             href="?<?= e(build_qs(['preset'=>'this_year','mode'=>'range','ym'=>null])) ?>">
            This year
          </a>
        </div>

        <div class="chip-row">
          <a class="btn <?= $status===''?'btn-warning':'btn-outline-light' ?>" href="?<?= e(build_qs(['status'=>''])) ?>">All</a>
          <a class="btn <?= $status==='Pending'?'btn-warning':'btn-outline-light' ?>" href="?<?= e(build_qs(['status'=>'Pending'])) ?>">Pending</a>
          <a class="btn <?= $status==='Partial'?'btn-warning':'btn-outline-light' ?>" href="?<?= e(build_qs(['status'=>'Partial'])) ?>">Partial</a>
          <a class="btn <?= $status==='Paid'?'btn-warning':'btn-outline-light' ?>" href="?<?= e(build_qs(['status'=>'Paid'])) ?>">Paid</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Alerts + Insights -->
  <?php if ($alerts || $insights): ?>
    <div class="dash-surface p-3 mb-3">
      <div class="row g-3">
        <div class="col-lg-6">
          <div class="dash-alert">
            <div class="title"><?= ui_icon('alert') ?><span>Auto alerts</span></div>
            <?php if ($alerts): ?>
              <ul>
                <?php foreach ($alerts as $a): ?><li><?= e($a) ?></li><?php endforeach; ?>
              </ul>
            <?php else: ?>
              <div class="dash-sub2">No alerts right now.</div>
            <?php endif; ?>
          </div>
        </div>

        <div class="col-lg-6">
          <div class="dash-alert">
            <div class="title"><?= ui_icon('trend') ?><span>Insights</span></div>
            <?php if ($insights): ?>
              <ul>
                <?php foreach ($insights as $a): ?><li><?= e($a) ?></li><?php endforeach; ?>
              </ul>
            <?php else: ?>
              <div class="dash-sub2">No new insights yet. More history gives better trends.</div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <!-- Tabs -->
  <div class="dash-tabs d-flex flex-wrap gap-2 mb-3">
    <a class="btn <?= $tab==='overview'?'btn-info':'btn-outline-light' ?>" href="?<?= e(build_qs(['tab'=>'overview'])) ?>">
      <?= ui_icon('grid') ?><span>Overview</span>
    </a>
    <a class="btn <?= $tab==='finance'?'btn-info':'btn-outline-light' ?>" href="?<?= e(build_qs(['tab'=>'finance'])) ?>">
      <?= ui_icon('money') ?><span>Finance</span>
    </a>
    <a class="btn <?= $tab==='risks'?'btn-info':'btn-outline-light' ?>" href="?<?= e(build_qs(['tab'=>'risks'])) ?>">
      <?= ui_icon('alert') ?><span>Risks</span>
    </a>
    <a class="btn <?= $tab==='health'?'btn-info':'btn-outline-light' ?>" href="?<?= e(build_qs(['tab'=>'health'])) ?>">
      <?= ui_icon('file') ?><span>Data health</span>
    </a>
    <a class="btn <?= $tab==='activity'?'btn-info':'btn-outline-light' ?>" href="?<?= e(build_qs(['tab'=>'activity'])) ?>">
      <?= ui_icon('trend') ?><span>Activity</span>
    </a>
  </div>

  <!-- Quick Search -->
  <form class="row g-2 mb-3 dash-search" method="get">
    <input type="hidden" name="mode" value="<?= e($mode) ?>">
    <input type="hidden" name="tab" value="<?= e($tab) ?>">
    <input type="hidden" name="status" value="<?= e($status) ?>">
    <input type="hidden" name="preset" value="<?= e($preset) ?>">

    <?php if ($mode === 'month'): ?>
      <input type="hidden" name="ym" value="<?= e($ym) ?>">
    <?php else: ?>
      <input type="hidden" name="from" value="<?= e($period_start) ?>">
      <input type="hidden" name="to" value="<?= e($period_end) ?>">
    <?php endif; ?>

    <div class="col-md-10">
      <div class="position-relative">
        <div class="position-absolute top-50 translate-middle-y ms-3 text-light opacity-75">
          <?= ui_icon('search') ?>
        </div>
        <input type="text" class="form-control ps-5" name="q"
               placeholder="Quick search: student or teacher name, reg no, phone, city"
               value="<?= e($q) ?>">
      </div>
    </div>
    <div class="col-md-2 d-grid">
      <button class="btn btn-primary"><?= ui_icon('search') ?> <span>Search</span></button>
    </div>
  </form>

  <?php if ($q !== ''): ?>
    <div class="row g-3 mb-3">
      <div class="col-lg-6">
        <div class="dash-table">
          <div class="p-3 d-flex justify-content-between align-items-center">
            <h5 class="dash-section-title">
              <span class="ico"><?= ui_icon('users') ?></span>
              <span>Student matches</span>
            </h5>
            <span class="dash-pill"><?= e((string)count($search_hits_students)) ?> results</span>
          </div>

          <div class="table-responsive">
            <table class="table table-dark table-hover align-middle">
              <thead><tr><th>ID</th><th>Reg</th><th>Name</th><th>Phone</th><th>City</th><th class="text-end">Open</th></tr></thead>
              <tbody>
                <?php foreach ($search_hits_students as $x): ?>
                  <tr>
                    <td><?= e((string)$x['id']) ?></td>
                    <td><?= e((string)($x['reg_no'] ?? '')) ?></td>
                    <td>
                      <a class="link-light" href="<?= e(url('student_view.php?id='.(int)$x['id'])) ?>">
                        <?= e((string)$x['name']) ?>
                      </a>
                    </td>
                    <td><?= e((string)($x['phoneno'] ?? '')) ?></td>
                    <td><?= e((string)($x['city'] ?? '')) ?></td>
                    <td class="text-end">
                      <a class="btn btn-sm btn-outline-light" href="<?= e(url('student_view.php?id='.(int)$x['id'])) ?>">Open</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
                <?php if (!$search_hits_students): ?>
                  <tr><td colspan="6" class="text-center text-secondary">No student results</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="dash-table">
          <div class="p-3 d-flex justify-content-between align-items-center">
            <h5 class="dash-section-title">
              <span class="ico"><?= ui_icon('teacher') ?></span>
              <span>Teacher matches</span>
            </h5>
            <span class="dash-pill"><?= e((string)count($search_hits_teachers)) ?> results</span>
          </div>

          <div class="table-responsive">
            <table class="table table-dark table-hover align-middle">
              <thead><tr><th>ID</th><th>Reg</th><th>Name</th><th>Phone</th><th>City</th><th class="text-end">Open</th></tr></thead>
              <tbody>
                <?php foreach ($search_hits_teachers as $x): ?>
                  <tr>
                    <td><?= e((string)$x['id']) ?></td>
                    <td><?= e((string)($x['reg_no'] ?? '')) ?></td>
                    <td>
                      <a class="link-light" href="<?= e(url('teacher_view.php?id='.(int)$x['id'])) ?>">
                        <?= e((string)$x['name']) ?>
                      </a>
                    </td>
                    <td><?= e((string)($x['phoneno'] ?? '')) ?></td>
                    <td><?= e((string)($x['city'] ?? '')) ?></td>
                    <td class="text-end">
                      <a class="btn btn-sm btn-outline-light" href="<?= e(url('teacher_view.php?id='.(int)$x['id'])) ?>">Open</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
                <?php if (!$search_hits_teachers): ?>
                  <tr><td colspan="6" class="text-center text-secondary">No teacher results</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <!-- Period filter -->
  <div class="dash-surface p-3 mb-3">
    <form class="row g-2 align-items-end dash-input" method="get">
      <input type="hidden" name="tab" value="<?= e($tab) ?>">
      <input type="hidden" name="status" value="<?= e($status) ?>">
      <input type="hidden" name="preset" value="<?= e($preset) ?>">
      <?php if ($q !== ''): ?><input type="hidden" name="q" value="<?= e($q) ?>"><?php endif; ?>

      <div class="col-md-2">
        <label class="form-label">View mode</label>
        <select class="form-select" name="mode" onchange="this.form.submit()">
          <option value="month" <?= $mode==='month'?'selected':'' ?>>Month</option>
          <option value="range" <?= $mode==='range'?'selected':'' ?>>Custom range</option>
        </select>
      </div>

      <?php if ($mode === 'month'): ?>
        <div class="col-md-2">
          <label class="form-label">Month</label>
          <input type="month" class="form-control" name="ym" value="<?= e($ym) ?>">
        </div>
        <div class="col-md-2 d-grid">
          <button class="btn btn-success">Apply</button>
        </div>
        <div class="col-md-6 text-end">
          <div class="d-flex flex-wrap justify-content-end gap-2">
            <a class="btn btn-outline-light" href="?<?= e(build_qs(['mode'=>'month','ym'=>$prev_month_ym,'preset'=>''])) ?>">Prev</a>
            <a class="btn btn-outline-light" href="?<?= e(build_qs(['mode'=>'month','ym'=>$this_month_ym,'preset'=>'month'])) ?>">This month</a>
            <a class="btn btn-outline-light" href="?<?= e(build_qs(['mode'=>'month','ym'=>$next_month_ym,'preset'=>''])) ?>">Next</a>
          </div>
          <div class="dash-sub mt-2">Period <span class="dash-pill"><?= e($period_start) ?> → <?= e($period_end) ?></span></div>
        </div>
      <?php else: ?>
        <div class="col-md-3">
          <label class="form-label">From</label>
          <input type="date" class="form-control" name="from" value="<?= e($period_start) ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">To</label>
          <input type="date" class="form-control" name="to" value="<?= e($period_end) ?>">
        </div>
        <div class="col-md-2 d-grid">
          <button class="btn btn-success">Apply</button>
        </div>
        <div class="col-md-2 d-grid">
          <a class="btn btn-outline-light" href="?<?= e(build_qs(['mode'=>'month','ym'=>$this_month_ym,'preset'=>'month','from'=>null,'to'=>null])) ?>">Back to month</a>
        </div>
        <div class="col-md-2 text-end dash-sub">
          Period <span class="dash-pill"><?= e($period_start) ?> → <?= e($period_end) ?></span>
        </div>
      <?php endif; ?>
    </form>
  </div>

  <?php if ($tab === 'overview'): ?>
    <div class="row g-3 mb-3">
      <div class="col-lg-3">
        <div class="dash-kpi dash-surface">
          <div class="kpi-top">
            <div>
              <div class="dash-kpi-label">Students total</div>
              <div class="dash-kpi-val"><?= e((string)$students_total) ?></div>
            </div>
            <div class="kpi-ico"><?= ui_icon('users') ?></div>
          </div>
          <div class="dash-sub2">All student records in the system</div>
        </div>
      </div>

      <div class="col-lg-3">
        <div class="dash-kpi dash-surface">
          <div class="kpi-top">
            <div>
              <div class="dash-kpi-label">Teachers total</div>
              <div class="dash-kpi-val"><?= e((string)$teachers_total) ?></div>
            </div>
            <div class="kpi-ico"><?= ui_icon('teacher') ?></div>
          </div>
          <div class="dash-sub2">All teacher records in the system</div>
        </div>
      </div>

      <div class="col-lg-3">
        <div class="dash-kpi dash-surface">
          <div class="kpi-top">
            <div>
              <div class="dash-kpi-label">Today</div>
              <div class="dash-kpi-val"><?= e((string)$today_count) ?> tuitions</div>
            </div>
            <div class="kpi-ico"><?= ui_icon('grid') ?></div>
          </div>
          <div class="dash-sub2">Fee <?= e(money_fmt($today_fee)) ?> and share <?= e(money_fmt($today_share)) ?></div>
        </div>
      </div>

      <div class="col-lg-3">
        <div class="dash-kpi dash-surface">
          <div class="kpi-top">
            <div>
              <div class="dash-kpi-label">Period averages</div>
              <div class="dash-kpi-val"><?= e(money_fmt($avg_fee)) ?> fee</div>
            </div>
            <div class="kpi-ico"><?= ui_icon('trend') ?></div>
          </div>
          <div class="dash-sub2">Avg share <?= e(money_fmt($avg_share)) ?> and avg pending <?= e(money_fmt($avg_pending)) ?></div>
        </div>
      </div>
    </div>

    <div class="dash-surface p-3 mb-3">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h5 class="dash-section-title">
          <span class="ico"><?= ui_icon('grid') ?></span>
          <span>Status distribution</span>
        </h5>
        <span class="dash-pill"><?= ui_icon('money') ?> <span class="dash-muted">Collection</span> <strong><?= e((string)$collect_pct) ?>%</strong></span>
      </div>

      <div class="dash-divider"></div>

      <div class="meter">
        <div class="dash-kpi">
          <div class="dash-kpi-label">Paid</div>
          <div class="dash-kpi-val"><?= e((string)$c_paid) ?> <span class="dash-sub2">(<?= e((string)$paid_pct) ?>%)</span></div>
          <div class="dash-sub2">Completed payments</div>
        </div>
        <div class="dash-kpi">
          <div class="dash-kpi-label">Partial</div>
          <div class="dash-kpi-val"><?= e((string)$c_partial) ?> <span class="dash-sub2">(<?= e((string)$partial_pct) ?>%)</span></div>
          <div class="dash-sub2">Needs balance follow up</div>
        </div>
        <div class="dash-kpi">
          <div class="dash-kpi-label">Pending</div>
          <div class="dash-kpi-val"><?= e((string)$c_pending) ?> <span class="dash-sub2">(<?= e((string)$pending_pct) ?>%)</span></div>
          <div class="dash-sub2">Not paid yet</div>
        </div>
      </div>

      <div class="dash-divider"></div>

      <div class="mt-2">
        <div class="d-flex justify-content-between dash-sub">
          <span>Paid vs pending (company share)</span>
          <span>Paid <?= e((string)$paid_pct_of_sh) ?>% and pending <?= e((string)$pending_pct_of_sh) ?>%</span>
        </div>
        <div class="progress mt-1">
          <div class="progress-bar" role="progressbar" style="width: <?= e((string)$paid_pct_of_sh) ?>%"></div>
        </div>
      </div>
    </div>

    <div class="dash-surface p-3 mb-3">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h5 class="dash-section-title">
          <span class="ico"><?= ui_icon('trend') ?></span>
          <span>Fee trend</span>
        </h5>
        <span class="mini-note">Bars are relative within the selected period</span>
      </div>

      <div class="dash-divider"></div>

      <?php if (!$trend_slice): ?>
        <div class="text-secondary">No trend data yet. Add more tuition rows with different dates.</div>
      <?php else: ?>
        <div class="mini-bars">
          <?php foreach ($trend_slice as $d): ?>
            <?php
              $v = (int)($trend_days[$d] ?? 0);
              $h = (int) round(($v / $max_fee_day) * 100);
              $h = clamp_int($h, 6, 100);
            ?>
            <div class="bar" title="<?= e($d) ?> | Fee <?= e(money_fmt($v)) ?>">
              <span style="height: <?= e((string)$h) ?>%;"></span>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="dash-divider"></div>

        <div class="d-flex flex-wrap gap-2 align-items-center">
          <span class="dash-pill"><span class="dash-muted">Best day</span> <strong><?= e($best_day['d'] ?: '-') ?></strong> <span class="dash-muted">Fee</span> <strong><?= e(money_fmt($best_day['fee'])) ?></strong></span>
          <span class="dash-pill"><span class="dash-muted">Worst day</span> <strong><?= e($worst_day['d'] ?: '-') ?></strong> <span class="dash-muted">Fee</span> <strong><?= e(money_fmt($worst_day['fee'])) ?></strong></span>
          <?php if (count($zero_fee_days) > 0): ?>
            <span class="dash-pill"><?= ui_icon('alert') ?> <span class="dash-muted">Zero fee days</span> <strong><?= e((string)count($zero_fee_days)) ?></strong></span>
          <?php endif; ?>
        </div>
      <?php endif; ?>
    </div>

    <div class="row g-3">
      <div class="col-lg-6">
        <div class="dash-table">
          <div class="p-3 d-flex justify-content-between align-items-center">
            <h5 class="dash-section-title">
              <span class="ico"><?= ui_icon('users') ?></span>
              <span>Top student cities</span>
            </h5>
            <span class="dash-pill"><?= e((string)count($city_students)) ?> cities</span>
          </div>
          <div class="table-responsive">
            <table class="table table-dark table-hover align-middle">
              <thead><tr><th>City</th><th class="text-end">Students</th></tr></thead>
              <tbody>
                <?php foreach ($city_students as $x): ?>
                  <tr><td><?= e((string)$x['city']) ?></td><td class="text-end"><?= e((string)$x['cnt']) ?></td></tr>
                <?php endforeach; ?>
                <?php if (!$city_students): ?><tr><td colspan="2" class="text-center text-secondary">No data</td></tr><?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="dash-table">
          <div class="p-3 d-flex justify-content-between align-items-center">
            <h5 class="dash-section-title">
              <span class="ico"><?= ui_icon('teacher') ?></span>
              <span>Top teacher cities</span>
            </h5>
            <span class="dash-pill"><?= e((string)count($city_teachers)) ?> cities</span>
          </div>
          <div class="table-responsive">
            <table class="table table-dark table-hover align-middle">
              <thead><tr><th>City</th><th class="text-end">Teachers</th></tr></thead>
              <tbody>
                <?php foreach ($city_teachers as $x): ?>
                  <tr><td><?= e((string)$x['city']) ?></td><td class="text-end"><?= e((string)$x['cnt']) ?></td></tr>
                <?php endforeach; ?>
                <?php if (!$city_teachers): ?><tr><td colspan="2" class="text-center text-secondary">No data</td></tr><?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($tab === 'finance'): ?>
    <?php
      [$c1,$t1] = delta_style($delta_fee);
      [$c2,$t2] = delta_style($delta_share);
      [$c3,$t3] = delta_style($delta_paid);
      [$c4,$t4] = delta_style($delta_pending);
    ?>

    <div class="row g-3 mb-3">
      <div class="col-lg-8">
        <div class="dash-surface p-3 h-100">
          <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="dash-section-title">
              <span class="ico"><?= ui_icon('money') ?></span>
              <span>Period finance</span>
            </h5>
            <span class="dash-pill"><?= ui_icon('trend') ?> <span class="dash-muted">Rows</span> <strong><?= e((string)$period_rows_cnt) ?></strong></span>
          </div>

          <div class="dash-divider"></div>

          <div class="row g-2">
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Fee total</div>
                <div class="dash-kpi-val"><?= e(money_fmt($fee_total)) ?></div>
                <div class="dash-sub2">Total fee inside selected period</div>
              </div>
            </div>
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Company share total</div>
                <div class="dash-kpi-val"><?= e(money_fmt($share_total)) ?></div>
                <div class="dash-sub2">Company share accumulated</div>
              </div>
            </div>
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Paid to company</div>
                <div class="dash-kpi-val"><?= e(money_fmt($paid_total)) ?></div>
                <div class="dash-sub2">Money received by company</div>
              </div>
            </div>
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Pending to company</div>
                <div class="dash-kpi-val"><?= e(money_fmt($pending_total)) ?></div>
                <div class="dash-sub2">Money still pending</div>
              </div>
            </div>
          </div>

          <div class="dash-divider"></div>

          <div class="mt-2">
            <div class="d-flex justify-content-between dash-sub">
              <span>Collection rate</span>
              <span><strong><?= e((string)$collect_pct) ?>%</strong></span>
            </div>
            <div class="progress mt-1">
              <div class="progress-bar" role="progressbar" style="width: <?= e((string)$collect_pct) ?>%"></div>
            </div>
            <div class="dash-sub2 mt-2">Lower collection means follow ups are needed.</div>
          </div>

          <div class="dash-divider"></div>

          <div class="row g-2">
            <div class="col-md-4">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Share percent of fee</div>
                <div class="dash-kpi-val"><?= e((string)$share_pct_of_fee) ?>%</div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Paid percent of share</div>
                <div class="dash-kpi-val"><?= e((string)$paid_pct_of_sh) ?>%</div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Pending percent of share</div>
                <div class="dash-kpi-val"><?= e((string)$pending_pct_of_sh) ?>%</div>
              </div>
            </div>
          </div>

          <div class="dash-divider"></div>

          <h6 class="dash-title mb-2">Last month comparison</h6>
          <div class="row g-2">
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Fee change</div>
                <div class="dash-kpi-val"><span class="<?= e($c1) ?>"><?= e($t1) ?></span></div>
              </div>
            </div>
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Share change</div>
                <div class="dash-kpi-val"><span class="<?= e($c2) ?>"><?= e($t2) ?></span></div>
              </div>
            </div>
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Paid change</div>
                <div class="dash-kpi-val"><span class="<?= e($c3) ?>"><?= e($t3) ?></span></div>
              </div>
            </div>
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Pending change</div>
                <div class="dash-kpi-val"><span class="<?= e($c4) ?>"><?= e($t4) ?></span></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-4">
        <div class="dash-surface p-3 h-100">
          <h5 class="dash-section-title">
            <span class="ico"><?= ui_icon('teacher') ?></span>
            <span>Top teachers by share</span>
          </h5>

          <div class="dash-divider"></div>

          <div class="dash-table mb-3">
            <div class="table-responsive">
              <table class="table table-dark table-hover align-middle">
                <thead><tr><th>Teacher</th><th class="text-end">Share</th><th class="text-end">Open</th></tr></thead>
                <tbody>
                  <?php foreach ($top_share_teachers as $x): ?>
                    <tr>
                      <td><?= e((string)$x['name']) ?></td>
                      <td class="text-end"><?= e(money_fmt($x['share_sum'])) ?></td>
                      <td class="text-end">
                        <a class="btn btn-sm btn-outline-light" href="<?= e(url('teacher_view.php?id='.(int)$x['id'])) ?>">Open</a>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                  <?php if (!$top_share_teachers): ?><tr><td colspan="3" class="text-center text-secondary">No data</td></tr><?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <h5 class="dash-section-title">
            <span class="ico"><?= ui_icon('users') ?></span>
            <span>Top students by fee</span>
          </h5>

          <div class="dash-divider"></div>

          <div class="dash-table mb-3">
            <div class="table-responsive">
              <table class="table table-dark table-hover align-middle">
                <thead><tr><th>Student</th><th class="text-end">Fee</th><th class="text-end">Open</th></tr></thead>
                <tbody>
                  <?php foreach ($top_students_fee as $x): ?>
                    <tr>
                      <td><?= e((string)$x['name']) ?></td>
                      <td class="text-end"><?= e(money_fmt($x['fee_sum'])) ?></td>
                      <td class="text-end">
                        <a class="btn btn-sm btn-outline-light" href="<?= e(url('student_view.php?id='.(int)$x['id'])) ?>">Open</a>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                  <?php if (!$top_students_fee): ?><tr><td colspan="3" class="text-center text-secondary">No data</td></tr><?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <a class="btn btn-outline-light w-100" href="<?= e(url('reports.php')) ?>?from=<?= e($period_start) ?>&to=<?= e($period_end) ?>">
            Open reports for this period
          </a>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($tab === 'risks'): ?>
    <div class="row g-3 mb-3">
      <div class="col-lg-6">
        <div class="dash-surface p-3 h-100">
          <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="dash-section-title">
              <span class="ico"><?= ui_icon('alert') ?></span>
              <span>Highest pending tuitions</span>
            </h5>
            <span class="dash-pill">Rows <strong><?= e((string)$high_pending_count) ?></strong></span>
          </div>

          <div class="dash-divider"></div>

          <div class="dash-table">
            <div class="table-responsive">
              <table class="table table-dark table-hover align-middle">
                <thead><tr><th>ID</th><th>Date</th><th>Student</th><th>Teacher</th><th class="text-end">Pending</th><th>Status</th><th class="text-end">Reports</th></tr></thead>
                <tbody>
                  <?php foreach ($risk_pending_rows as $r): ?>
                    <tr>
                      <td><?= e((string)$r['id']) ?></td>
                      <td><?= e((string)$r['tuition_date']) ?></td>
                      <td><?= e((string)$r['student_name']) ?></td>
                      <td><?= e((string)$r['teacher_name']) ?></td>
                      <td class="text-end"><?= e(money_fmt($r['pending_to_company'])) ?></td>
                      <td>
                        <?php $badge = badge_for_status((string)$r['status']); ?>
                        <?= ui_badge((string)$r['status'], $badge) ?>
                      </td>
                      <td class="text-end">
                        <a class="btn btn-sm btn-outline-light" href="<?= e(url('reports.php')) ?>?from=<?= e($period_start) ?>&to=<?= e($period_end) ?>">Open</a>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                  <?php if (!$risk_pending_rows): ?><tr><td colspan="7" class="text-center text-secondary">No pending rows</td></tr><?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <div class="dash-sub2 mt-2">These rows usually need payment follow up or correction.</div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="dash-surface p-3 h-100">
          <h5 class="dash-section-title">
            <span class="ico"><?= ui_icon('teacher') ?></span>
            <span>Top teachers by pending</span>
          </h5>

          <div class="dash-divider"></div>

          <div class="dash-table">
            <div class="table-responsive">
              <table class="table table-dark table-hover align-middle">
                <thead><tr><th>Teacher</th><th class="text-end">Pending</th><th class="text-end">Share percent</th><th class="text-end">Open</th></tr></thead>
                <tbody>
                  <?php foreach ($top_pending_teachers as $x): ?>
                    <?php
                      $pending = (int)($x['pending_sum'] ?? 0);
                      $sharepct = pct_int($pending, max(1, $share_total));
                    ?>
                    <tr>
                      <td><?= e((string)$x['name']) ?></td>
                      <td class="text-end"><?= e(money_fmt($pending)) ?></td>
                      <td class="text-end"><?= e((string)$sharepct) ?>%</td>
                      <td class="text-end">
                        <a class="btn btn-sm btn-outline-light" href="<?= e(url('teacher_view.php?id='.(int)$x['id'])) ?>">Open</a>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                  <?php if (!$top_pending_teachers): ?><tr><td colspan="4" class="text-center text-secondary">No data</td></tr><?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <div class="dash-sub2 mt-2">If one teacher has high pending, check fee collection and update paid amounts.</div>
        </div>
      </div>
    </div>

    <?php if (count($zero_fee_days) > 0): ?>
      <div class="dash-surface p-3">
        <h5 class="dash-section-title">
          <span class="ico"><?= ui_icon('alert') ?></span>
          <span>Zero fee days inside period</span>
        </h5>
        <div class="dash-sub2 mt-2">These dates have total fee = 0. Usually missing entries or no classes.</div>

        <div class="dash-divider"></div>

        <div class="chip-row">
          <?php foreach (array_slice($zero_fee_days, 0, 20) as $d): ?>
            <span class="chip"><?= e($d) ?></span>
          <?php endforeach; ?>
          <?php if (count($zero_fee_days) > 20): ?>
            <span class="chip">+<?= e((string)(count($zero_fee_days) - 20)) ?> more</span>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  <?php endif; ?>

  <?php if ($tab === 'health'): ?>
    <div class="row g-3 mb-3">
      <div class="col-lg-6">
        <div class="dash-surface p-3 h-100">
          <h5 class="dash-section-title">
            <span class="ico"><?= ui_icon('file') ?></span>
            <span>Health summary</span>
          </h5>

          <div class="dash-divider"></div>

          <div class="row g-2">
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Teachers missing docs</div>
                <div class="dash-kpi-val"><?= e((string)$teachers_missing_docs) ?></div>
              </div>
            </div>
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Teachers missing phone</div>
                <div class="dash-kpi-val"><?= e((string)$teachers_missing_phone) ?></div>
              </div>
            </div>
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Students missing phone</div>
                <div class="dash-kpi-val"><?= e((string)$students_missing_phone) ?></div>
              </div>
            </div>
            <div class="col-6">
              <div class="dash-kpi">
                <div class="dash-kpi-label">Students missing location link</div>
                <div class="dash-kpi-val"><?= e((string)$students_missing_location_link) ?></div>
              </div>
            </div>
          </div>

          <div class="dash-divider"></div>

          <div class="dash-sub2">Cleaner data means fewer errors and more reliable reports.</div>

          <div class="d-grid d-sm-flex gap-2 mt-3">
            <a class="btn btn-outline-light flex-fill" href="<?= e(url('teachers.php')) ?>">Fix teachers</a>
            <a class="btn btn-outline-light flex-fill" href="<?= e(url('students.php')) ?>">Fix students</a>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="dash-surface p-3 h-100">
          <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h5 class="dash-section-title">
              <span class="ico"><?= ui_icon('teacher') ?></span>
              <span>Teachers missing docs</span>
            </h5>
            <span class="dash-pill"><?= e((string)count($teachers_missing_docs_list)) ?> shown</span>
          </div>

          <div class="dash-divider"></div>

          <div class="dash-table">
            <div class="table-responsive">
              <table class="table table-dark table-hover align-middle">
                <thead><tr><th>ID</th><th>Reg</th><th>Name</th><th>City</th><th>ID file</th><th>Doc file</th><th class="text-end">Open</th></tr></thead>
                <tbody>
                  <?php foreach ($teachers_missing_docs_list as $t): ?>
                    <tr>
                      <td><?= e((string)$t['id']) ?></td>
                      <td><?= e((string)($t['reg_no'] ?? '')) ?></td>
                      <td><?= e((string)$t['name']) ?></td>
                      <td><?= e((string)($t['city'] ?? '')) ?></td>
                      <td><?= ($t['teacher_id_file'] ? ui_badge('OK','success') : ui_badge('Missing','secondary')) ?></td>
                      <td><?= ($t['teacher_doc_file'] ? ui_badge('OK','success') : ui_badge('Missing','secondary')) ?></td>
                      <td class="text-end">
                        <a class="btn btn-sm btn-outline-light" href="<?= e(url('teacher_view.php?id='.(int)$t['id'])) ?>">Open</a>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                  <?php if (!$teachers_missing_docs_list): ?><tr><td colspan="7" class="text-center text-secondary">No missing docs</td></tr><?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <div class="mt-3">
            <a class="btn btn-outline-light w-100" href="<?= e(url('teachers.php')) ?>">
              Open teachers to upload missing files
            </a>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($tab === 'activity'): ?>
    <div class="dash-surface p-3 mb-3">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h5 class="dash-section-title">
          <span class="ico"><?= ui_icon('money') ?></span>
          <span>Recent tuitions (period)</span>
        </h5>
        <a class="btn btn-sm btn-outline-light" href="<?= e(url('tuitions.php')) ?>">Open</a>
      </div>

      <div class="dash-divider"></div>

      <div class="dash-table">
        <div class="table-responsive">
          <table class="table table-dark table-hover align-middle">
            <thead>
              <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Student</th>
                <th>Teacher</th>
                <th class="text-end">Fee</th>
                <th class="text-end">Company</th>
                <th class="text-end">Paid</th>
                <th class="text-end">Pending</th>
                <th>Status</th>
                <th class="text-end">Edit</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recent_tuitions as $r): ?>
                <tr>
                  <td><?= e((string)$r['id']) ?></td>
                  <td><?= e((string)$r['tuition_date']) ?></td>
                  <td>
                    <a class="link-light" href="<?= e(url('student_view.php?id='.(int)$r['student_id'])) ?>">
                      <?= e((string)$r['student_name']) ?>
                    </a>
                  </td>
                  <td>
                    <a class="link-light" href="<?= e(url('teacher_view.php?id='.(int)$r['teacher_id'])) ?>">
                      <?= e((string)$r['teacher_name']) ?>
                    </a>
                  </td>
                  <td class="text-end"><?= e(money_fmt($r['monthly_fee'])) ?></td>
                  <td class="text-end"><?= e(money_fmt($r['company_share_amount'])) ?></td>
                  <td class="text-end"><?= e(money_fmt($r['paid_to_company'])) ?></td>
                  <td class="text-end"><?= e(money_fmt($r['pending_to_company'])) ?></td>
                  <td>
                    <?php $badge = badge_for_status((string)$r['status']); ?>
                    <?= ui_badge((string)$r['status'], $badge) ?>
                  </td>
                  <td class="text-end">
                    <a class="btn btn-sm btn-outline-light" href="<?= e(url('tuition_form.php?id='.(int)$r['id'])) ?>">Edit</a>
                  </td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$recent_tuitions): ?>
                <tr><td colspan="10" class="text-center text-secondary">No recent tuitions</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="dash-surface p-3">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h5 class="dash-section-title">
          <span class="ico"><?= ui_icon('trend') ?></span>
          <span>Recent activity log</span>
        </h5>
        <span class="dash-sub2">Shows who changed what</span>
      </div>

      <div class="dash-divider"></div>

      <div class="dash-table">
        <div class="table-responsive">
          <table class="table table-dark table-hover align-middle">
            <thead>
              <tr>
                <th>When</th>
                <th>Time</th>
                <th>User</th>
                <th>Action</th>
                <th>Entity</th>
                <th>ID</th>
                <th>Details</th>
                <th>IP</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recent_logs as $x): ?>
                <tr>
                  <td><?= e(human_when($x['created_at'])) ?></td>
                  <td><?= e((string)$x['created_at']) ?></td>
                  <td><?= e((string)($x['user_name'] ?? 'Unknown')) ?></td>
                  <td><?= e((string)$x['action']) ?></td>
                  <td><?= e((string)$x['entity']) ?></td>
                  <td><?= e((string)$x['entity_id']) ?></td>
                  <td><?= e((string)($x['details'] ?? '')) ?></td>
                  <td><?= e((string)($x['ip'] ?? '')) ?></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$recent_logs): ?>
                <tr><td colspan="8" class="text-center text-secondary">No activity yet</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  <?php endif; ?>

</div>

<?php require __DIR__ . '/_layout_bottom.php'; ?>
<!-- Shrink sticky header on scroll -->
<script>
  (function () {
    const el = document.getElementById('dashSticky');
    if (!el) return;

    const threshold = 40; // pixels to start shrinking

    const onScroll = () => {
      if (window.scrollY > threshold) {
        el.classList.add('shrink');
      } else {
        el.classList.remove('shrink');
      }
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  })();
</script>

<?php require __DIR__ . '/_layout_bottom.php'; ?>
