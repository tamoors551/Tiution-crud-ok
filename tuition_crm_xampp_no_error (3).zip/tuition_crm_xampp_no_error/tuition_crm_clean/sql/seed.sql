CREATE DATABASE IF NOT EXISTS tuition_crm
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE tuition_crm;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(190) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','staff') NOT NULL DEFAULT 'staff',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS students (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  record_date DATE NOT NULL,
  reg_no VARCHAR(50) UNIQUE NULL,
  name VARCHAR(190) NOT NULL,
  phoneno VARCHAR(30) NULL,
  school_name VARCHAR(150) NULL,
  class VARCHAR(50) NOT NULL,
  subjects VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL,
  home_address VARCHAR(255) NULL,
  fee_range VARCHAR(80) NULL,
  location VARCHAR(190) NULL,
  location_link VARCHAR(255) NULL,
  mode ENUM('online','home') NOT NULL,
  device ENUM('laptop','mobile') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS teachers (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  record_date DATE NOT NULL,
  reg_no VARCHAR(50) UNIQUE NULL,
  name VARCHAR(190) NOT NULL,
  phoneno VARCHAR(30) NULL,
  email VARCHAR(190) NULL,
  qualification VARCHAR(190) NULL,
  experience_years TINYINT UNSIGNED NULL,
  subjects VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL,
  home_address VARCHAR(255) NULL,
  fee_range VARCHAR(80) NULL,
  availability VARCHAR(190) NULL,
  mode ENUM('online','home') NOT NULL,
  device ENUM('laptop','mobile') NOT NULL,
  teacher_id_file VARCHAR(255) NULL,
  teacher_doc_file VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO users (name, email, password_hash, role)
VALUES ('Admin', 'admin@local.test', '$2y$10$7GroDbYZcDvffWKpHsZ.Beo7a73CW9fJq/lnjKBpLwmTY9Ul2cMG.', 'admin')
ON DUPLICATE KEY UPDATE email=email;



/* =====================================================================
   1) SQL: /sql/tuition_crud.sql  (RUN ONCE)
   =====================================================================
*/
CREATE TABLE IF NOT EXISTS tuitions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_id INT UNSIGNED NOT NULL,
  amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  fee_month DATE NULL,                 -- store first day of month (e.g. 2025-12-01)
  paid_on DATE NULL,
  method VARCHAR(50) NULL,             -- cash/bank/jazzcash/easypaisa/etc
  notes VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_student (student_id),
  INDEX idx_paid_on (paid_on),
  CONSTRAINT fk_tuitions_student
    FOREIGN KEY (student_id) REFERENCES students(id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/* ==========================================================
   Tuition Seed Data
   ========================================================== */

INSERT INTO tuitions
(
  tuition_date,
  student_id,
  teacher_id,
  monthly_fee,
  company_share_percent,
  company_share_amount,
  paid_to_company,
  pending_to_company,
  status,
  notes
)
VALUES
-- Fully Paid
(
  '2025-01-01',
  1,
  1,
  5000,
  30,
  1500,
  1500,
  0,
  'Paid',
  'January tuition fully paid'
),

-- Partial Payment
(
  '2025-01-01',
  2,
  1,
  6000,
  25,
  1500,
  800,
  700,
  'Partial',
  'Partial payment received'
),

-- Pending
(
  '2025-01-01',
  3,
  2,
  4000,
  20,
  800,
  0,
  800,
  'Pending',
  'Payment not yet received'
),

-- February – Paid
(
  '2025-02-01',
  1,
  1,
  5000,
  30,
  1500,
  1500,
  0,
  'Paid',
  'February tuition paid on time'
),

-- February – Partial
(
  '2025-02-01',
  2,
  2,
  6000,
  25,
  1500,
  1000,
  500,
  'Partial',
  'Advance paid, balance pending'
),

-- February – Pending
(
  '2025-02-01',
  3,
  3,
  4500,
  20,
  900,
  0,
  900,
  'Pending',
  'Awaiting payment'
);


