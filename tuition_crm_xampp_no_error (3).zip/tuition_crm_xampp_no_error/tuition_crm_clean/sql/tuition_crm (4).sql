-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2025 at 07:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tuition_crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `action` enum('create','update','delete') NOT NULL,
  `entity` enum('student','teacher') NOT NULL,
  `entity_id` int(10) UNSIGNED NOT NULL,
  `details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `created_at`, `user_id`, `ip`, `action`, `entity`, `entity_id`, `details`) VALUES
(1, '2025-12-21 11:45:47', 1, '127.0.0.1', 'create', 'student', 1, 'Student created'),
(2, '2025-12-21 11:45:47', 1, '127.0.0.1', 'create', 'teacher', 1, 'Teacher created'),
(3, '2025-12-21 11:45:47', 2, '127.0.0.1', 'update', 'student', 2, 'Phone updated'),
(4, '2025-12-21 11:45:47', 2, '127.0.0.1', 'update', 'teacher', 2, 'Availability changed'),
(5, '2025-12-21 11:45:47', 3, '127.0.0.1', 'delete', 'student', 3, 'Duplicate record'),
(6, '2025-12-21 11:45:47', 3, '127.0.0.1', 'create', 'student', 4, 'New admission'),
(7, '2025-12-21 11:45:47', 4, '127.0.0.1', 'create', 'teacher', 3, 'New teacher onboarded'),
(8, '2025-12-21 11:45:47', 4, '127.0.0.1', 'update', 'student', 5, 'Fee updated'),
(9, '2025-12-21 11:45:47', 5, '127.0.0.1', 'update', 'teacher', 4, 'Experience corrected'),
(10, '2025-12-21 11:45:47', 5, '127.0.0.1', 'create', 'student', 6, 'New student'),
(11, '2025-12-21 11:45:47', 6, '127.0.0.1', 'update', 'student', 7, 'Class updated'),
(12, '2025-12-21 11:45:47', 6, '127.0.0.1', 'create', 'teacher', 5, 'Teacher added'),
(13, '2025-12-21 11:45:47', 7, '127.0.0.1', 'update', 'teacher', 6, 'Mode changed'),
(14, '2025-12-21 11:45:47', 7, '127.0.0.1', 'delete', 'teacher', 7, 'Left platform'),
(15, '2025-12-21 11:45:47', 8, '127.0.0.1', 'create', 'student', 8, 'New enrollment'),
(16, '2025-12-21 11:45:47', 8, '127.0.0.1', 'update', 'student', 9, 'Subjects updated'),
(17, '2025-12-21 11:45:47', 9, '127.0.0.1', 'create', 'teacher', 8, 'Teacher joined'),
(18, '2025-12-21 11:45:47', 9, '127.0.0.1', 'update', 'teacher', 9, 'Fee range updated'),
(19, '2025-12-21 11:45:47', 10, '127.0.0.1', 'create', 'student', 10, 'Student registered'),
(20, '2025-12-21 11:45:47', 10, '127.0.0.1', 'update', 'student', 11, 'Address corrected');

-- --------------------------------------------------------

--
-- Table structure for table `saved_reports`
--

CREATE TABLE `saved_reports` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `filters` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(10) UNSIGNED NOT NULL,
  `record_date` date NOT NULL,
  `reg_no` varchar(50) DEFAULT NULL,
  `name` varchar(190) NOT NULL,
  `phoneno` varchar(30) DEFAULT NULL,
  `school_name` varchar(150) DEFAULT NULL,
  `class` varchar(50) NOT NULL,
  `subjects` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `home_address` varchar(255) DEFAULT NULL,
  `fee_range` varchar(80) DEFAULT NULL,
  `location` varchar(190) DEFAULT NULL,
  `location_link` varchar(255) DEFAULT NULL,
  `mode` enum('online','home') NOT NULL,
  `device` enum('laptop','mobile') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `record_date`, `reg_no`, `name`, `phoneno`, `school_name`, `class`, `subjects`, `city`, `home_address`, `fee_range`, `location`, `location_link`, `mode`, `device`, `created_at`) VALUES
(1, '2025-12-01', 'STU-001', 'Ali Hassan', '0301000001', 'Beaconhouse', 'O Level', 'Math,Physics', 'Islamabad', 'G-11', '15000-20000', 'G-11', 'https://maps.google.com?q=G-11', 'home', 'laptop', '2025-12-21 11:45:47'),
(2, '2025-12-02', 'STU-002', 'Ahmed Raza', '0301000002', 'Roots', 'A Level', 'Chemistry', 'Rawalpindi', 'Saddar', '18000-25000', 'Saddar', 'https://maps.google.com?q=Saddar', 'online', 'laptop', '2025-12-21 11:45:47'),
(3, '2025-12-03', 'STU-003', 'Sara Khan', '0301000003', 'APS', 'Class 9', 'Biology', 'Islamabad', 'G-9', '12000-15000', 'G-9', 'https://maps.google.com?q=G-9', 'home', 'mobile', '2025-12-21 11:45:47'),
(4, '2025-12-04', 'STU-004', 'Bilal Ahmad', '0301000004', 'City School', 'Class 8', 'Science', 'Lahore', 'Model Town', '10000-14000', 'Model Town', 'https://maps.google.com?q=Model+Town', 'home', 'laptop', '2025-12-21 11:45:47'),
(5, '2025-12-05', 'STU-005', 'Ayesha Malik', '0301000005', 'Roots', 'O Level', 'Math', 'Rawalpindi', 'Bahria', '16000-22000', 'Bahria', 'https://maps.google.com?q=Bahria', 'online', 'laptop', '2025-12-21 11:45:47'),
(6, '2025-12-06', 'STU-006', 'Usman Ali', '0301000006', 'Beaconhouse', 'A Level', 'Physics', 'Islamabad', 'G-10', '18000-26000', 'G-10', 'https://maps.google.com?q=G-10', 'home', 'laptop', '2025-12-21 11:45:47'),
(7, '2025-12-07', 'STU-007', 'Hira Noor', '0301000007', 'APS', 'Class 7', 'Math', 'Islamabad', 'I-8', '9000-12000', 'I-8', 'https://maps.google.com?q=I-8', 'home', 'mobile', '2025-12-21 11:45:47'),
(8, '2025-12-08', 'STU-008', 'Zain Sheikh', '0301000008', 'City School', 'Class 6', 'Science', 'Rawalpindi', 'Satellite', '8000-11000', 'Satellite', 'https://maps.google.com?q=Satellite', 'home', 'mobile', '2025-12-21 11:45:47'),
(9, '2025-12-09', 'STU-009', 'Maryam Iqbal', '0301000009', 'Beaconhouse', 'O Level', 'Biology', 'Islamabad', 'F-10', '15000-20000', 'F-10', 'https://maps.google.com?q=F-10', 'online', 'laptop', '2025-12-21 11:45:47'),
(10, '2025-12-10', 'STU-010', 'Hamza Khan', '0301000010', 'Roots', 'A Level', 'Chemistry', 'Lahore', 'DHA', '20000-30000', 'DHA', 'https://maps.google.com?q=DHA', 'home', 'laptop', '2025-12-21 11:45:47'),
(11, '2025-12-11', 'STU-011', 'Noor Fatima', '0301000011', 'APS', 'Class 10', 'Physics', 'Islamabad', 'G-13', '13000-18000', 'G-13', 'https://maps.google.com?q=G-13', 'home', 'laptop', '2025-12-21 11:45:47'),
(12, '2025-12-12', 'STU-012', 'Taha Raza', '0301000012', 'City School', 'Class 9', 'Math', 'Rawalpindi', 'Pindi', '12000-17000', 'Pindi', 'https://maps.google.com?q=Pindi', 'online', 'mobile', '2025-12-21 11:45:47'),
(13, '2025-12-13', 'STU-013', 'Laiba Tariq', '0301000013', 'Roots', 'O Level', 'Chemistry', 'Islamabad', 'E-11', '17000-23000', 'E-11', 'https://maps.google.com?q=E-11', 'home', 'laptop', '2025-12-21 11:45:47'),
(14, '2025-12-14', 'STU-014', 'Saad Ahmed', '0301000014', 'Beaconhouse', 'A Level', 'Math', 'Islamabad', 'F-8', '20000-28000', 'F-8', 'https://maps.google.com?q=F-8', 'online', 'laptop', '2025-12-21 11:45:47'),
(15, '2025-12-15', 'STU-015', 'Iqra Ali', '0301000015', 'APS', 'Class 8', 'Science', 'Rawalpindi', 'Westridge', '9000-13000', 'Westridge', 'https://maps.google.com?q=Westridge', 'home', 'mobile', '2025-12-21 11:45:47'),
(16, '2025-12-16', 'STU-016', 'Fahad Mehmood', '0301000016', 'City School', 'Class 7', 'Math', 'Lahore', 'Johar', '10000-15000', 'Johar', 'https://maps.google.com?q=Johar', 'home', 'mobile', '2025-12-21 11:45:47'),
(17, '2025-12-17', 'STU-017', 'Sana Yousaf', '0301000017', 'Roots', 'O Level', 'Physics', 'Islamabad', 'H-13', '16000-21000', 'H-13', 'https://maps.google.com?q=H-13', 'online', 'laptop', '2025-12-21 11:45:47'),
(18, '2025-12-18', 'STU-018', 'Umer Farooq', '0301000018', 'Beaconhouse', 'A Level', 'Chemistry', 'Rawalpindi', 'Bahria', '22000-30000', 'Bahria', 'https://maps.google.com?q=Bahria', 'home', 'laptop', '2025-12-21 11:45:47');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(10) UNSIGNED NOT NULL,
  `record_date` date NOT NULL,
  `reg_no` varchar(50) DEFAULT NULL,
  `name` varchar(190) NOT NULL,
  `phoneno` varchar(30) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `qualification` varchar(190) DEFAULT NULL,
  `experience_years` tinyint(3) UNSIGNED DEFAULT NULL,
  `subjects` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `home_address` varchar(255) DEFAULT NULL,
  `fee_range` varchar(80) DEFAULT NULL,
  `availability` varchar(190) DEFAULT NULL,
  `mode` enum('online','home') NOT NULL,
  `device` enum('laptop','mobile') NOT NULL,
  `teacher_id_file` varchar(255) DEFAULT NULL,
  `teacher_doc_file` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `record_date`, `reg_no`, `name`, `phoneno`, `email`, `qualification`, `experience_years`, `subjects`, `city`, `home_address`, `fee_range`, `availability`, `mode`, `device`, `teacher_id_file`, `teacher_doc_file`, `created_at`, `deleted_at`) VALUES
(1, '2025-12-01', 'TCH-001', 'Muhammad Asif', '0302000001', 'asif@gmail.com', 'MSc Physics', 6, 'Physics,Math', 'Islamabad', 'G-10', '20000-30000', 'Evening', 'home', 'laptop', 'id1.pdf', 'doc1.pdf', '2025-12-21 11:45:47', NULL),
(2, '2025-12-02', 'TCH-002', 'Sara Ahmed', '0302000002', 'sara@gmail.com', 'MPhil Chemistry', 4, 'Chemistry', 'Rawalpindi', 'Bahria', '18000-25000', 'Weekend', 'online', 'laptop', 'id2.pdf', 'doc2.pdf', '2025-12-21 11:45:47', NULL),
(3, '2025-12-03', 'TCH-003', 'Bilal Mehmood', '0302000003', 'bilal@gmail.com', 'BS Math', 2, 'Math', 'Lahore', 'Model Town', '12000-18000', 'Flexible', 'home', 'mobile', NULL, NULL, '2025-12-21 11:45:47', NULL),
(4, '2025-12-04', 'TCH-004', 'Ayesha Noor', '0302000004', 'ayesha@gmail.com', 'MSc Biology', 5, 'Biology', 'Islamabad', 'F-11', '18000-26000', 'Morning', 'home', 'laptop', NULL, NULL, '2025-12-21 11:45:47', NULL),
(5, '2025-12-05', 'TCH-005', 'Usman Tariq', '0302000005', 'usman@gmail.com', 'BS Physics', 3, 'Physics', 'Rawalpindi', 'Saddar', '15000-22000', 'Evening', 'online', 'laptop', NULL, NULL, '2025-12-21 11:45:47', NULL),
(6, '2025-12-06', 'TCH-006', 'Hira Ali', '0302000006', 'hira@gmail.com', 'MSc Math', 4, 'Math', 'Islamabad', 'I-8', '17000-23000', 'Morning', 'home', 'laptop', NULL, NULL, '2025-12-21 11:45:47', NULL),
(7, '2025-12-07', 'TCH-007', 'Zain Malik', '0302000007', 'zain@gmail.com', 'BS Chemistry', 2, 'Chemistry', 'Lahore', 'DHA', '14000-19000', 'Flexible', 'online', 'mobile', NULL, NULL, '2025-12-21 11:45:47', NULL),
(8, '2025-12-08', 'TCH-008', 'Noor Fatima', '0302000008', 'noor@gmail.com', 'MPhil Physics', 6, 'Physics', 'Islamabad', 'E-11', '22000-30000', 'Evening', 'home', 'laptop', NULL, NULL, '2025-12-21 11:45:47', NULL),
(9, '2025-12-09', 'TCH-009', 'Hamza Riaz', '0302000009', 'hamza@gmail.com', 'BS Math', 3, 'Math', 'Rawalpindi', 'Satellite', '13000-18000', 'Weekend', 'home', 'mobile', NULL, NULL, '2025-12-21 11:45:47', NULL),
(10, '2025-12-10', 'TCH-010', 'Laiba Shah', '0302000010', 'laiba@gmail.com', 'MSc Biology', 5, 'Biology', 'Islamabad', 'G-13', '18000-24000', 'Morning', 'online', 'laptop', NULL, NULL, '2025-12-21 11:45:47', NULL),
(11, '2025-12-11', 'TCH-011', 'Saad Khan', '0302000011', 'saad@gmail.com', 'BS Physics', 2, 'Physics', 'Lahore', 'Johar', '14000-19000', 'Flexible', 'home', 'mobile', NULL, NULL, '2025-12-21 11:45:47', NULL),
(12, '2025-12-12', 'TCH-012', 'Maham Raza', '0302000012', 'maham@gmail.com', 'MSc Chemistry', 4, 'Chemistry', 'Islamabad', 'H-13', '17000-23000', 'Evening', 'online', 'laptop', NULL, NULL, '2025-12-21 11:45:47', NULL),
(13, '2025-12-13', 'TCH-013', 'Umer Iqbal', '0302000013', 'umer@gmail.com', 'BS Math', 3, 'Math', 'Rawalpindi', 'Pindi', '13000-18000', 'Morning', 'home', 'mobile', NULL, NULL, '2025-12-21 11:45:47', NULL),
(14, '2025-12-14', 'TCH-014', 'Sana Yousaf', '0302000014', 'sana@gmail.com', 'MPhil Biology', 6, 'Biology', 'Islamabad', 'F-8', '22000-28000', 'Evening', 'home', 'laptop', NULL, NULL, '2025-12-21 11:45:47', NULL),
(15, '2025-12-15', 'TCH-015', 'Fahad Ali', '0302000015', 'fahad@gmail.com', 'BS Physics', 2, 'Physics', 'Lahore', 'Cantt', '14000-19000', 'Weekend', 'online', 'mobile', NULL, NULL, '2025-12-21 11:45:47', NULL),
(16, '2025-12-16', 'TCH-016', 'Maryam Sheikh', '0302000016', 'maryam@gmail.com', 'MSc Math', 5, 'Math', 'Islamabad', 'I-10', '18000-24000', 'Morning', 'home', 'laptop', NULL, NULL, '2025-12-21 11:45:47', NULL),
(17, '2025-12-17', 'TCH-017', 'Taha Ahmed', '0302000017', 'taha@gmail.com', 'BS Chemistry', 3, 'Chemistry', 'Rawalpindi', 'Bahria', '16000-21000', 'Flexible', 'online', 'laptop', NULL, NULL, '2025-12-21 11:45:47', NULL),
(18, '2025-12-18', 'TCH-018', 'Iqra Noor', '0302000018', 'iqra@gmail.com', 'MSc Biology', 4, 'Biology', 'Islamabad', 'G-11', '17000-22000', 'Evening', 'home', 'laptop', NULL, NULL, '2025-12-21 11:45:47', NULL),
(19, '2025-12-19', 'TCH-019', 'Shahzaib Khan', '0302000019', 'shahzaib@gmail.com', 'BS Math', 2, 'Math', 'Lahore', 'DHA', '13000-18000', 'Weekend', 'home', 'mobile', NULL, NULL, '2025-12-21 11:45:47', NULL),
(20, '2025-12-20', 'TCH-020', 'Adeel Raza', '0302000020', 'adeel@gmail.com', 'MPhil Physics', 7, 'Physics', 'Islamabad', 'F-10', '25000-35000', 'Evening', 'home', 'laptop', 'teacher_id/20251221_150322_193a525e92ed.pdf', 'teacher_docs/20251221_150322_37fc4c0901a7.pdf', '2025-12-21 11:45:47', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tuitions`
--

CREATE TABLE `tuitions` (
  `id` int(10) UNSIGNED NOT NULL,
  `tuition_date` date NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `teacher_id` int(10) UNSIGNED NOT NULL,
  `monthly_fee` int(11) NOT NULL,
  `company_share_percent` int(11) NOT NULL,
  `company_share_amount` int(11) NOT NULL,
  `paid_to_company` int(11) NOT NULL DEFAULT 0,
  `pending_to_company` int(11) NOT NULL DEFAULT 0,
  `status` enum('Pending','Partial','Paid') NOT NULL DEFAULT 'Pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tuitions`
--

INSERT INTO `tuitions` (`id`, `tuition_date`, `student_id`, `teacher_id`, `monthly_fee`, `company_share_percent`, `company_share_amount`, `paid_to_company`, `pending_to_company`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(21, '2025-12-01', 1, 1, 5000, 30, 1500, 1500, 0, 'Paid', 'January paid', '2025-12-21 11:50:34', NULL),
(22, '2025-12-02', 2, 2, 6000, 25, 1500, 1000, 500, 'Partial', 'Pending balance', '2025-12-21 11:50:34', NULL),
(23, '2025-12-03', 3, 3, 4000, 20, 800, 0, 800, 'Pending', 'Awaiting payment', '2025-12-21 11:50:34', NULL),
(24, '2025-12-04', 4, 4, 5500, 30, 1650, 1650, 0, 'Paid', '', '2025-12-21 11:50:34', NULL),
(25, '2025-12-05', 5, 5, 7000, 25, 1750, 1750, 0, 'Paid', '', '2025-12-21 11:50:34', NULL),
(26, '2025-12-06', 6, 6, 4500, 20, 900, 0, 900, 'Pending', '', '2025-12-21 11:50:34', NULL),
(27, '2025-12-07', 7, 7, 3500, 20, 700, 700, 0, 'Paid', '', '2025-12-21 11:50:34', NULL),
(28, '2025-12-08', 8, 8, 8000, 30, 2400, 1200, 1200, 'Partial', '', '2025-12-21 11:50:34', NULL),
(29, '2025-12-09', 9, 9, 5000, 25, 1250, 0, 1250, 'Pending', '', '2025-12-21 11:50:34', NULL),
(30, '2025-12-10', 10, 10, 9000, 30, 2700, 2700, 0, 'Paid', '', '2025-12-21 11:50:34', NULL),
(31, '2025-12-11', 11, 11, 6000, 20, 1200, 1200, 0, 'Paid', '', '2025-12-21 11:50:34', NULL),
(32, '2025-12-12', 12, 12, 5500, 25, 1375, 500, 875, 'Partial', '', '2025-12-21 11:50:34', NULL),
(33, '2025-12-13', 13, 13, 4500, 20, 900, 0, 900, 'Pending', '', '2025-12-21 11:50:34', NULL),
(34, '2025-12-14', 14, 14, 10000, 30, 3000, 3000, 0, 'Paid', '', '2025-12-21 11:50:34', NULL),
(35, '2025-12-15', 15, 15, 4800, 25, 1200, 1200, 0, 'Paid', '', '2025-12-21 11:50:34', NULL),
(36, '2025-12-16', 16, 16, 5200, 20, 1040, 0, 1040, 'Pending', '', '2025-12-21 11:50:34', NULL),
(37, '2025-12-17', 17, 17, 7500, 30, 2250, 1000, 1250, 'Partial', '', '2025-12-21 11:50:34', NULL),
(39, '2025-12-19', 19, 19, 4300, 20, 860, 0, 860, 'Pending', '', '2025-12-21 11:50:34', NULL),
(40, '2025-12-20', 20, 20, 12000, 30, 3600, 3600, 0, 'Paid', '', '2025-12-21 11:50:34', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(190) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','staff') NOT NULL DEFAULT 'staff',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `role`, `created_at`) VALUES
(1, 'Admin', 'admin@local.test', '$2y$10$wP0K6Y2q0Zy3pS3d7YpJ6e6xG5vYqKqP6gKq4qg8M2D4YH0bYqv6G', 'admin', '2025-12-21 11:45:47'),
(2, 'Staff One', 'staff1@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(3, 'Staff Two', 'staff2@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(4, 'Staff Three', 'staff3@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(5, 'Staff Four', 'staff4@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(6, 'Staff Five', 'staff5@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(7, 'Staff Six', 'staff6@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(8, 'Staff Seven', 'staff7@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(9, 'Staff Eight', 'staff8@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(10, 'Staff Nine', 'staff9@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(11, 'Staff Ten', 'staff10@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(12, 'Staff Eleven', 'staff11@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(13, 'Staff Twelve', 'staff12@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(14, 'Staff Thirteen', 'staff13@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(15, 'Staff Fourteen', 'staff14@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(16, 'Staff Fifteen', 'staff15@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(17, 'Staff Sixteen', 'staff16@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(18, 'Staff Seventeen', 'staff17@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(19, 'Staff Eighteen', 'staff18@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(20, 'Staff Nineteen', 'staff19@crm.test', '$2y$10$abcdefghijklmnopqrstuv', 'staff', '2025-12-21 11:45:47'),
(21, 'Admin', 'admin@example.com', '$2y$10$K6hQHjQ8oT2K0vVnVgQF3O9qJwqk4q3m7h1b0cJq3OaQpY9p9oBfS', 'admin', '2025-12-21 13:21:23'),
(22, 'Ahmed Mujtaba', 'tamoorsultan92@gmail.com', '$2y$10$W.x5wNubE3/j7LHvXvvG0e.n.PApjo.18Ye31TS4LJtg0FJbH78Tu', 'staff', '2025-12-21 13:59:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_when` (`created_at`),
  ADD KEY `idx_entity` (`entity`,`entity_id`),
  ADD KEY `idx_action` (`action`),
  ADD KEY `idx_user` (`user_id`);

--
-- Indexes for table `saved_reports`
--
ALTER TABLE `saved_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reg_no` (`reg_no`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reg_no` (`reg_no`);

--
-- Indexes for table `tuitions`
--
ALTER TABLE `tuitions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_date` (`tuition_date`),
  ADD KEY `idx_student` (`student_id`),
  ADD KEY `idx_teacher` (`teacher_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `saved_reports`
--
ALTER TABLE `saved_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tuitions`
--
ALTER TABLE `tuitions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
