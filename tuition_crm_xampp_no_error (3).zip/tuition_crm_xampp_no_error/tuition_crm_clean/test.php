<?php echo "OK"; ?>
<?php
// ========================================
// FILE: /app/auth.php  (REPLACE FILE)
// ========================================
declare(strict_types=1);

function auth_start_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function auth_user(): ?array
{
    auth_start_session();
    $id = (int)($_SESSION['auth_user_id'] ?? 0);
    if ($id <= 0) return null;

    $stmt = db()->prepare("SELECT id, name, email, role FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);

    return $u ?: null;
}

function require_auth(): void
{
    if (!auth_user()) {
        flash_set('warning', 'Please login first.');
        redirect('login.php');
    }
}

function auth_login(int $user_id): void
{
    auth_start_session();
    session_regenerate_id(true);
    $_SESSION['auth_user_id'] = $user_id;
}

function auth_logout(): void
{
    auth_start_session();

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], (bool)$p['secure'], (bool)$p['httponly']);
    }

    session_destroy();
}

function auth_password_hash(string $password): string
{
    return password_hash($password, PASSWORD_BCRYPT);
}

function auth_password_verify(string $password, string $hash): bool
{
    return password_verify($password, $hash);
}


// ========================================
// FILE: /public/actions/auth/login_post.php (REPLACE FILE)
// ========================================
/*
POST: email, password
*/
require_once __DIR__ . '/../../../app/bootstrap.php';

auth_start_session();
csrf_verify();

$email = trim((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');

if ($email === '' || $password === '') {
    flash_set('danger', 'Email and password are required.');
    redirect('login.php');
}

$stmt = db()->prepare("SELECT id, password_hash FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row || !auth_password_verify($password, (string)$row['password_hash'])) {
    flash_set('danger', 'Invalid email or password.');
    redirect('login.php');
}

auth_login((int)$row['id']);
flash_set('success', 'Logged in successfully.');
redirect('dashboard.php');


// ========================================
// FILE: /public/actions/auth/logout_post.php (REPLACE FILE)
// ========================================
require_once __DIR__ . '/../../../app/bootstrap.php';

auth_start_session();
csrf_verify();

auth_logout();
flash_set('success', 'Logged out.');
redirect('login.php');


// ========================================
// FILE: /public/login.php (REPLACE FILE)
// ========================================
require_once __DIR__ . '/../app/bootstrap.php';

auth_start_session();
if (auth_user()) {
    redirect('dashboard.php');
}

$pageTitle = 'Login';
require __DIR__ . '/_layout_top.php';
?>
<div class="row justify-content-center">
  <div class="col-md-6 col-lg-5">
    <div class="card p-3">
      <div class="p-3">
        <h2 class="mb-3">Login</h2>

        <form method="post" action="<?= e(url('actions/auth/login_post.php')) ?>">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label class="form-label">Email</label>
            <input class="form-control" type="email" name="email" required autocomplete="username">
          </div>

          <div class="mb-3">
            <label class="form-label">Password</label>
            <input class="form-control" type="password" name="password" required autocomplete="current-password">
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-primary">Login</button>
            <a class="btn btn-outline-light" href="<?= e(url('register.php')) ?>">Create new account</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/_layout_bottom.php'; ?>


<?php
// ========================================
// FILE: /public/register.php (NEW FILE)
// ========================================
require_once __DIR__ . '/../app/bootstrap.php';

auth_start_session();
if (auth_user()) {
    redirect('dashboard.php');
}

$pageTitle = 'Register';
require __DIR__ . '/_layout_top.php';
?>
<div class="row justify-content-center">
  <div class="col-md-7 col-lg-6">
    <div class="card p-3">
      <div class="p-3">
        <h2 class="mb-3">Register</h2>

        <form method="post" action="<?= e(url('actions/auth/register_post.php')) ?>">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label class="form-label">Name</label>
            <input class="form-control" name="name" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Email</label>
            <input class="form-control" type="email" name="email" required autocomplete="username">
          </div>

          <div class="mb-3">
            <label class="form-label">Password</label>
            <input class="form-control" type="password" name="password" required minlength="6" autocomplete="new-password">
          </div>

          <div class="mb-3">
            <label class="form-label">Confirm Password</label>
            <input class="form-control" type="password" name="password2" required minlength="6" autocomplete="new-password">
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-success">Create Account</button>
            <a class="btn btn-outline-light" href="<?= e(url('login.php')) ?>">Back to Login</a>
          </div>
        </form>

        <div class="text-secondary small mt-3">
          Note: First registered user becomes <b>admin</b> automatically.
        </div>
      </div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/_layout_bottom.php'; ?>


<?php
// ========================================
// FILE: /public/actions/auth/register_post.php (NEW FILE)
// ========================================
require_once __DIR__ . '/../../../app/bootstrap.php';

auth_start_session();
csrf_verify();

$name = trim((string)($_POST['name'] ?? ''));
$email = trim((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');
$password2 = (string)($_POST['password2'] ?? '');

if ($name === '' || $email === '' || $password === '' || $password2 === '') {
    flash_set('danger', 'All fields are required.');
    redirect('register.php');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    flash_set('danger', 'Invalid email address.');
    redirect('register.php');
}

if ($password !== $password2) {
    flash_set('danger', 'Passwords do not match.');
    redirect('register.php');
}

if (strlen($password) < 6) {
    flash_set('danger', 'Password must be at least 6 characters.');
    redirect('register.php');
}

$stmt = db()->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
if ($stmt->fetchColumn()) {
    flash_set('danger', 'Email already registered. Please login.');
    redirect('login.php');
}

$totalUsers = (int)db()->query("SELECT COUNT(*) FROM users")->fetchColumn();
$role = $totalUsers === 0 ? 'admin' : 'staff';

$hash = auth_password_hash($password);

$ins = db()->prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)");
$ins->execute([$name, $email, $hash, $role]);

$userId = (int)db()->lastInsertId();

auth_login($userId);
flash_set('success', 'Account created and logged in.');
redirect('dashboard.php');


// ========================================
// FILE: /sql/seed.sql (APPEND THIS)
// (Run once in phpMyAdmin or import)
// ========================================

// CREATE TABLE IF NOT EXISTS users (
//   id INT UNSIGNED NOT NULL AUTO_INCREMENT,
//   name VARCHAR(120) NOT NULL,
//   email VARCHAR(190) NOT NULL UNIQUE,
//   password_hash VARCHAR(255) NOT NULL,
//   role VARCHAR(50) NOT NULL DEFAULT 'staff',
//   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
//   PRIMARY KEY (id)
// ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

// -- Optional admin seed (password: admin123)
// -- Use only if you want a default login in fresh DB.
// -- INSERT INTO users (name, email, password_hash, role)
// -- VALUES ('Admin', 'admin@example.com', '$2y$10$3EoG5r8Q0l5mYfWm1x7P2u6p3p8j1nQfJXzP0dJ5YqvT1cVg9l7yW', 'admin');

<?php
// /public/reports.php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$pageTitle = 'Reports';

$u = auth_user();
$is_admin = $u && strtolower((string)($u['role'] ?? '')) === 'admin';

/** =========================
 *  Inputs
 *  ========================= */
$from       = trim((string)($_GET['from'] ?? date('Y-m-01')));
$to         = trim((string)($_GET['to'] ?? date('Y-m-t')));
$teacher_id = (int)($_GET['teacher_id'] ?? 0);
$status     = trim((string)($_GET['status'] ?? ''));
$view       = trim((string)($_GET['view'] ?? 'detail'));     // detail | monthly | teacher
$sort       = trim((string)($_GET['sort'] ?? 'pending'));    // teacher sort: pending|paid|fee|records|name
$export     = trim((string)($_GET['export'] ?? ''));         // ''|'csv_detail'|'csv_monthly'|'csv_teacher'|'pdf'
$q          = trim((string)($_GET['q'] ?? ''));              // ✅ NEW: search query
$per_page   = (int)($_GET['per_page'] ?? 50);                // ✅ NEW: per page
$save_name  = trim((string)($_POST['save_name'] ?? ''));     // admin only
$load_saved = (int)($_GET['load_saved'] ?? 0);               // admin only

if (!in_array($view, ['detail', 'monthly', 'teacher'], true)) $view = 'detail';

$allowed_per_page = [25, 50, 100, 200];
if (!in_array($per_page, $allowed_per_page, true)) $per_page = 50;

$page   = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $per_page;

$allowed_status = ['Pending', 'Partial', 'Paid'];
if ($status !== '' && !in_array($status, $allowed_status, true)) $status = '';

/** =========================
 *  Helpers
 *  ========================= */
function build_query(array $overrides = [], array $remove = []): string {
  $q = array_merge($_GET, $overrides);
  foreach ($remove as $k) unset($q[$k]);
  return http_build_query($q);
}

function money_int($v): int {
  return (int)($v ?? 0);
}

function safe_pct(int $num, int $den): int {
  if ($den <= 0) return 0;
  return (int)round(($num / $den) * 100);
}

function is_valid_date(string $d): bool {
  if ($d === '') return false;
  $dt = DateTime::createFromFormat('Y-m-d', $d);
  return $dt && $dt->format('Y-m-d') === $d;
}

/** ✅ Validate dates (avoid broken filters) */
if (!is_valid_date($from)) $from = date('Y-m-01');
if (!is_valid_date($to))   $to   = date('Y-m-t');

/** =========================
 *  Presets
 *  ========================= */
$today = new DateTimeImmutable('today');
$thisMonthFrom = $today->format('Y-m-01');
$thisMonthTo   = $today->format('Y-m-t');

$lastMonth = $today->modify('first day of last month');
$lastMonthFrom = $lastMonth->format('Y-m-01');
$lastMonthTo   = $lastMonth->format('Y-m-t');

$thisYearFrom = $today->format('Y-01-01');
$thisYearTo   = $today->format('Y-12-31');

/** =========================
 *  Load saved report (admin)
 *  ========================= */
if ($is_admin && $load_saved > 0) {
  try {
    $stmt = db()->prepare("SELECT query FROM saved_reports WHERE id = ?");
    $stmt->execute([$load_saved]);
    $qs = (string)$stmt->fetchColumn();
    if ($qs !== '') {
      redirect(url('reports.php?' . $qs));
    }
  } catch (Throwable $e) {
    flash_set('danger', 'Could not load saved report.');
    redirect(url('reports.php'));
  }
}

/** Teachers list */
$teachers = db()->query("SELECT id, name FROM teachers ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

/** =========================
 *  Filters -> WHERE
 *  ========================= */
$where = [];
$args  = [];

$where[] = "t.tuition_date >= ?";
$args[] = $from;

$where[] = "t.tuition_date <= ?";
$args[] = $to;

if ($teacher_id > 0)    { $where[] = "t.teacher_id = ?";     $args[] = $teacher_id; }
if ($status !== '')     { $where[] = "t.status = ?";         $args[] = $status; }

/** ✅ NEW: search by student / teacher / notes */
if ($q !== '') {
  $where[] = "(s.name LIKE ? OR te.name LIKE ? OR COALESCE(t.notes,'') LIKE ?)";
  $like = '%' . $q . '%';
  $args[] = $like;
  $args[] = $like;
  $args[] = $like;
}

$sqlWhere = $where ? ("WHERE " . implode(" AND ", $where)) : "";

$baseSql = "
  FROM tuitions t
  JOIN students s ON s.id = t.student_id
  JOIN teachers te ON te.id = t.teacher_id
  $sqlWhere
";

/** =========================
 *  Summary KPIs (for current filters)
 *  ========================= */
$summaryStmt = db()->prepare("
  SELECT
    COUNT(*) AS total_records,
    COALESCE(SUM(t.monthly_fee),0) AS total_fee,
    COALESCE(SUM(t.company_share_amount),0) AS total_company_share,
    COALESCE(SUM(t.paid_to_company),0) AS total_paid_company,
    COALESCE(SUM(t.pending_to_company),0) AS total_pending_company,
    COALESCE(SUM(CASE WHEN t.status='Pending' THEN 1 ELSE 0 END),0) AS c_pending,
    COALESCE(SUM(CASE WHEN t.status='Partial' THEN 1 ELSE 0 END),0) AS c_partial,
    COALESCE(SUM(CASE WHEN t.status='Paid' THEN 1 ELSE 0 END),0) AS c_paid
  $baseSql
");
$summaryStmt->execute($args);
$summary = $summaryStmt->fetch(PDO::FETCH_ASSOC) ?: [
  'total_records' => 0,
  'total_fee' => 0,
  'total_company_share' => 0,
  'total_paid_company' => 0,
  'total_pending_company' => 0,
  'c_pending' => 0,
  'c_partial' => 0,
  'c_paid' => 0,
];

/** Status bar percentages */
$cp = (int)$summary['c_pending'];
$ct = (int)$summary['c_partial'];
$ca = (int)$summary['c_paid'];
$sumCounts = max(1, $cp + $ct + $ca);
$pPending = (int)round(($cp / $sumCounts) * 100);
$pPartial = (int)round(($ct / $sumCounts) * 100);
$pPaid    = max(0, 100 - $pPending - $pPartial);

/** =========================
 *  Monthly summary
 *  ========================= */
$monthlyStmt = db()->prepare("
  SELECT
    DATE_FORMAT(t.tuition_date, '%Y-%m') AS ym,
    COUNT(*) AS records,
    COALESCE(SUM(t.monthly_fee),0) AS fee_total,
    COALESCE(SUM(t.company_share_amount),0) AS company_total,
    COALESCE(SUM(t.paid_to_company),0) AS paid_total,
    COALESCE(SUM(t.pending_to_company),0) AS pending_total
  $baseSql
  GROUP BY ym
  ORDER BY ym DESC
  LIMIT 120
");
$monthlyStmt->execute($args);
$monthlyRows = $monthlyStmt->fetchAll(PDO::FETCH_ASSOC);

/** =========================
 *  Teacher summary
 *  ========================= */
$sortMap = [
  'pending'  => 'pending_total DESC',
  'paid'     => 'paid_total DESC',
  'fee'      => 'fee_total DESC',
  'records'  => 'records DESC',
  'name'     => 'teacher_name ASC',
];
$orderBy = $sortMap[$sort] ?? $sortMap['pending'];

$teacherSummaryStmt = db()->prepare("
  SELECT
    te.id AS teacher_id,
    te.name AS teacher_name,
    COUNT(*) AS records,
    COALESCE(SUM(t.monthly_fee),0) AS fee_total,
    COALESCE(SUM(t.company_share_amount),0) AS company_total,
    COALESCE(SUM(t.paid_to_company),0) AS paid_total,
    COALESCE(SUM(t.pending_to_company),0) AS pending_total
  $baseSql
  GROUP BY te.id, te.name
  ORDER BY $orderBy
");
$teacherSummaryStmt->execute($args);
$teacherRows = $teacherSummaryStmt->fetchAll(PDO::FETCH_ASSOC);

/** =========================
 *  Detail view queries
 *  ========================= */
$total_records = (int)$summary['total_records'];
$total_pages   = max(1, (int)ceil($total_records / $per_page));
$page          = min($page, $total_pages);
$offset        = ($page - 1) * $per_page;

$listStmt = db()->prepare("
  SELECT
    t.*,
    s.name AS student_name,
    te.name AS teacher_name
  $baseSql
  ORDER BY t.tuition_date DESC, t.id DESC
  LIMIT $per_page OFFSET $offset
");
$listStmt->execute($args);
$rows = $listStmt->fetchAll(PDO::FETCH_ASSOC);

/** Top teachers */
$topTeachersStmt = db()->prepare("
  SELECT
    te.id AS teacher_id,
    te.name AS teacher_name,
    COALESCE(SUM(t.monthly_fee),0) AS fee_total,
    COALESCE(SUM(t.company_share_amount),0) AS company_total,
    COALESCE(SUM(t.paid_to_company),0) AS paid_total,
    COALESCE(SUM(t.pending_to_company),0) AS pending_total,
    COUNT(*) AS records
  $baseSql
  GROUP BY te.id, te.name
  ORDER BY pending_total DESC, paid_total DESC
  LIMIT 5
");
$topTeachersStmt->execute($args);
$topTeachers = $topTeachersStmt->fetchAll(PDO::FETCH_ASSOC);

/** =========================
 *  Exports
 *  ========================= */
if ($export === 'csv_detail') {
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="tuition_reports_detail.csv"');

  $exportStmt = db()->prepare("
    SELECT
      t.id,
      t.tuition_date,
      s.name AS student,
      te.name AS teacher,
      t.monthly_fee,
      t.company_share_percent,
      t.company_share_amount,
      t.paid_to_company,
      t.pending_to_company,
      t.status,
      t.notes
    $baseSql
    ORDER BY t.tuition_date DESC, t.id DESC
  ");
  $exportStmt->execute($args);

  $out = fopen('php://output', 'w');
  fputcsv($out, ['ID','Date','Student','Teacher','Fee','Share %','Company Share','Paid','Pending','Status','Notes']);
  while ($r = $exportStmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($out, [
      $r['id'], $r['tuition_date'], $r['student'], $r['teacher'],
      $r['monthly_fee'], $r['company_share_percent'], $r['company_share_amount'],
      $r['paid_to_company'], $r['pending_to_company'], $r['status'], $r['notes'],
    ]);
  }
  fclose($out);
  exit;
}

if ($export === 'csv_monthly') {
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="tuition_reports_monthly.csv"');

  $out = fopen('php://output', 'w');
  fputcsv($out, ['Month','Records','Fee Total','Company Total','Paid Total','Pending Total']);
  foreach ($monthlyRows as $m) {
    fputcsv($out, [
      $m['ym'], $m['records'], $m['fee_total'], $m['company_total'], $m['paid_total'], $m['pending_total']
    ]);
  }
  fclose($out);
  exit;
}

if ($export === 'csv_teacher') {
  if (!$is_admin) {
    flash_set('danger', 'Only admin can export Teacher Summary.');
    redirect(url('reports.php?' . build_query([], ['export'])));
  }

  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="tuition_reports_teacher_summary.csv"');

  $out = fopen('php://output', 'w');
  fputcsv($out, ['Teacher','Records','Fee Total','Company Total','Paid Total','Pending Total','Pending %']);
  foreach ($teacherRows as $t) {
    $paid = money_int($t['paid_total']);
    $pending = money_int($t['pending_total']);
    $pctPending = safe_pct($pending, max(1, $paid + $pending));
    fputcsv($out, [
      $t['teacher_name'],
      $t['records'],
      $t['fee_total'],
      $t['company_total'],
      $paid,
      $pending,
      $pctPending . '%',
    ]);
  }
  fclose($out);
  exit;
}

/** =========================
 *  ✅ FIXED PDF EXPORT (Dompdf Options)
 *  ========================= */
if ($export === 'pdf') {
  if (!$is_admin) {
    flash_set('danger', 'Only admin can export PDF.');
    redirect(url('reports.php?' . build_query([], ['export'])));
  }

  $autoload = __DIR__ . '/../vendor/autoload.php';
  if (!is_file($autoload)) {
    flash_set('danger', 'PDF export requires dompdf. Run: composer require dompdf/dompdf');
    redirect(url('reports.php?' . build_query([], ['export'])));
  }

  require_once $autoload;

  if (!class_exists(\Dompdf\Dompdf::class)) {
    flash_set('danger', 'Dompdf not found. Run: composer require dompdf/dompdf');
    redirect(url('reports.php?' . build_query([], ['export'])));
  }

  try {
    $html = '<h2 style="margin:0;">Tuition CRM - Reports</h2>';
    $html .= '<div style="margin:6px 0 14px 0; color:#555;">';
    $html .= 'From: ' . htmlspecialchars($from) . ' | To: ' . htmlspecialchars($to);
    if ($teacher_id > 0) $html .= ' | Teacher ID: ' . (int)$teacher_id;
    if ($status !== '') $html .= ' | Status: ' . htmlspecialchars($status);
    if ($q !== '') $html .= ' | Search: ' . htmlspecialchars($q);
    $html .= '</div>';

    $html .= '<table width="100%" cellspacing="0" cellpadding="6" border="1" style="border-collapse:collapse;font-size:12px;">';
    $html .= '<thead><tr style="background:#eee;">
      <th align="left">Month</th>
      <th align="right">Records</th>
      <th align="right">Fee</th>
      <th align="right">Company</th>
      <th align="right">Paid</th>
      <th align="right">Pending</th>
    </tr></thead><tbody>';

    foreach ($monthlyRows as $m) {
      $html .= '<tr>
        <td>' . htmlspecialchars((string)$m['ym']) . '</td>
        <td align="right">' . (int)$m['records'] . '</td>
        <td align="right">' . (int)$m['fee_total'] . '</td>
        <td align="right">' . (int)$m['company_total'] . '</td>
        <td align="right">' . (int)$m['paid_total'] . '</td>
        <td align="right">' . (int)$m['pending_total'] . '</td>
      </tr>';
    }

    $html .= '</tbody></table>';
    $html .= '<div style="margin-top:10px;font-size:11px;color:#666;">Generated: ' . date('Y-m-d H:i:s') . '</div>';

    // ✅ Correct dompdf initialization
    $options = new \Dompdf\Options();
    $options->set('isRemoteEnabled', true);
    $dompdf = new \Dompdf\Dompdf($options);

    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $dompdf->stream('tuition_reports.pdf', ['Attachment' => true]);
    exit;

  } catch (Throwable $e) {
    flash_set('danger', 'PDF export failed: ' . $e->getMessage());
    redirect(url('reports.php?' . build_query([], ['export'])));
  }
}

/** =========================
 *  Saved reports (admin-only)
 *  ========================= */
if ($is_admin && $save_name !== '') {
  try {
    $queryString = build_query([], ['export', 'load_saved', 'page']);
    $stmt = db()->prepare("INSERT INTO saved_reports (user_id, name, query) VALUES (?, ?, ?)");
    $stmt->execute([(int)($u['id'] ?? 0), mb_substr($save_name, 0, 120), $queryString]);
    flash_set('success', 'Saved report created.');
  } catch (Throwable $e) {
    flash_set('danger', 'Saving report failed. Ensure saved_reports table exists.');
  }
  redirect(url('reports.php?' . build_query([], ['export'])));
}

$savedReports = [];
if ($is_admin) {
  try {
    $savedReports = db()->query("SELECT id, name, created_at FROM saved_reports ORDER BY id DESC LIMIT 30")->fetchAll(PDO::FETCH_ASSOC);
  } catch (Throwable $e) {
    $savedReports = [];
  }
}

/** Auto monthly (foundation) */
$is_first_day = (int)date('j') === 1;

require __DIR__ . '/_layout_top.php';

/** Chart data (Chart.js) */
$chartLabels = [];
$chartCompany = [];
$chartPaid = [];
$chartPending = [];

$monthlyAsc = array_reverse($monthlyRows);
foreach ($monthlyAsc as $m) {
  $chartLabels[] = (string)$m['ym'];
  $chartCompany[] = (int)$m['company_total'];
  $chartPaid[] = (int)$m['paid_total'];
  $chartPending[] = (int)$m['pending_total'];
}
?>

<div class="report-page">

  <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
      <h2 class="mb-1">Reports</h2>
      <div class="text-secondary small">
        Filter by date / teacher / status • Views: Detail, Monthly, Teachers • Charts + Exports
      </div>
      <?php if ($is_first_day): ?>
        <div class="alert alert-warning py-2 mt-2 mb-0">
          Month started today. Tip: review last month quickly using <b>Last Month</b> preset.
        </div>
      <?php endif; ?>
    </div>

    <div class="d-flex gap-2 flex-wrap align-items-center">
      <a class="btn btn-outline-light btn-sm" href="?<?= e(build_query(['from'=>$thisMonthFrom,'to'=>$thisMonthTo,'page'=>1])) ?>">This Month</a>
      <a class="btn btn-outline-light btn-sm" href="?<?= e(build_query(['from'=>$lastMonthFrom,'to'=>$lastMonthTo,'page'=>1])) ?>">Last Month</a>
      <a class="btn btn-outline-light btn-sm" href="?<?= e(build_query(['from'=>$thisYearFrom,'to'=>$thisYearTo,'page'=>1])) ?>">This Year</a>

      <div class="btn-group ms-sm-2" role="group" aria-label="View">
        <a class="btn btn-sm btn-outline-light <?= $view==='detail'?'active':'' ?>"
           href="?<?= e(build_query(['view'=>'detail','page'=>1])) ?>">Detail</a>
        <a class="btn btn-sm btn-outline-light <?= $view==='monthly'?'active':'' ?>"
           href="?<?= e(build_query(['view'=>'monthly','page'=>1])) ?>">Monthly</a>
        <a class="btn btn-sm btn-outline-light <?= $view==='teacher'?'active':'' ?>"
           href="?<?= e(build_query(['view'=>'teacher','page'=>1])) ?>">Teachers</a>
      </div>

      <div class="btn-group ms-sm-1" role="group" aria-label="Export">
        <?php
          $defaultCsv = ($view === 'monthly') ? 'csv_monthly' : (($view === 'teacher') ? 'csv_teacher' : 'csv_detail');
        ?>
        <a class="btn btn-sm btn-primary" href="?<?= e(build_query(['export'=>$defaultCsv])) ?>">Export CSV</a>
        <a class="btn btn-sm btn-danger <?= $is_admin?'':'disabled' ?>" href="?<?= e(build_query(['export'=>'pdf'])) ?>">PDF</a>
      </div>
    </div>
  </div>

  <!-- Filters -->
  <form class="row g-2 mb-3" method="get">
    <input type="hidden" name="view" value="<?= e($view) ?>">
    <input type="hidden" name="page" value="1">

    <div class="col-md-2">
      <label class="form-label">From</label>
      <input type="date" class="form-control" name="from" value="<?= e($from) ?>">
    </div>

    <div class="col-md-2">
      <label class="form-label">To</label>
      <input type="date" class="form-control" name="to" value="<?= e($to) ?>">
    </div>

    <div class="col-md-3">
      <label class="form-label">Teacher</label>
      <select class="form-select" name="teacher_id">
        <option value="0">All</option>
        <?php foreach ($teachers as $t): ?>
          <option value="<?= e((string)$t['id']) ?>" <?= $teacher_id===(int)$t['id']?'selected':'' ?>>
            <?= e((string)$t['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="col-md-2">
      <label class="form-label">Status</label>
      <select class="form-select" name="status">
        <option value="">All</option>
        <?php foreach (['Pending','Partial','Paid'] as $st): ?>
          <option value="<?= e($st) ?>" <?= $status===$st?'selected':'' ?>><?= e($st) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="col-md-2">
      <label class="form-label">Search</label>
      <input class="form-control" name="q" value="<?= e($q) ?>" placeholder="student / teacher / notes">
    </div>

    <div class="col-md-1">
      <label class="form-label">Rows</label>
      <select class="form-select" name="per_page">
        <?php foreach ([25,50,100,200] as $n): ?>
          <option value="<?= $n ?>" <?= $per_page===$n?'selected':'' ?>><?= $n ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="col-md-12 d-grid">
      <button class="btn btn-success">Go</button>
    </div>
  </form>

  <?php if ($is_admin): ?>
    <div class="card p-3 mb-3">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
        <div>
          <div class="fw-semibold">Saved Reports</div>
          <div class="text-secondary small">Save current filters / view. Load anytime.</div>
        </div>

        <form method="post" class="d-flex gap-2 flex-wrap">
          <input class="form-control form-control-sm" name="save_name" placeholder="Save name (e.g. Last Month - All)" style="min-width:260px;">
          <button class="btn btn-sm btn-outline-light">Save</button>
        </form>
      </div>

      <?php if ($savedReports): ?>
        <div class="d-flex flex-wrap gap-2 mt-2">
          <?php foreach ($savedReports as $sr): ?>
            <a class="btn btn-sm btn-outline-info"
               href="?<?= e(build_query(['load_saved'=>(int)$sr['id']], ['export'])) ?>">
              <?= e((string)$sr['name']) ?>
              <span class="text-secondary">· <?= e((string)$sr['created_at']) ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="text-secondary small mt-2">No saved reports yet (or table not created).</div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <!-- KPI cards -->
  <div class="row g-3 mb-3">
    <div class="col-md-3">
      <div class="card p-3 report-kpi">
        <div class="text-secondary small">Total Records</div>
        <div class="fs-4 fw-semibold"><?= e((string)$summary['total_records']) ?></div>
        <div class="text-secondary small mt-2">
          Pending: <?= e((string)$summary['c_pending']) ?> |
          Partial: <?= e((string)$summary['c_partial']) ?> |
          Paid: <?= e((string)$summary['c_paid']) ?>
        </div>

        <div class="report-bar mt-2" title="Status distribution">
          <span class="bar pending" style="width: <?= e((string)$pPending) ?>%"></span>
          <span class="bar partial" style="width: <?= e((string)$pPartial) ?>%"></span>
          <span class="bar paid" style="width: <?= e((string)$pPaid) ?>%"></span>
        </div>
        <div class="text-secondary small mt-1">
          <?= e((string)$pPending) ?>% Pending · <?= e((string)$pPartial) ?>% Partial · <?= e((string)$pPaid) ?>% Paid
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card p-3 report-kpi">
        <div class="text-secondary small">Total Fee</div>
        <div class="fs-4 fw-semibold"><?= e((string)$summary['total_fee']) ?></div>
        <div class="text-secondary small mt-1">Sum of monthly fees</div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card p-3 report-kpi">
        <div class="text-secondary small">Company Share</div>
        <div class="fs-4 fw-semibold"><?= e((string)$summary['total_company_share']) ?></div>
        <div class="text-secondary small mt-1">Company share total</div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card p-3 report-kpi">
        <div class="text-secondary small">Paid / Pending</div>
        <div class="fs-6 fw-semibold">Paid: <?= e((string)$summary['total_paid_company']) ?></div>
        <div class="fs-6 fw-semibold">Pending: <?= e((string)$summary['total_pending_company']) ?></div>
        <div class="text-secondary small mt-1">Company cashflow</div>
      </div>
    </div>
  </div>

  <!-- Charts -->
  <div class="row g-3 mb-3">
    <div class="col-lg-6">
      <div class="card p-3">
        <div class="d-flex justify-content-between align-items-center">
          <div class="fw-semibold">Company Share by Month</div>
          <div class="text-secondary small">Current filters</div>
        </div>
        <div class="mt-2">
          <canvas id="chartCompany" height="120"></canvas>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="card p-3">
        <div class="d-flex justify-content-between align-items-center">
          <div class="fw-semibold">Paid vs Pending by Month</div>
          <div class="text-secondary small">Current filters</div>
        </div>
        <div class="mt-2">
          <canvas id="chartCash" height="120"></canvas>
        </div>
      </div>
    </div>
  </div>

  <?php if ($view === 'teacher'): ?>

    <div class="card p-3">
      <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
        <div>
          <h5 class="mb-0">Teacher Summary</h5>
          <div class="text-secondary small">All teachers, sortable, drill-down to Monthly</div>
        </div>

        <div class="btn-group" role="group" aria-label="Sort">
          <a class="btn btn-sm btn-outline-light <?= $sort==='pending'?'active':'' ?>" href="?<?= e(build_query(['sort'=>'pending'])) ?>">Pending</a>
          <a class="btn btn-sm btn-outline-light <?= $sort==='paid'?'active':'' ?>" href="?<?= e(build_query(['sort'=>'paid'])) ?>">Paid</a>
          <a class="btn btn-sm btn-outline-light <?= $sort==='fee'?'active':'' ?>" href="?<?= e(build_query(['sort'=>'fee'])) ?>">Fee</a>
          <a class="btn btn-sm btn-outline-light <?= $sort==='records'?'active':'' ?>" href="?<?= e(build_query(['sort'=>'records'])) ?>">Records</a>
          <a class="btn btn-sm btn-outline-light <?= $sort==='name'?'active':'' ?>" href="?<?= e(build_query(['sort'=>'name'])) ?>">Name</a>
        </div>
      </div>

      <div class="table-responsive">
        <table class="table table-dark table-hover align-middle mb-0">
          <thead>
            <tr>
              <th>Teacher</th>
              <th>Records</th>
              <th>Fee Total</th>
              <th>Company Total</th>
              <th>Paid</th>
              <th>Pending</th>
              <th>Risk</th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$teacherRows): ?>
            <tr><td colspan="7" class="text-center text-secondary">No teachers for selected filters.</td></tr>
          <?php else: ?>
            <?php foreach ($teacherRows as $t): ?>
              <?php
                $paid = money_int($t['paid_total']);
                $pending = money_int($t['pending_total']);
                $totalCash = max(1, $paid + $pending);
                $pendingPct = safe_pct($pending, $totalCash);
                $riskClass = $pendingPct >= 60 ? 'danger' : ($pendingPct >= 30 ? 'warning' : 'success');
              ?>
              <tr>
                <td class="fw-semibold">
                  <a class="text-decoration-none"
                     href="?<?= e(build_query(['view'=>'monthly','teacher_id'=>(int)$t['teacher_id'],'page'=>1])) ?>">
                    <?= e((string)$t['teacher_name']) ?>
                  </a>
                </td>
                <td><?= e((string)$t['records']) ?></td>
                <td><?= e((string)$t['fee_total']) ?></td>
                <td><?= e((string)$t['company_total']) ?></td>
                <td><?= e((string)$paid) ?></td>
                <td class="fw-semibold"><?= e((string)$pending) ?></td>
                <td>
                  <span class="badge bg-<?= e($riskClass) ?>">
                    <?= e((string)$pendingPct) ?>% Pending
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  <?php elseif ($view === 'monthly'): ?>

    <div class="card p-3">
      <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
        <div>
          <h5 class="mb-0">Monthly Summary</h5>
          <div class="text-secondary small">Drill-down: click month → open Detail for that month.</div>
        </div>
      </div>

      <div class="table-responsive">
        <table class="table table-dark table-hover align-middle mb-0">
          <thead>
            <tr>
              <th>Month</th>
              <th>Records</th>
              <th>Fee Total</th>
              <th>Company Total</th>
              <th>Paid</th>
              <th>Pending</th>
              <th>Pending %</th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$monthlyRows): ?>
            <tr><td colspan="7" class="text-center text-secondary">No data for selected filters.</td></tr>
          <?php else: ?>
            <?php foreach ($monthlyRows as $m): ?>
              <?php
                $paid = money_int($m['paid_total']);
                $pending = money_int($m['pending_total']);
                $totalCash = max(1, $paid + $pending);
                $pendingPct = safe_pct($pending, $totalCash);

                $monthFrom = (string)$m['ym'] . '-01';
                $monthTo = (new DateTimeImmutable($monthFrom))->format('Y-m-t');
              ?>
              <tr>
                <td class="fw-semibold">
                  <a class="text-decoration-none"
                     href="?<?= e(build_query(['view'=>'detail','from'=>$monthFrom,'to'=>$monthTo,'page'=>1])) ?>">
                    <?= e((string)$m['ym']) ?>
                  </a>
                </td>
                <td><?= e((string)$m['records']) ?></td>
                <td><?= e((string)$m['fee_total']) ?></td>
                <td><?= e((string)$m['company_total']) ?></td>
                <td><?= e((string)$paid) ?></td>
                <td><?= e((string)$pending) ?></td>
                <td>
                  <span class="badge bg-<?= $pendingPct >= 60 ? 'danger' : ($pendingPct >= 30 ? 'warning' : 'success') ?>">
                    <?= e((string)$pendingPct) ?>%
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  <?php else: ?>

    <div class="card p-3">
      <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
        <div class="text-secondary small">
          Showing <?= e((string)count($rows)) ?> rows • Page <?= e((string)$page) ?> of <?= e((string)$total_pages) ?> • Total <?= e((string)$total_records) ?>
        </div>

        <div class="d-flex gap-2">
          <?php $prev = max(1, $page - 1); $next = min($total_pages, $page + 1); ?>
          <a class="btn btn-outline-light btn-sm <?= $page<=1?'disabled':'' ?>"
             href="?<?= e(build_query(['page'=>$prev])) ?>">← Prev</a>

          <a class="btn btn-outline-light btn-sm <?= $page>=$total_pages?'disabled':'' ?>"
             href="?<?= e(build_query(['page'=>$next])) ?>">Next →</a>
        </div>
      </div>

      <div class="table-responsive">
        <table class="table table-dark table-hover align-middle">
          <thead>
            <tr>
              <th>ID</th>
              <th>Date</th>
              <th>Student</th>
              <th>Teacher</th>
              <th>Fee</th>
              <th>Company Amt</th>
              <th>Paid</th>
              <th>Pending</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$rows): ?>
            <tr><td colspan="9" class="text-center text-secondary">No report data</td></tr>
          <?php else: ?>
            <?php foreach ($rows as $r): ?>
              <?php $badge = $r['status']==='Paid' ? 'success' : ($r['status']==='Partial' ? 'warning' : 'secondary'); ?>
              <tr>
                <td><?= e((string)$r['id']) ?></td>
                <td><?= e((string)$r['tuition_date']) ?></td>
                <td><?= e((string)$r['student_name']) ?></td>
                <td><?= e((string)$r['teacher_name']) ?></td>
                <td><?= e((string)$r['monthly_fee']) ?></td>
                <td><?= e((string)$r['company_share_amount']) ?></td>
                <td><?= e((string)$r['paid_to_company']) ?></td>
                <td><?= e((string)$r['pending_to_company']) ?></td>
                <td><span class="badge bg-<?= e($badge) ?>"><?= e((string)$r['status']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  <?php endif; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
  const labels = <?= json_encode($chartLabels, JSON_UNESCAPED_SLASHES) ?>;
  const company = <?= json_encode($chartCompany, JSON_UNESCAPED_SLASHES) ?>;
  const paid = <?= json_encode($chartPaid, JSON_UNESCAPED_SLASHES) ?>;
  const pending = <?= json_encode($chartPending, JSON_UNESCAPED_SLASHES) ?>;

  const elCompany = document.getElementById('chartCompany');
  if (elCompany) {
    new Chart(elCompany, {
      type: 'line',
      data: { labels, datasets: [{ label: 'Company Share', data: company, borderWidth: 2, tension: 0.25 }] },
      options: { responsive: true, plugins: { legend: { display: true } }, scales: { y: { beginAtZero: true } } }
    });
  }

  const elCash = document.getElementById('chartCash');
  if (elCash) {
    new Chart(elCash, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          { label: 'Paid', data: paid, borderWidth: 1 },
          { label: 'Pending', data: pending, borderWidth: 1 }
        ]
      },
      options: { responsive: true, plugins: { legend: { display: true } }, scales: { y: { beginAtZero: true } } }
    });
  }
</script>

<?php require __DIR__ . '/_layout_bottom.php'; ?>





<?php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$u = auth_user();
$pageTitle = 'Dashboard';

require __DIR__ . '/_layout_top.php';
?>

<link rel="stylesheet" href="<?= e(url('assets/css/dashboard.css')) ?>">

<!-- ==============================
     STICKY HEADER
================================ -->
<div id="dashSticky" class="dash-sticky">
  <div class="dash-sticky-inner">

    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
      <div>
        <h2 class="dash-title-big mb-1">Dashboard</h2>

        <div class="hide-on-shrink small text-secondary">
          Welcome, <?= e($u['name'] ?? 'User') ?>
          <?= isset($u['role']) ? '(' . e($u['role']) . ')' : '' ?>
        </div>
      </div>

      <div class="d-flex gap-2">
        <a class="btn btn-outline-light btn-sm-on-shrink"
           href="<?= e(url('reports.php')) ?>">Reports</a>

        <a class="btn btn-outline-light btn-sm-on-shrink"
           href="<?= e(url('logout.php')) ?>">Logout</a>
      </div>
    </div>

  </div>
</div>

<!-- ==============================
     PAGE CONTENT
================================ -->
<div class="container-fluid mt-3 dash-wrap">

  <div class="row g-3 mb-3">
    <div class="col-md-3">
      <div class="dash-kpi card">
        <div class="dash-kpi-label">Students</div>
        <div class="dash-kpi-val">—</div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="dash-kpi card">
        <div class="dash-kpi-label">Teachers</div>
        <div class="dash-kpi-val">—</div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="dash-kpi card">
        <div class="dash-kpi-label">Tuitions</div>
        <div class="dash-kpi-val">—</div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="dash-kpi card">
        <div class="dash-kpi-label">Pending</div>
        <div class="dash-kpi-val">—</div>
      </div>
    </div>
  </div>

  <div class="card p-3 mb-3">
    <h5>Quick Actions</h5>
    <div class="d-flex gap-2 flex-wrap">
      <a class="btn btn-primary" href="<?= e(url('students.php')) ?>">Students</a>
      <a class="btn btn-primary" href="<?= e(url('teachers.php')) ?>">Teachers</a>
      <a class="btn btn-primary" href="<?= e(url('tuitions.php')) ?>">Tuitions</a>
      <a class="btn btn-outline-light" href="<?= e(url('reports.php')) ?>">Reports</a>
    </div>
  </div>

</div>

<!-- ==============================
     SHRINK SCRIPT (SAFE)
================================ -->
<script>
(function () {
  const header = document.getElementById('dashSticky');
  if (!header) return;

  const threshold = 40;

  function onScroll() {
    if (window.scrollY > threshold) {
      header.classList.add('shrink');
    } else {
      header.classList.remove('shrink');
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();
</script>

<?php require __DIR__ . '/_layout_bottom.php'; ?>
