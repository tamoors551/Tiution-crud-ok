<?php

// FILE: /app/auth.php  (REPLACE FILE)
// ========================================
declare(strict_types=1);

function auth_start_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function auth_user(): ?array
{
    auth_start_session();
    $id = (int)($_SESSION['auth_user_id'] ?? 0);
    if ($id <= 0) return null;

    $stmt = db()->prepare("SELECT id, name, email, role FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);

    return $u ?: null;
}

function require_auth(): void
{
    if (!auth_user()) {
        flash_set('warning', 'Please login first.');
        redirect('login.php');
    }
}

function auth_login(int $user_id): void
{
    auth_start_session();
    session_regenerate_id(true);
    $_SESSION['auth_user_id'] = $user_id;
}

function auth_logout(): void
{
    auth_start_session();

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], (bool)$p['secure'], (bool)$p['httponly']);
    }

    session_destroy();
}

function auth_password_hash(string $password): string
{
    return password_hash($password, PASSWORD_BCRYPT);
}

function auth_password_verify(string $password, string $hash): bool
{
    return password_verify($password, $hash);
}