<?php
function ensure_upload_dirs(): void {
  $base = config('app.upload_dir');
  @mkdir($base, 0775, true);
  @mkdir($base . '/teacher_id', 0775, true);
  @mkdir($base . '/teacher_docs', 0775, true);
}

function sanitize_filename(string $name): string {
  $name = preg_replace('/[^a-zA-Z0-9._-]/', '_', $name);
  $name = preg_replace('/_+/', '_', $name);
  return trim($name, '_');
}

function store_upload(string $field, string $subdir, array $allowedExt): ?string {
  if (!isset($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) return null;

  if ($_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
    throw new RuntimeException("Upload error for $field");
  }

  $maxBytes = (int)config('app.max_upload_mb', 10) * 1024 * 1024;
  if ((int)$_FILES[$field]['size'] > $maxBytes) {
    throw new RuntimeException("File too large (max ".config('app.max_upload_mb')."MB)");
  }

  $original = $_FILES[$field]['name'] ?? 'file';
  $original = sanitize_filename($original);

  $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
  if (!in_array($ext, $allowedExt, true)) {
    throw new RuntimeException("Invalid file type. Allowed: " . implode(', ', $allowedExt));
  }

  ensure_upload_dirs();

  $unique = date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
  $target = rtrim(config('app.upload_dir'), '/') . '/' . trim($subdir, '/') . '/' . $unique;

  if (!move_uploaded_file($_FILES[$field]['tmp_name'], $target)) {
    throw new RuntimeException("Failed to move uploaded file");
  }

  return trim($subdir, '/') . '/' . $unique;
}

function absolute_upload_path(string $relative): string {
  $relative = ltrim($relative, '/');
  $base = rtrim(config('app.upload_dir'), '/');
  $full = $base . '/' . $relative;

  $realBase = realpath($base);
  $realFull = realpath($full);

  if (!$realFull || !$realBase || strpos($realFull, $realBase) !== 0) {
    throw new RuntimeException('Invalid file path');
  }

  return $realFull;
}
