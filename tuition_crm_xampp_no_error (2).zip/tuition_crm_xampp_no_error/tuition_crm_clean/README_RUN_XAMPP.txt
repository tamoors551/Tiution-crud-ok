TUITION CRM (XAMPP READY)

1) Copy the folder "tuition_crm" into:
   C:\xampp\htdocs\

   Final path must be:
   C:\xampp\htdocs\tuition_crm\public\login.php

2) Start XAMPP:
   - Start Apache
   - Start MySQL

3) Create + Import Database:
   - Open: http://localhost/phpmyadmin
   - Create database: tuition_crm
   - Import file: sql/seed.sql

4) Open App:
   http://localhost/tuition_crm/public/

Default Admin:
Email: admin@local.test
Password: admin123

If you used Xampp-3, it is the same idea, just put it inside:
C:\Xampp-3\htdocs\tuition_crm\
.
├── app
│   ├── auth.php
│   ├── bootstrap.php
│   ├── config.php
│   ├── csrf.php
│   ├── db.php
│   ├── flash.php
│   ├── helpers.php
│   └── storage.php
├── public
│   ├── actions
│   │   ├── auth
│   │   │   ├── hello.php
│   │   │   ├── login_post.php
│   │   │   ├── logout_post.php
│   │   │   └── register_post.php
│   │   ├── students
│   │   │   ├── create.php
│   │   │   ├── delete.php
│   │   │   └── update.php
│   │   └── teachers
│   │       ├── create.php
│   │       ├── delete.php
│   │       ├── file.php
│   │       └── update.php
│   ├── assets
│   │   ├── admin_logs.php
│   │   └── app.css
│   ├── tuitions
│   │   ├── create.php
│   │   ├── delete.php
│   │   └── update.php
│   ├── uploads
│   │   ├── teacher_docs
│   │   │   ├── 20251221_054400_a5f59d079521.pdf
│   │   │   └── 20251221_083609_ec1711ed91da.pdf
│   │   └── teacher_id
│   │       ├── 20251221_054400_6806f67d331c.pdf
│   │       └── 20251221_083609_fa3439068970.pdf
│   ├── _layout_bottom.php
│   ├── _layout_top.php
│   ├── dashboard.php
│   ├── index.php
│   ├── login.php
│   ├── logout.php
│   ├── register.php
│   ├── reports.php
│   ├── student_form.php
│   ├── students.php
│   ├── teacher_form.php
│   ├── teachers.php
│   ├── tuition_form.php
│   └── tuitions.php
├── sql
│   └── seed.sql
├── README_RUN_XAMPP.txt
└── test.php