<?php

return [
    'db' => [
        'host'    => '127.0.0.1',
        'name'    => 'tuition_crm',
        'user'    => 'root',
        'pass'    => '',
        'charset' => 'utf8mb4',
    ],

    'app' => [
        /*
         |------------------------------------------------------------
         | Base URL for XAMPP (VERY IMPORTANT)
         |------------------------------------------------------------
         | Your real project URL is:
         | http://localhost/tuition_crm_xampp_no_error/tuition_crm_clean/public/
         |
         | So base_url MUST match this path exactly.
         */
        'base_url' => '/tuition_crm_xampp_no_error/tuition_crm_clean/public',

        /*
         |------------------------------------------------------------
         | Upload directory (do not change)
         |------------------------------------------------------------
         */
        'upload_dir' => __DIR__ . '/../public/uploads',

        /*
         |------------------------------------------------------------
         | Maximum upload size (MB)
         |------------------------------------------------------------
         */
        'max_upload_mb' => 10,
    ],
];
