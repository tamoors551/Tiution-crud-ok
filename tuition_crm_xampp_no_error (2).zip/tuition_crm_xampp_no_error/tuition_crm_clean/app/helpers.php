<?php
function config(string $key, $default = null) {
  static $cfg = null;
  if ($cfg === null) $cfg = require __DIR__ . '/config.php';

  $parts = explode('.', $key);
  $value = $cfg;

  foreach ($parts as $p) {
    if (!is_array($value) || !array_key_exists($p, $value)) return $default;
    $value = $value[$p];
  }
  return $value;
}

function e(string $str): string {
  return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

/**
 * Build an absolute URL path under your app base.
 * Set config('app.base_url') to something like:
 *   http://localhost/tuition_crm_xampp_no_error/tuition_crm_clean/public
 */
function url(string $path = ''): string {
  $base = rtrim((string)config('app.base_url', ''), '/');
  $path = '/' . ltrim($path, '/');

  if ($base !== '') return $base . $path;

  // fallback if base_url is not set (works on localhost subfolders too)
  $dir = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/\\');
  return ($dir === '' ? '' : $dir) . $path;
}
function redirect(string $path): void {
  // If it's already an absolute URL or absolute path, don't wrap it again
  if (preg_match('~^https?://~i', $path) || str_starts_with($path, '/')) {
    header('Location: ' . $path);
    exit;
  }

  header('Location: ' . url($path));
  exit;
}


/* ===== keep your audit() below as-is ===== */
function audit(string $action, string $entity, int $entity_id, string $details = ''): void
{
  try {
    $u = auth_user();
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $stmt = db()->prepare(
      "INSERT INTO activity_log (user_id, ip, action, entity, entity_id, details)
       VALUES (?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([
      $u['id'] ?? null,
      substr($ip, 0, 45),
      $action,
      $entity,
      $entity_id,
      $details !== '' ? mb_substr($details, 0, 2000) : null,
    ]);
  } catch (Throwable $e) {
    error_log('audit() failed: ' . $e->getMessage());
  }
}
