<?php echo "OK"; ?>
<?php
// ========================================
// FILE: /app/auth.php  (REPLACE FILE)
// ========================================
declare(strict_types=1);

function auth_start_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function auth_user(): ?array
{
    auth_start_session();
    $id = (int)($_SESSION['auth_user_id'] ?? 0);
    if ($id <= 0) return null;

    $stmt = db()->prepare("SELECT id, name, email, role FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);

    return $u ?: null;
}

function require_auth(): void
{
    if (!auth_user()) {
        flash_set('warning', 'Please login first.');
        redirect('login.php');
    }
}

function auth_login(int $user_id): void
{
    auth_start_session();
    session_regenerate_id(true);
    $_SESSION['auth_user_id'] = $user_id;
}

function auth_logout(): void
{
    auth_start_session();

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], (bool)$p['secure'], (bool)$p['httponly']);
    }

    session_destroy();
}

function auth_password_hash(string $password): string
{
    return password_hash($password, PASSWORD_BCRYPT);
}

function auth_password_verify(string $password, string $hash): bool
{
    return password_verify($password, $hash);
}


// ========================================
// FILE: /public/actions/auth/login_post.php (REPLACE FILE)
// ========================================
/*
POST: email, password
*/
require_once __DIR__ . '/../../../app/bootstrap.php';

auth_start_session();
csrf_verify();

$email = trim((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');

if ($email === '' || $password === '') {
    flash_set('danger', 'Email and password are required.');
    redirect('login.php');
}

$stmt = db()->prepare("SELECT id, password_hash FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row || !auth_password_verify($password, (string)$row['password_hash'])) {
    flash_set('danger', 'Invalid email or password.');
    redirect('login.php');
}

auth_login((int)$row['id']);
flash_set('success', 'Logged in successfully.');
redirect('dashboard.php');


// ========================================
// FILE: /public/actions/auth/logout_post.php (REPLACE FILE)
// ========================================
require_once __DIR__ . '/../../../app/bootstrap.php';

auth_start_session();
csrf_verify();

auth_logout();
flash_set('success', 'Logged out.');
redirect('login.php');


// ========================================
// FILE: /public/login.php (REPLACE FILE)
// ========================================
require_once __DIR__ . '/../app/bootstrap.php';

auth_start_session();
if (auth_user()) {
    redirect('dashboard.php');
}

$pageTitle = 'Login';
require __DIR__ . '/_layout_top.php';
?>
<div class="row justify-content-center">
  <div class="col-md-6 col-lg-5">
    <div class="card p-3">
      <div class="p-3">
        <h2 class="mb-3">Login</h2>

        <form method="post" action="<?= e(url('actions/auth/login_post.php')) ?>">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label class="form-label">Email</label>
            <input class="form-control" type="email" name="email" required autocomplete="username">
          </div>

          <div class="mb-3">
            <label class="form-label">Password</label>
            <input class="form-control" type="password" name="password" required autocomplete="current-password">
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-primary">Login</button>
            <a class="btn btn-outline-light" href="<?= e(url('register.php')) ?>">Create new account</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/_layout_bottom.php'; ?>


<?php
// ========================================
// FILE: /public/register.php (NEW FILE)
// ========================================
require_once __DIR__ . '/../app/bootstrap.php';

auth_start_session();
if (auth_user()) {
    redirect('dashboard.php');
}

$pageTitle = 'Register';
require __DIR__ . '/_layout_top.php';
?>
<div class="row justify-content-center">
  <div class="col-md-7 col-lg-6">
    <div class="card p-3">
      <div class="p-3">
        <h2 class="mb-3">Register</h2>

        <form method="post" action="<?= e(url('actions/auth/register_post.php')) ?>">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label class="form-label">Name</label>
            <input class="form-control" name="name" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Email</label>
            <input class="form-control" type="email" name="email" required autocomplete="username">
          </div>

          <div class="mb-3">
            <label class="form-label">Password</label>
            <input class="form-control" type="password" name="password" required minlength="6" autocomplete="new-password">
          </div>

          <div class="mb-3">
            <label class="form-label">Confirm Password</label>
            <input class="form-control" type="password" name="password2" required minlength="6" autocomplete="new-password">
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-success">Create Account</button>
            <a class="btn btn-outline-light" href="<?= e(url('login.php')) ?>">Back to Login</a>
          </div>
        </form>

        <div class="text-secondary small mt-3">
          Note: First registered user becomes <b>admin</b> automatically.
        </div>
      </div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/_layout_bottom.php'; ?>


<?php
// ========================================
// FILE: /public/actions/auth/register_post.php (NEW FILE)
// ========================================
require_once __DIR__ . '/../../../app/bootstrap.php';

auth_start_session();
csrf_verify();

$name = trim((string)($_POST['name'] ?? ''));
$email = trim((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');
$password2 = (string)($_POST['password2'] ?? '');

if ($name === '' || $email === '' || $password === '' || $password2 === '') {
    flash_set('danger', 'All fields are required.');
    redirect('register.php');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    flash_set('danger', 'Invalid email address.');
    redirect('register.php');
}

if ($password !== $password2) {
    flash_set('danger', 'Passwords do not match.');
    redirect('register.php');
}

if (strlen($password) < 6) {
    flash_set('danger', 'Password must be at least 6 characters.');
    redirect('register.php');
}

$stmt = db()->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
if ($stmt->fetchColumn()) {
    flash_set('danger', 'Email already registered. Please login.');
    redirect('login.php');
}

$totalUsers = (int)db()->query("SELECT COUNT(*) FROM users")->fetchColumn();
$role = $totalUsers === 0 ? 'admin' : 'staff';

$hash = auth_password_hash($password);

$ins = db()->prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)");
$ins->execute([$name, $email, $hash, $role]);

$userId = (int)db()->lastInsertId();

auth_login($userId);
flash_set('success', 'Account created and logged in.');
redirect('dashboard.php');


// ========================================
// FILE: /sql/seed.sql (APPEND THIS)
// (Run once in phpMyAdmin or import)
// ========================================

// CREATE TABLE IF NOT EXISTS users (
//   id INT UNSIGNED NOT NULL AUTO_INCREMENT,
//   name VARCHAR(120) NOT NULL,
//   email VARCHAR(190) NOT NULL UNIQUE,
//   password_hash VARCHAR(255) NOT NULL,
//   role VARCHAR(50) NOT NULL DEFAULT 'staff',
//   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
//   PRIMARY KEY (id)
// ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

// -- Optional admin seed (password: admin123)
// -- Use only if you want a default login in fresh DB.
// -- INSERT INTO users (name, email, password_hash, role)
// -- VALUES ('Admin', 'admin@example.com', '$2y$10$3EoG5r8Q0l5mYfWm1x7P2u6p3p8j1nQfJXzP0dJ5YqvT1cVg9l7yW', 'admin');

