<?php
require_once __DIR__ . '/../app/bootstrap.php';

if (auth_user()) redirect('dashboard.php');
redirect('login.php');
