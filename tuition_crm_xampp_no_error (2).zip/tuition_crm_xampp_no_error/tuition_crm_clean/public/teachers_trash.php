<?php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();
$pageTitle = 'Deleted Teachers';

$rows = db()->query("
  SELECT * FROM teachers 
  WHERE deleted_at IS NOT NULL
  ORDER BY deleted_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

require __DIR__ . '/_layout_top.php';
?>

<h2 class="mb-3">Deleted Teachers</h2>

<table class="table table-dark table-hover">
<thead>
<tr>
  <th>ID</th>
  <th>Name</th>
  <th>Deleted At</th>
  <th>Actions</th>
</tr>
</thead>
<tbody>
<?php foreach ($rows as $r): ?>
<tr>
  <td><?= e($r['id']) ?></td>
  <td><?= e($r['name']) ?></td>
  <td><?= e($r['deleted_at']) ?></td>
  <td class="d-flex gap-2">

    <form method="post" action="<?= e(url('actions/teachers/restore.php')) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= e($r['id']) ?>">
      <button class="btn btn-sm btn-success">Restore</button>
    </form>

    <form method="post" action="<?= e(url('actions/teachers/force_delete.php')) ?>"
          onsubmit="return confirm('Permanently delete? This cannot be undone.')">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= e($r['id']) ?>">
      <button class="btn btn-sm btn-danger">Delete Forever</button>
    </form>

  </td>
</tr>
<?php endforeach; ?>
<?php if (!$rows): ?>
<tr><td colspan="4" class="text-center">Trash empty</td></tr>
<?php endif; ?>
</tbody>
</table>

<?php require __DIR__ . '/_layout_bottom.php'; ?>
