<?php
// public/teachers.php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$q = trim((string)($_GET['q'] ?? ''));

if ($q !== '') {
  $stmt = db()->prepare("
    SELECT * FROM teachers
    WHERE name LIKE ? OR reg_no LIKE ? OR city LIKE ?
    ORDER BY id DESC
  ");
  $like = "%{$q}%";
  $stmt->execute([$like, $like, $like]);
  $rows = $stmt->fetchAll();
} else {
  $rows = db()->query("SELECT * FROM teachers ORDER BY id DESC")->fetchAll();
}

$pageTitle = 'Teachers';
require __DIR__ . '/_layout_top.php';
?>

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-3">
  <h2 class="mb-0">Teachers</h2>

  <div class="d-flex gap-2">
    <!-- BULK DELETE BUTTON -->
    <button type="submit"
            form="bulkDeleteForm"
            class="btn btn-danger"
            onclick="return confirm('Delete selected teachers?')">
      Bulk Delete
    </button>

    <a class="btn btn-outline-light" href="<?= e(url('dashboard.php')) ?>">Dashboard</a>
    <a class="btn btn-success" href="<?= e(url('teacher_form.php')) ?>">+ Add Teacher</a>
  </div>
</div>

<!-- SEARCH -->
<form class="row g-2 mb-3" method="get" action="<?= e(url('teachers.php')) ?>">
  <div class="col-md-10">
    <input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Search by name, reg no, city">
  </div>
  <div class="col-md-2 d-grid">
    <button class="btn btn-primary" type="submit">Search</button>
  </div>
</form>

<!-- BULK DELETE FORM START -->
<form id="bulkDeleteForm" method="post" action="<?= e(url('actions/teachers/bulk_delete.php')) ?>">
  <?= csrf_field() ?>

  <div class="card p-3">
    <div class="table-responsive">
      <table class="table table-dark table-hover align-middle">
        <thead>
          <tr>
            <!-- SELECT ALL -->
            <th>
              <input type="checkbox"
                     onclick="document.querySelectorAll('.row-check').forEach(c => c.checked = this.checked)">
            </th>
            <th>ID</th>
            <th>Date</th>
            <th>Reg No</th>
            <th>Name</th>
            <th>Phone</th>
            <th>City</th>
            <th>Home Address</th>
            <th>Subjects</th>
            <th>ID Card</th>
            <th>Document</th>
            <th style="width:190px;">Actions</th>
          </tr>
        </thead>

        <tbody>
          <?php if (!$rows): ?>
            <tr>
              <td colspan="12" class="text-center text-secondary">No records</td>
            </tr>
          <?php else: ?>
            <?php foreach ($rows as $r): ?>
              <tr>
                <!-- ROW CHECKBOX -->
                <td>
                  <input type="checkbox"
                         class="row-check"
                         name="ids[]"
                         value="<?= e((string)$r['id']) ?>">
                </td>

                <td><?= e((string)$r['id']) ?></td>
                <td><?= e((string)$r['record_date']) ?></td>
                <td><?= e((string)($r['reg_no'] ?? '')) ?></td>
                <td><?= e((string)$r['name']) ?></td>
                <td><?= e((string)($r['phoneno'] ?? '')) ?></td>
                <td><?= e((string)$r['city']) ?></td>
                <td><?= e((string)($r['home_address'] ?? '')) ?></td>
                <td><?= e((string)$r['subjects']) ?></td>

                <!-- ID FILE -->
                <td>
                  <?php if (!empty($r['teacher_id_file'])): ?>
                    <a class="btn btn-sm btn-outline-info" target="_blank"
                       href="<?= e(url('actions/teachers/file.php?path=' . urlencode($r['teacher_id_file']) . '&disposition=inline')) ?>">
                      View
                    </a>
                    <a class="btn btn-sm btn-outline-light mt-1"
                       href="<?= e(url('actions/teachers/file.php?path=' . urlencode($r['teacher_id_file']) . '&disposition=download')) ?>">
                      Download
                    </a>
                  <?php else: ?>
                    <span class="text-secondary">None</span>
                  <?php endif; ?>
                </td>

                <!-- DOC FILE -->
                <td>
                  <?php if (!empty($r['teacher_doc_file'])): ?>
                    <a class="btn btn-sm btn-outline-info" target="_blank"
                       href="<?= e(url('actions/teachers/file.php?path=' . urlencode($r['teacher_doc_file']) . '&disposition=inline')) ?>">
                      View
                    </a>
                    <a class="btn btn-sm btn-outline-light mt-1"
                       href="<?= e(url('actions/teachers/file.php?path=' . urlencode($r['teacher_doc_file']) . '&disposition=download')) ?>">
                      Download
                    </a>
                  <?php else: ?>
                    <span class="text-secondary">None</span>
                  <?php endif; ?>
                </td>

                <!-- ACTIONS -->
                <td>
                  <a class="btn btn-sm btn-warning"
                     href="<?= e(url('teacher_form.php?id=' . (int)$r['id'])) ?>">
                    Edit
                  </a>

                  <form class="d-inline"
                        method="post"
                        action="<?= e(url('actions/teachers/delete.php')) ?>"
                        onsubmit="return confirm('Delete this teacher?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= e((string)$r['id']) ?>">
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</form>
<!-- BULK DELETE FORM END -->

<?php require __DIR__ . '/_layout_bottom.php'; ?>
