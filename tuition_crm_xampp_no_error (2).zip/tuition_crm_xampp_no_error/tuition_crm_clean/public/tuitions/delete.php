<?php
require_once __DIR__ . '/../../app/bootstrap.php';
require_auth();
csrf_verify();

$stmt = db()->prepare("DELETE FROM tuitions WHERE id = ?");
$stmt->execute([$_POST['id']]);

flash_set('success','Tuition deleted');
redirect(url('tuitions.php'));
