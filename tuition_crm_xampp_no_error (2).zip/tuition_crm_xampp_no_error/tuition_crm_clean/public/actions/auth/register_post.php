<?php
// /public/actions/auth/register_post.php
require_once __DIR__ . '/../../../app/bootstrap.php';

auth_start_session();
csrf_verify();

$name = trim((string)($_POST['name'] ?? ''));
$email = trim((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');
$password2 = (string)($_POST['password2'] ?? '');

if ($name === '' || $email === '' || $password === '' || $password2 === '') {
  flash_set('danger', 'All fields are required.');
  redirect('register.php');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  flash_set('danger', 'Invalid email.');
  redirect('register.php');
}

if ($password !== $password2) {
  flash_set('danger', 'Passwords do not match.');
  redirect('register.php');
}

$stmt = db()->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
if ($stmt->fetchColumn()) {
  flash_set('danger', 'Email already registered. Please login.');
  redirect('login.php');
}

$totalUsers = (int)db()->query("SELECT COUNT(*) FROM users")->fetchColumn();
$role = $totalUsers === 0 ? 'admin' : 'staff';

$hash = auth_password_hash($password);

$ins = db()->prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)");
$ins->execute([$name, $email, $hash, $role]);

auth_login((int)db()->lastInsertId());
flash_set('success', 'Account created.');
redirect('dashboard.php');
