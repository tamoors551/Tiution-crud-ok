<?php
/**
 * ------------------------------------------------------------
 * Teacher Delete Action – Version 2 (Advanced & Safe)
 * ------------------------------------------------------------
 * ✔ Login required
 * ✔ Admin only delete
 * ✔ POST only
 * ✔ CSRF protected
 * ✔ Validates teacher ID
 * ✔ Soft delete (recoverable)
 * ✔ Transaction-safe
 * ✔ Activity log entry
 * ✔ Clear user feedback
 * ------------------------------------------------------------
 */

require_once __DIR__ . '/../../app/bootstrap.php';

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/
require_auth();
$user = auth_user();

/*
|--------------------------------------------------------------------------
| Authorization (Admin Only)
|--------------------------------------------------------------------------
*/
if (strtolower((string)($user['role'] ?? '')) !== 'admin') {
    flash_set('error', 'You are not allowed to delete teachers.');
    redirect('teachers.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Allow POST only
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    flash_set('error', 'Invalid request.');
    redirect('teachers.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| CSRF Protection
|--------------------------------------------------------------------------
*/
csrf_verify();

/*
|--------------------------------------------------------------------------
| Validate Teacher ID
|--------------------------------------------------------------------------
*/
$teacher_id = $_POST['id'] ?? null;

if (!$teacher_id || !ctype_digit((string)$teacher_id)) {
    flash_set('error', 'Teacher ID missing. Please refresh and try again.');
    redirect('teachers.php');
    exit;
}

$teacher_id = (int)$teacher_id;

/*
|--------------------------------------------------------------------------
| Fetch Teacher (must exist & not deleted)
|--------------------------------------------------------------------------
*/
$stmt = db()->prepare("
    SELECT id, name 
    FROM teachers 
    WHERE id = ? AND deleted_at IS NULL
    LIMIT 1
");
$stmt->execute([$teacher_id]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    flash_set('error', 'Teacher not found or already deleted.');
    redirect('teachers.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Begin Transaction
|--------------------------------------------------------------------------
*/
db()->beginTransaction();

try {

    /*
    |--------------------------------------------------------------------------
    | Soft Delete (recommended)
    |--------------------------------------------------------------------------
    */
    $del = db()->prepare("
        UPDATE teachers
        SET deleted_at = NOW()
        WHERE id = ?
    ");
    $del->execute([$teacher_id]);

    /*
    |--------------------------------------------------------------------------
    | Activity Log
    |--------------------------------------------------------------------------
    */
    $log = db()->prepare("
        INSERT INTO activity_log
        (user_id, action, entity, entity_id, details, ip, created_at)
        VALUES (?, 'DELETE', 'teacher', ?, ?, ?, NOW())
    ");

    $log->execute([
        $user['id'],
        $teacher_id,
        'Teacher "' . $teacher['name'] . '" soft deleted',
        $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ]);

    /*
    |--------------------------------------------------------------------------
    | Commit
    |--------------------------------------------------------------------------
    */
    db()->commit();

    flash_set(
        'success',
        'Teacher "' . e($teacher['name']) . '" deleted successfully.'
    );

} catch (Throwable $e) {

    db()->rollBack();

    flash_set(
        'error',
        'Delete failed. No data was changed.'
    );
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/
redirect('teachers.php');
exit;


