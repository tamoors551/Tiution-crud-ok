<?php
require_once __DIR__ . '/../../../app/bootstrap.php';
require_auth();
csrf_verify();

$id = (int)($_POST['id'] ?? 0);
if (!$id) { flash_set('danger','Invalid request.'); redirect('teachers.php'); }

$stmt = db()->prepare("SELECT * FROM teachers WHERE id=?");
$stmt->execute([$id]);
$existing = $stmt->fetch();
if (!$existing) { flash_set('danger','Teacher not found.'); redirect('teachers.php'); }

$idFile = $existing['teacher_id_file'];
$docFile = $existing['teacher_doc_file'];

try {
  $newId = store_upload('teacher_id', 'teacher_id', ['png','jpg','jpeg','pdf']);
  if ($newId) $idFile = $newId;

  $newDoc = store_upload('teacher_doc', 'teacher_docs', ['pdf','doc','docx']);
  if ($newDoc) $docFile = $newDoc;
} catch (Throwable $e) {
  flash_set('danger', $e->getMessage());
  redirect('teacher_form.php?id=' . $id);
}

$data = [
  'id' => $id,
  'record_date' => $_POST['record_date'] ?? '',
  'reg_no' => $_POST['reg_no'] ?? null,
  'name' => $_POST['name'] ?? '',
  'phoneno' => $_POST['phoneno'] ?? null,
  'email' => $_POST['email'] ?? null,
  'qualification' => $_POST['qualification'] ?? null,
  'experience_years' => ($_POST['experience_years'] ?? '') !== '' ? (int)$_POST['experience_years'] : null,
  'subjects' => $_POST['subjects'] ?? '',
  'city' => $_POST['city'] ?? '',
  'home_address' => $_POST['home_address'] ?? null,
  'fee_range' => $_POST['fee_range'] ?? null,
  'availability' => $_POST['availability'] ?? null,
  'mode' => $_POST['mode'] ?? 'online',
  'device' => $_POST['device'] ?? 'laptop',
  'teacher_id_file' => $idFile,
  'teacher_doc_file' => $docFile,
];

$stmt = db()->prepare("
  UPDATE teachers SET
    record_date=:record_date,
    reg_no=:reg_no,
    name=:name,
    phoneno=:phoneno,
    email=:email,
    qualification=:qualification,
    experience_years=:experience_years,
    subjects=:subjects,
    city=:city,
    home_address=:home_address,
    fee_range=:fee_range,
    availability=:availability,
    mode=:mode,
    device=:device,
    teacher_id_file=:teacher_id_file,
    teacher_doc_file=:teacher_doc_file
  WHERE id=:id
");
$stmt->execute($data);

flash_set('success', 'Teacher updated.');
redirect('teachers.php');


// /* ---- /public/actions/teachers/update.php (after successful update) ---- */
require_once __DIR__ . '/../../../app/bootstrap.php';
require_auth();

// ... perform update, $id is teacher id ...
// You can include only changed fields if you track them; here's a simple summary
audit('update', 'teacher', (int)$id, json_encode([
    'updated' => array_keys($_POST),
]));

// redirect