<?php
require_once __DIR__ . '/../../../app/bootstrap.php';
require_auth();

$path = (string)($_GET['path'] ?? '');
$disp = (string)($_GET['disposition'] ?? 'inline');

if ($path === '') {
  http_response_code(404);
  exit('File not found');
}

try {
  $full = absolute_upload_path($path);
} catch (Throwable $e) {
  http_response_code(404);
  exit('File not found');
}

$filename = basename($full);
$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

$mimeMap = [
  'pdf' => 'application/pdf',
  'png' => 'image/png',
  'jpg' => 'image/jpeg',
  'jpeg' => 'image/jpeg',
  'doc' => 'application/msword',
  'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];

$mime = $mimeMap[$ext] ?? 'application/octet-stream';

header('Content-Type: ' . $mime);
header('X-Content-Type-Options: nosniff');

if ($disp === 'download') {
  header('Content-Disposition: attachment; filename="' . $filename . '"');
} else {
  header('Content-Disposition: inline; filename="' . $filename . '"');
}

header('Content-Length: ' . filesize($full));
readfile($full);
exit;
