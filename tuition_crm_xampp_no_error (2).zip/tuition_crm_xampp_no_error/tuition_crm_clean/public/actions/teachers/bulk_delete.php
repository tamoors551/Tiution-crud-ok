<?php
/**
 * ------------------------------------------------------------
 * Bulk Teacher Delete (Safe & Production Ready)
 * ------------------------------------------------------------
 */

require_once __DIR__ . '/../../app/bootstrap.php';

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/
require_auth();
$user = auth_user();

/*
|--------------------------------------------------------------------------
| Authorization (Admin Only)
|--------------------------------------------------------------------------
*/
if (strtolower((string)($user['role'] ?? '')) !== 'admin') {
    flash_set('error', 'You are not allowed to perform bulk delete.');
    redirect('teachers.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| POST + CSRF
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    flash_set('error', 'Invalid request.');
    redirect('teachers.php');
    exit;
}

csrf_verify();

/*
|--------------------------------------------------------------------------
| Validate IDs
|--------------------------------------------------------------------------
*/
$ids = $_POST['ids'] ?? [];

if (!is_array($ids) || empty($ids)) {
    flash_set('error', 'No teachers selected.');
    redirect('teachers.php');
    exit;
}

$ids = array_filter($ids, fn($id) => ctype_digit((string)$id));
$ids = array_map('intval', $ids);

if (!$ids) {
    flash_set('error', 'Invalid teacher selection.');
    redirect('teachers.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Begin Transaction
|--------------------------------------------------------------------------
*/
db()->beginTransaction();

$deleted = 0;

try {

    /*
    |--------------------------------------------------------------------------
    | Check linked tuitions (block delete)
    |--------------------------------------------------------------------------
    */
    $check = db()->prepare("
        SELECT COUNT(*) 
        FROM tuitions 
        WHERE teacher_id = ? AND status != 'Paid'
    ");

    $delete = db()->prepare("
        UPDATE teachers
        SET deleted_at = NOW()
        WHERE id = ? AND deleted_at IS NULL
    ");

    $log = db()->prepare("
        INSERT INTO activity_log
        (user_id, action, entity, entity_id, details, ip, created_at)
        VALUES (?, 'DELETE', 'teacher', ?, ?, ?, NOW())
    ");

    foreach ($ids as $id) {

        // block delete if teacher has active tuitions
        $check->execute([$id]);
        if ((int)$check->fetchColumn() > 0) {
            continue;
        }

        $delete->execute([$id]);

        if ($delete->rowCount() > 0) {
            $deleted++;

            $log->execute([
                $user['id'],
                $id,
                'Teacher deleted via bulk action',
                $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ]);
        }
    }

    db()->commit();

    if ($deleted > 0) {
        flash_set('success', $deleted . ' teacher(s) deleted successfully.');
    } else {
        flash_set('error', 'No teachers were deleted (linked records exist).');
    }

} catch (Throwable $e) {

    db()->rollBack();

    flash_set('error', 'Bulk delete failed. No changes were made.');
}

redirect('teachers.php');
exit;
