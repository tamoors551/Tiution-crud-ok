<?php
// /public/_layout_top.php  (REPLACE FILE)
if (!isset($pageTitle)) $pageTitle = 'Tuition CRM';
$flash = flash_get();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= e($pageTitle) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= e(url('assets/app.css')) ?>" rel="stylesheet">
</head>
<body>

<!-- Top navbar -->
<header class="navbar navbar-dark bg-dark sticky-top shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand fw-semibold" href="<?= e(url('dashboard.php')) ?>">Tuition CRM</a>
    <div class="d-flex align-items-center gap-2">
      <a class="btn btn-outline-light btn-sm" href="<?= e(url('dashboard.php')) ?>">Dashboard</a>
      <a class="btn btn-outline-light btn-sm" href="<?= e(url('students.php')) ?>">Students</a>
      <a class="btn btn-outline-light btn-sm" href="<?= e(url('teachers.php')) ?>">Teachers</a>
      <a class="btn btn-outline-light btn-sm" href="<?= e(url('logout.php')) ?>">Logout</a>
    </div>
  </div>
</header>

<!-- Horizontal subnav (sticky under header) -->
<nav class="subnav">
  <div class="container-fluid">
    <ul class="nav nav-pills flex-wrap gap-2">
      <li class="nav-item">
        <a class="nav-link <?= $pageTitle==='Dashboard'?'active':'' ?>" href="<?= e(url('dashboard.php')) ?>">🏠 Dashboard</a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $pageTitle==='Students'?'active':'' ?>" href="<?= e(url('students.php')) ?>">🎓 Students</a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?= $pageTitle==='Teachers'?'active':'' ?>" href="<?= e(url('teachers.php')) ?>">👩‍🏫 Teachers</a>
      </li>
      <li><span class="divider d-none d-md-inline"></span></li>
      <li class="nav-item">
        <a class="nav-link" href="<?= e(url('student_form.php')) ?>">➕ Add Student</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= e(url('teacher_form.php')) ?>">➕ Add Teacher</a>
      </li>
      <li class="nav-item">
  <a class="nav-link <?= $pageTitle==='Tuitions'?'active':'' ?>" href="<?= e(url('tuitions.php')) ?>">💵 Tuitions</a>
</li>
<li class="nav-item">
  <a class="nav-link <?= $pageTitle==='Reports'?'active':'' ?>" href="<?= e(url('reports.php')) ?>">📊 Reports</a>
</li>


      <li class="ms-auto d-none d-md-flex align-items-center">
        <span class="text-secondary small">Logged in</span>
      </li>
    </ul>
  </div>
</nav>

<!-- Page content -->
<div class="container-fluid px-3 py-3">
  <?php if ($flash): ?>
    <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
  <?php endif; ?>



  
  
