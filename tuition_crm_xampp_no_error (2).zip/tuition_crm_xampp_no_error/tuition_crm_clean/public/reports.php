<?php
// /public/reports.php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$pageTitle = 'Reports';

$u = auth_user();
$is_admin = $u && strtolower((string)($u['role'] ?? '')) === 'admin';

/** =========================
 *  Inputs
 *  ========================= */
$from       = trim((string)($_GET['from'] ?? date('Y-m-01')));
$to         = trim((string)($_GET['to'] ?? date('Y-m-t')));
$teacher_id = (int)($_GET['teacher_id'] ?? 0);
$status     = trim((string)($_GET['status'] ?? ''));
$view       = trim((string)($_GET['view'] ?? 'detail'));     // detail | monthly | teacher
$sort       = trim((string)($_GET['sort'] ?? 'pending'));    // teacher sort: pending|paid|fee|records|name
$export     = trim((string)($_GET['export'] ?? ''));         // ''|'csv_detail'|'csv_monthly'|'csv_teacher'|'pdf'
$save_name  = trim((string)($_POST['save_name'] ?? ''));     // admin only
$load_saved = (int)($_GET['load_saved'] ?? 0);               // admin only

if (!in_array($view, ['detail', 'monthly', 'teacher'], true)) $view = 'detail';

$page     = max(1, (int)($_GET['page'] ?? 1));
$per_page = 50;
$offset   = ($page - 1) * $per_page;

$allowed_status = ['Pending', 'Partial', 'Paid'];
if ($status !== '' && !in_array($status, $allowed_status, true)) $status = '';

/** =========================
 *  Helpers
 *  ========================= */
function build_query(array $overrides = [], array $remove = []): string {
  $q = array_merge($_GET, $overrides);
  foreach ($remove as $k) unset($q[$k]);
  return http_build_query($q);
}

function money_int($v): int {
  return (int)($v ?? 0);
}

function safe_pct(int $num, int $den): int {
  if ($den <= 0) return 0;
  return (int)round(($num / $den) * 100);
}

/** =========================
 *  Presets
 *  ========================= */
$today = new DateTimeImmutable('today');
$thisMonthFrom = $today->format('Y-m-01');
$thisMonthTo   = $today->format('Y-m-t');

$lastMonth = $today->modify('first day of last month');
$lastMonthFrom = $lastMonth->format('Y-m-01');
$lastMonthTo   = $lastMonth->format('Y-m-t');

$thisYearFrom = $today->format('Y-01-01');
$thisYearTo   = $today->format('Y-12-31');

/** =========================
 *  Load saved report (admin)
 *  ========================= */
if ($is_admin && $load_saved > 0) {
  try {
    $stmt = db()->prepare("SELECT query FROM saved_reports WHERE id = ?");
    $stmt->execute([$load_saved]);
    $qs = (string)$stmt->fetchColumn();
    if ($qs !== '') {
      redirect(url('reports.php?' . $qs));
    }
  } catch (Throwable $e) {
    flash_set('danger', 'Could not load saved report.');
    redirect(url('reports.php'));
  }
}

/** Teachers list */
$teachers = db()->query("SELECT id, name FROM teachers ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

/** =========================
 *  Filters -> WHERE
 *  ========================= */
$where = [];
$args  = [];

if ($from !== '')       { $where[] = "t.tuition_date >= ?"; $args[] = $from; }
if ($to !== '')         { $where[] = "t.tuition_date <= ?"; $args[] = $to; }
if ($teacher_id > 0)    { $where[] = "t.teacher_id = ?";     $args[] = $teacher_id; }
if ($status !== '')     { $where[] = "t.status = ?";         $args[] = $status; }

$sqlWhere = $where ? ("WHERE " . implode(" AND ", $where)) : "";

$baseSql = "
  FROM tuitions t
  JOIN students s ON s.id = t.student_id
  JOIN teachers te ON te.id = t.teacher_id
  $sqlWhere
";

/** =========================
 *  Summary KPIs (for current filters)
 *  ========================= */
$summaryStmt = db()->prepare("
  SELECT
    COUNT(*) AS total_records,
    COALESCE(SUM(t.monthly_fee),0) AS total_fee,
    COALESCE(SUM(t.company_share_amount),0) AS total_company_share,
    COALESCE(SUM(t.paid_to_company),0) AS total_paid_company,
    COALESCE(SUM(t.pending_to_company),0) AS total_pending_company,
    COALESCE(SUM(CASE WHEN t.status='Pending' THEN 1 ELSE 0 END),0) AS c_pending,
    COALESCE(SUM(CASE WHEN t.status='Partial' THEN 1 ELSE 0 END),0) AS c_partial,
    COALESCE(SUM(CASE WHEN t.status='Paid' THEN 1 ELSE 0 END),0) AS c_paid
  $baseSql
");
$summaryStmt->execute($args);
$summary = $summaryStmt->fetch(PDO::FETCH_ASSOC) ?: [
  'total_records' => 0,
  'total_fee' => 0,
  'total_company_share' => 0,
  'total_paid_company' => 0,
  'total_pending_company' => 0,
  'c_pending' => 0,
  'c_partial' => 0,
  'c_paid' => 0,
];

/** Status bar percentages */
$cp = (int)$summary['c_pending'];
$ct = (int)$summary['c_partial'];
$ca = (int)$summary['c_paid'];
$sumCounts = max(1, $cp + $ct + $ca);
$pPending = (int)round(($cp / $sumCounts) * 100);
$pPartial = (int)round(($ct / $sumCounts) * 100);
$pPaid    = max(0, 100 - $pPending - $pPartial);

/** =========================
 *  Monthly summary (Step-1)
 *  ========================= */
$monthlyStmt = db()->prepare("
  SELECT
    DATE_FORMAT(t.tuition_date, '%Y-%m') AS ym,
    COUNT(*) AS records,
    COALESCE(SUM(t.monthly_fee),0) AS fee_total,
    COALESCE(SUM(t.company_share_amount),0) AS company_total,
    COALESCE(SUM(t.paid_to_company),0) AS paid_total,
    COALESCE(SUM(t.pending_to_company),0) AS pending_total
  $baseSql
  GROUP BY ym
  ORDER BY ym DESC
  LIMIT 120
");
$monthlyStmt->execute($args);
$monthlyRows = $monthlyStmt->fetchAll(PDO::FETCH_ASSOC);

/** =========================
 *  Teacher summary (Step-2)
 *  ========================= */
$sortMap = [
  'pending'  => 'pending_total DESC',
  'paid'     => 'paid_total DESC',
  'fee'      => 'fee_total DESC',
  'records'  => 'records DESC',
  'name'     => 'teacher_name ASC',
];
$orderBy = $sortMap[$sort] ?? $sortMap['pending'];

$teacherSummaryStmt = db()->prepare("
  SELECT
    te.id AS teacher_id,
    te.name AS teacher_name,
    COUNT(*) AS records,
    COALESCE(SUM(t.monthly_fee),0) AS fee_total,
    COALESCE(SUM(t.company_share_amount),0) AS company_total,
    COALESCE(SUM(t.paid_to_company),0) AS paid_total,
    COALESCE(SUM(t.pending_to_company),0) AS pending_total
  $baseSql
  GROUP BY te.id, te.name
  ORDER BY $orderBy
");
$teacherSummaryStmt->execute($args);
$teacherRows = $teacherSummaryStmt->fetchAll(PDO::FETCH_ASSOC);

/** =========================
 *  Detail view queries
 *  ========================= */
$total_records = (int)$summary['total_records'];
$total_pages   = max(1, (int)ceil($total_records / $per_page));
$page          = min($page, $total_pages);
$offset        = ($page - 1) * $per_page;

$listStmt = db()->prepare("
  SELECT
    t.*,
    s.name AS student_name,
    te.name AS teacher_name
  $baseSql
  ORDER BY t.tuition_date DESC, t.id DESC
  LIMIT $per_page OFFSET $offset
");
$listStmt->execute($args);
$rows = $listStmt->fetchAll(PDO::FETCH_ASSOC);

/** Top teachers (kept, but now optional for detail view) */
$topTeachersStmt = db()->prepare("
  SELECT
    te.id AS teacher_id,
    te.name AS teacher_name,
    COALESCE(SUM(t.monthly_fee),0) AS fee_total,
    COALESCE(SUM(t.company_share_amount),0) AS company_total,
    COALESCE(SUM(t.paid_to_company),0) AS paid_total,
    COALESCE(SUM(t.pending_to_company),0) AS pending_total,
    COUNT(*) AS records
  $baseSql
  GROUP BY te.id, te.name
  ORDER BY pending_total DESC, paid_total DESC
  LIMIT 5
");
$topTeachersStmt->execute($args);
$topTeachers = $topTeachersStmt->fetchAll(PDO::FETCH_ASSOC);

/** =========================
 *  Exports
 *  ========================= */
if ($export === 'csv_detail') {
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="tuition_reports_detail.csv"');

  $exportStmt = db()->prepare("
    SELECT
      t.id,
      t.tuition_date,
      s.name AS student,
      te.name AS teacher,
      t.monthly_fee,
      t.company_share_percent,
      t.company_share_amount,
      t.paid_to_company,
      t.pending_to_company,
      t.status,
      t.notes
    $baseSql
    ORDER BY t.tuition_date DESC, t.id DESC
  ");
  $exportStmt->execute($args);

  $out = fopen('php://output', 'w');
  fputcsv($out, ['ID','Date','Student','Teacher','Fee','Share %','Company Share','Paid','Pending','Status','Notes']);
  while ($r = $exportStmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($out, [
      $r['id'], $r['tuition_date'], $r['student'], $r['teacher'],
      $r['monthly_fee'], $r['company_share_percent'], $r['company_share_amount'],
      $r['paid_to_company'], $r['pending_to_company'], $r['status'], $r['notes'],
    ]);
  }
  fclose($out);
  exit;
}

if ($export === 'csv_monthly') {
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="tuition_reports_monthly.csv"');

  $out = fopen('php://output', 'w');
  fputcsv($out, ['Month','Records','Fee Total','Company Total','Paid Total','Pending Total']);
  foreach ($monthlyRows as $m) {
    fputcsv($out, [
      $m['ym'], $m['records'], $m['fee_total'], $m['company_total'], $m['paid_total'], $m['pending_total']
    ]);
  }
  fclose($out);
  exit;
}

if ($export === 'csv_teacher') {
  if (!$is_admin) {
    flash_set('danger', 'Only admin can export Teacher Summary.');
    redirect(url('reports.php?' . build_query([], ['export'])));
  }

  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="tuition_reports_teacher_summary.csv"');

  $out = fopen('php://output', 'w');
  fputcsv($out, ['Teacher','Records','Fee Total','Company Total','Paid Total','Pending Total','Pending %']);
  foreach ($teacherRows as $t) {
    $paid = money_int($t['paid_total']);
    $pending = money_int($t['pending_total']);
    $pctPending = safe_pct($pending, max(1, $paid + $pending));
    fputcsv($out, [
      $t['teacher_name'],
      $t['records'],
      $t['fee_total'],
      $t['company_total'],
      $paid,
      $pending,
      $pctPending . '%',
    ]);
  }
  fclose($out);
  exit;
}

if ($export === 'pdf') {
  if (!$is_admin) {
    flash_set('danger', 'Only admin can export PDF.');
    redirect(url('reports.php?' . build_query([], ['export'])));
  }

  $autoload = __DIR__ . '/../vendor/autoload.php';
  if (!is_file($autoload)) {
    flash_set('danger', 'PDF export requires dompdf. Run: composer require dompdf/dompdf');
    redirect(url('reports.php?' . build_query([], ['export'])));
  }

  require_once $autoload;

  try {
    $html = '<h2 style="margin:0;">Tuition CRM - Reports</h2>';
    $html .= '<div style="margin:6px 0 14px 0; color:#555;">';
    $html .= 'From: ' . htmlspecialchars($from) . ' | To: ' . htmlspecialchars($to);
    if ($teacher_id > 0) $html .= ' | Teacher ID: ' . (int)$teacher_id;
    if ($status !== '') $html .= ' | Status: ' . htmlspecialchars($status);
    $html .= '</div>';

    $html .= '<table width="100%" cellspacing="0" cellpadding="6" border="1" style="border-collapse:collapse;font-size:12px;">';
    $html .= '<thead><tr style="background:#eee;">
      <th align="left">Month</th>
      <th align="right">Records</th>
      <th align="right">Fee</th>
      <th align="right">Company</th>
      <th align="right">Paid</th>
      <th align="right">Pending</th>
    </tr></thead><tbody>';

    foreach ($monthlyRows as $m) {
      $html .= '<tr>
        <td>' . htmlspecialchars((string)$m['ym']) . '</td>
        <td align="right">' . (int)$m['records'] . '</td>
        <td align="right">' . (int)$m['fee_total'] . '</td>
        <td align="right">' . (int)$m['company_total'] . '</td>
        <td align="right">' . (int)$m['paid_total'] . '</td>
        <td align="right">' . (int)$m['pending_total'] . '</td>
      </tr>';
    }

    $html .= '</tbody></table>';
    $html .= '<div style="margin-top:10px;font-size:11px;color:#666;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    
    
    $dompdf = new Dompdf\Dompdf(['isRemoteEnabled' => true]);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $dompdf->stream('tuition_reports.pdf', ['Attachment' => true]);
    exit;
  } catch (Throwable $e) {
    flash_set('danger', 'PDF export failed: ' . $e->getMessage());
    redirect(url('reports.php?' . build_query([], ['export'])));
  }
}

/** =========================
 *  Saved reports (admin-only)
 *  ========================= */
if ($is_admin && $save_name !== '') {
  try {
    $queryString = build_query([], ['export', 'load_saved', 'page']); // keep stable
    $stmt = db()->prepare("INSERT INTO saved_reports (user_id, name, query) VALUES (?, ?, ?)");
    $stmt->execute([(int)($u['id'] ?? 0), mb_substr($save_name, 0, 120), $queryString]);
    flash_set('success', 'Saved report created.');
  } catch (Throwable $e) {
    flash_set('danger', 'Saving report failed. Ensure saved_reports table exists.');
  }
  redirect(url('reports.php?' . build_query([], ['export'])));
}

$savedReports = [];
if ($is_admin) {
  try {
    $savedReports = db()->query("SELECT id, name, created_at FROM saved_reports ORDER BY id DESC LIMIT 30")->fetchAll(PDO::FETCH_ASSOC);
  } catch (Throwable $e) {
    $savedReports = [];
  }
}

/** =========================
 *  Step-3 Auto monthly (foundation)
 *  ========================= */
$is_first_day = (int)date('j') === 1;

require __DIR__ . '/_layout_top.php';

/** =========================
 *  Chart data (Chart.js)
 *  ========================= */
$chartLabels = [];
$chartCompany = [];
$chartPaid = [];
$chartPending = [];

$monthlyAsc = array_reverse($monthlyRows);
foreach ($monthlyAsc as $m) {
  $chartLabels[] = (string)$m['ym'];
  $chartCompany[] = (int)$m['company_total'];
  $chartPaid[] = (int)$m['paid_total'];
  $chartPending[] = (int)$m['pending_total'];
}
?>

<div class="report-page">

  <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
      <h2 class="mb-1">Reports</h2>
      <div class="text-secondary small">
        Filter by date / teacher / status • Views: Detail, Monthly, Teachers • Charts + Exports
      </div>
      <?php if ($is_first_day): ?>
        <div class="alert alert-warning py-2 mt-2 mb-0">
          Month started today. Tip: review last month quickly using <b>Last Month</b> preset.
        </div>
      <?php endif; ?>
    </div>

    <div class="d-flex gap-2 flex-wrap align-items-center">
      <a class="btn btn-outline-light btn-sm" href="?<?= e(build_query(['from'=>$thisMonthFrom,'to'=>$thisMonthTo,'page'=>1])) ?>">This Month</a>
      <a class="btn btn-outline-light btn-sm" href="?<?= e(build_query(['from'=>$lastMonthFrom,'to'=>$lastMonthTo,'page'=>1])) ?>">Last Month</a>
      <a class="btn btn-outline-light btn-sm" href="?<?= e(build_query(['from'=>$thisYearFrom,'to'=>$thisYearTo,'page'=>1])) ?>">This Year</a>

      <div class="btn-group ms-sm-2" role="group" aria-label="View">
        <a class="btn btn-sm btn-outline-light <?= $view==='detail'?'active':'' ?>"
           href="?<?= e(build_query(['view'=>'detail','page'=>1])) ?>">Detail</a>
        <a class="btn btn-sm btn-outline-light <?= $view==='monthly'?'active':'' ?>"
           href="?<?= e(build_query(['view'=>'monthly','page'=>1])) ?>">Monthly</a>
        <a class="btn btn-sm btn-outline-light <?= $view==='teacher'?'active':'' ?>"
           href="?<?= e(build_query(['view'=>'teacher','page'=>1])) ?>">Teachers</a>
      </div>

      <div class="btn-group ms-sm-1" role="group" aria-label="Export">
        <a class="btn btn-sm btn-primary" href="?<?= e(build_query(['export'=>$view==='monthly'?'csv_monthly':'csv_detail'])) ?>">Export CSV</a>
        <?php if ($view === 'teacher'): ?>
          <a class="btn btn-sm btn-primary <?= $is_admin?'':'disabled' ?>" href="?<?= e(build_query(['export'=>'csv_teacher'])) ?>">Teacher CSV</a>
        <?php endif; ?>
        <a class="btn btn-sm btn-danger <?= $is_admin?'':'disabled' ?>" href="?<?= e(build_query(['export'=>'pdf'])) ?>">PDF</a>
      </div>
    </div>
  </div>

  <!-- Filters -->
  <form class="row g-2 mb-3" method="get">
    <input type="hidden" name="view" value="<?= e($view) ?>">
    <input type="hidden" name="page" value="1">

    <div class="col-md-3">
      <label class="form-label">From</label>
      <input type="date" class="form-control" name="from" value="<?= e($from) ?>">
    </div>

    <div class="col-md-3">
      <label class="form-label">To</label>
      <input type="date" class="form-control" name="to" value="<?= e($to) ?>">
    </div>

    <div class="col-md-3">
      <label class="form-label">Teacher</label>
      <select class="form-select" name="teacher_id">
        <option value="0">All</option>
        <?php foreach ($teachers as $t): ?>
          <option value="<?= e((string)$t['id']) ?>" <?= $teacher_id===(int)$t['id']?'selected':'' ?>>
            <?= e((string)$t['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="col-md-2">
      <label class="form-label">Status</label>
      <select class="form-select" name="status">
        <option value="">All</option>
        <?php foreach (['Pending','Partial','Paid'] as $st): ?>
          <option value="<?= e($st) ?>" <?= $status===$st?'selected':'' ?>><?= e($st) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="col-md-1 d-grid align-self-end">
      <button class="btn btn-success">Go</button>
    </div>
  </form>

  <?php if ($is_admin): ?>
    <div class="card p-3 mb-3">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
        <div>
          <div class="fw-semibold">Saved Reports</div>
          <div class="text-secondary small">Save current filters / view. Load anytime.</div>
        </div>

        <form method="post" class="d-flex gap-2 flex-wrap">
          <input class="form-control form-control-sm" name="save_name" placeholder="Save name (e.g. Last Month - All)" style="min-width:260px;">
          <button class="btn btn-sm btn-outline-light">Save</button>
        </form>
      </div>

      <?php if ($savedReports): ?>
        <div class="d-flex flex-wrap gap-2 mt-2">
          <?php foreach ($savedReports as $sr): ?>
            <a class="btn btn-sm btn-outline-info"
               href="?<?= e(build_query(['load_saved'=>(int)$sr['id']], ['export'])) ?>">
              <?= e((string)$sr['name']) ?>
              <span class="text-secondary">· <?= e((string)$sr['created_at']) ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="text-secondary small mt-2">No saved reports yet (or table not created).</div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <!-- KPI cards -->
  <div class="row g-3 mb-3">
    <div class="col-md-3">
      <div class="card p-3 report-kpi">
        <div class="text-secondary small">Total Records</div>
        <div class="fs-4 fw-semibold"><?= e((string)$summary['total_records']) ?></div>
        <div class="text-secondary small mt-2">
          Pending: <?= e((string)$summary['c_pending']) ?> |
          Partial: <?= e((string)$summary['c_partial']) ?> |
          Paid: <?= e((string)$summary['c_paid']) ?>
        </div>

        <div class="report-bar mt-2" title="Status distribution">
          <span class="bar pending" style="width: <?= e((string)$pPending) ?>%"></span>
          <span class="bar partial" style="width: <?= e((string)$pPartial) ?>%"></span>
          <span class="bar paid" style="width: <?= e((string)$pPaid) ?>%"></span>
        </div>
        <div class="text-secondary small mt-1">
          <?= e((string)$pPending) ?>% Pending · <?= e((string)$pPartial) ?>% Partial · <?= e((string)$pPaid) ?>% Paid
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card p-3 report-kpi">
        <div class="text-secondary small">Total Fee</div>
        <div class="fs-4 fw-semibold"><?= e((string)$summary['total_fee']) ?></div>
        <div class="text-secondary small mt-1">Sum of monthly fees</div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card p-3 report-kpi">
        <div class="text-secondary small">Company Share</div>
        <div class="fs-4 fw-semibold"><?= e((string)$summary['total_company_share']) ?></div>
        <div class="text-secondary small mt-1">Company share total</div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card p-3 report-kpi">
        <div class="text-secondary small">Paid / Pending</div>
        <div class="fs-6 fw-semibold">Paid: <?= e((string)$summary['total_paid_company']) ?></div>
        <div class="fs-6 fw-semibold">Pending: <?= e((string)$summary['total_pending_company']) ?></div>
        <div class="text-secondary small mt-1">Company cashflow</div>
      </div>
    </div>
  </div>

  <!-- Step-3 Charts -->
  <div class="row g-3 mb-3">
    <div class="col-lg-6">
      <div class="card p-3">
        <div class="d-flex justify-content-between align-items-center">
          <div class="fw-semibold">Company Share by Month</div>
          <div class="text-secondary small">Current filters</div>
        </div>
        <div class="mt-2">
          <canvas id="chartCompany" height="120"></canvas>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="card p-3">
        <div class="d-flex justify-content-between align-items-center">
          <div class="fw-semibold">Paid vs Pending by Month</div>
          <div class="text-secondary small">Current filters</div>
        </div>
        <div class="mt-2">
          <canvas id="chartCash" height="120"></canvas>
        </div>
      </div>
    </div>
  </div>

  <?php if ($view === 'teacher'): ?>

    <!-- Step-2 Teacher Summary -->
    <div class="card p-3">
      <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
        <div>
          <h5 class="mb-0">Teacher Summary</h5>
          <div class="text-secondary small">All teachers, sortable, drill-down to Monthly</div>
        </div>

        <div class="btn-group" role="group" aria-label="Sort">
          <a class="btn btn-sm btn-outline-light <?= $sort==='pending'?'active':'' ?>" href="?<?= e(build_query(['sort'=>'pending'])) ?>">Pending</a>
          <a class="btn btn-sm btn-outline-light <?= $sort==='paid'?'active':'' ?>" href="?<?= e(build_query(['sort'=>'paid'])) ?>">Paid</a>
          <a class="btn btn-sm btn-outline-light <?= $sort==='fee'?'active':'' ?>" href="?<?= e(build_query(['sort'=>'fee'])) ?>">Fee</a>
          <a class="btn btn-sm btn-outline-light <?= $sort==='records'?'active':'' ?>" href="?<?= e(build_query(['sort'=>'records'])) ?>">Records</a>
          <a class="btn btn-sm btn-outline-light <?= $sort==='name'?'active':'' ?>" href="?<?= e(build_query(['sort'=>'name'])) ?>">Name</a>
        </div>
      </div>

      <div class="table-responsive">
        <table class="table table-dark table-hover align-middle mb-0">
          <thead>
            <tr>
              <th>Teacher</th>
              <th>Records</th>
              <th>Fee Total</th>
              <th>Company Total</th>
              <th>Paid</th>
              <th>Pending</th>
              <th>Risk</th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$teacherRows): ?>
            <tr><td colspan="7" class="text-center text-secondary">No teachers for selected filters.</td></tr>
          <?php else: ?>
            <?php foreach ($teacherRows as $t): ?>
              <?php
                $paid = money_int($t['paid_total']);
                $pending = money_int($t['pending_total']);
                $totalCash = max(1, $paid + $pending);
                $pendingPct = safe_pct($pending, $totalCash);

                $riskClass = $pendingPct >= 60 ? 'danger' : ($pendingPct >= 30 ? 'warning' : 'success');
              ?>
              <tr>
                <td class="fw-semibold">
                  <a class="text-decoration-none"
                     href="?<?= e(build_query(['view'=>'monthly','teacher_id'=>(int)$t['teacher_id'],'page'=>1])) ?>">
                    <?= e((string)$t['teacher_name']) ?>
                  </a>
                </td>
                <td><?= e((string)$t['records']) ?></td>
                <td><?= e((string)$t['fee_total']) ?></td>
                <td><?= e((string)$t['company_total']) ?></td>
                <td><?= e((string)$paid) ?></td>
                <td class="fw-semibold"><?= e((string)$pending) ?></td>
                <td>
                  <span class="badge bg-<?= e($riskClass) ?>">
                    <?= e((string)$pendingPct) ?>% Pending
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div class="text-secondary small mt-2">
        Drill-down: click a teacher → monthly view filtered to that teacher.
      </div>
    </div>

  <?php elseif ($view === 'monthly'): ?>

    <!-- MONTHLY SUMMARY -->
    <div class="card p-3">
      <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
        <div>
          <h5 class="mb-0">Monthly Summary</h5>
          <div class="text-secondary small">Grouped by month (max 120 months)</div>
        </div>
        <div class="text-secondary small">
          Drill-down: click month → open Detail for that month.
        </div>
      </div>

      <div class="table-responsive">
        <table class="table table-dark table-hover align-middle mb-0">
          <thead>
            <tr>
              <th>Month</th>
              <th>Records</th>
              <th>Fee Total</th>
              <th>Company Total</th>
              <th>Paid</th>
              <th>Pending</th>
              <th>Pending %</th>
              <th style="min-width:180px;">Paid vs Pending</th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$monthlyRows): ?>
            <tr><td colspan="8" class="text-center text-secondary">No data for selected filters.</td></tr>
          <?php else: ?>
            <?php foreach ($monthlyRows as $m): ?>
              <?php
                $paid = money_int($m['paid_total']);
                $pending = money_int($m['pending_total']);
                $totalCash = max(1, $paid + $pending);
                $pPaidCash = safe_pct($paid, $totalCash);
                $pPendingCash = 100 - $pPaidCash;
                $pendingPct = safe_pct($pending, $totalCash);

                $monthFrom = (string)$m['ym'] . '-01';
                $monthTo = (new DateTimeImmutable($monthFrom))->format('Y-m-t');
              ?>
              <tr>
                <td class="fw-semibold">
                  <a class="text-decoration-none"
                     href="?<?= e(build_query(['view'=>'detail','from'=>$monthFrom,'to'=>$monthTo,'page'=>1])) ?>">
                    <?= e((string)$m['ym']) ?>
                  </a>
                </td>
                <td><?= e((string)$m['records']) ?></td>
                <td><?= e((string)$m['fee_total']) ?></td>
                <td><?= e((string)$m['company_total']) ?></td>
                <td><?= e((string)$paid) ?></td>
                <td><?= e((string)$pending) ?></td>
                <td>
                  <span class="badge bg-<?= $pendingPct >= 60 ? 'danger' : ($pendingPct >= 30 ? 'warning' : 'success') ?>">
                    <?= e((string)$pendingPct) ?>%
                  </span>
                </td>
                <td>
                  <div class="cash-bar" title="Paid <?= $pPaidCash ?>% / Pending <?= $pPendingCash ?>%">
                    <span class="cash-paid" style="width: <?= e((string)$pPaidCash) ?>%"></span>
                    <span class="cash-pending" style="width: <?= e((string)$pPendingCash) ?>%"></span>
                  </div>
                  <div class="text-secondary small mt-1">Paid <?= e((string)$pPaidCash) ?>% · Pending <?= e((string)$pPendingCash) ?>%</div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div class="text-secondary small mt-2">
        Tip: use Teacher filter to generate a teacher-only monthly statement.
      </div>
    </div>

  <?php else: ?>

    <!-- Detail view: Top teachers -->
    <?php if ($topTeachers): ?>
    <div class="card p-3 mb-3">
      <div class="d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Top Teachers (by Pending)</h5>
        <div class="text-secondary small">Top 5 based on current filters</div>
      </div>
      <div class="table-responsive mt-2">
        <table class="table table-dark table-hover align-middle mb-0">
          <thead>
            <tr>
              <th>Teacher</th>
              <th>Records</th>
              <th>Fee Total</th>
              <th>Company Total</th>
              <th>Paid</th>
              <th>Pending</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($topTeachers as $t): ?>
            <tr>
              <td>
                <a class="text-decoration-none"
                   href="?<?= e(build_query(['view'=>'monthly','teacher_id'=>(int)$t['teacher_id'],'page'=>1])) ?>">
                  <?= e((string)$t['teacher_name']) ?>
                </a>
              </td>
              <td><?= e((string)$t['records']) ?></td>
              <td><?= e((string)$t['fee_total']) ?></td>
              <td><?= e((string)$t['company_total']) ?></td>
              <td><?= e((string)$t['paid_total']) ?></td>
              <td><?= e((string)$t['pending_total']) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>

    <!-- Detail table -->
    <div class="card p-3">
      <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
        <div class="text-secondary small">
          Showing <?= e((string)count($rows)) ?> rows • Page <?= e((string)$page) ?> of <?= e((string)$total_pages) ?> • Total <?= e((string)$total_records) ?>
        </div>

        <div class="d-flex gap-2">
          <?php $prev = max(1, $page - 1); $next = min($total_pages, $page + 1); ?>
          <a class="btn btn-outline-light btn-sm <?= $page<=1?'disabled':'' ?>"
             href="?<?= e(build_query(['page'=>$prev])) ?>">← Prev</a>

          <a class="btn btn-outline-light btn-sm <?= $page>=$total_pages?'disabled':'' ?>"
             href="?<?= e(build_query(['page'=>$next])) ?>">Next →</a>
        </div>
      </div>

      <div class="table-responsive">
        <table class="table table-dark table-hover align-middle">
          <thead>
            <tr>
              <th>ID</th>
              <th>Date</th>
              <th>Student</th>
              <th>Teacher</th>
              <th>Fee</th>
              <th>Company Amt</th>
              <th>Paid</th>
              <th>Pending</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $sumFee = 0; $sumCompany = 0; $sumPaid = 0; $sumPending = 0;
            ?>
            <?php foreach ($rows as $r): ?>
              <?php
                $sumFee     += (int)$r['monthly_fee'];
                $sumCompany += (int)$r['company_share_amount'];
                $sumPaid    += (int)$r['paid_to_company'];
                $sumPending += (int)$r['pending_to_company'];
                $badge = $r['status']==='Paid' ? 'success' : ($r['status']==='Partial' ? 'warning' : 'secondary');
              ?>
              <tr>
                <td><?= e((string)$r['id']) ?></td>
                <td><?= e((string)$r['tuition_date']) ?></td>
                <td><?= e((string)$r['student_name']) ?></td>
                <td><?= e((string)$r['teacher_name']) ?></td>
                <td><?= e((string)$r['monthly_fee']) ?></td>
                <td><?= e((string)$r['company_share_amount']) ?></td>
                <td><?= e((string)$r['paid_to_company']) ?></td>
                <td><?= e((string)$r['pending_to_company']) ?></td>
                <td><span class="badge bg-<?= e($badge) ?>"><?= e((string)$r['status']) ?></span></td>
              </tr>
            <?php endforeach; ?>

            <?php if (!$rows): ?>
              <tr><td colspan="9" class="text-center text-secondary">No report data</td></tr>
            <?php else: ?>
              <tr class="report-total-row">
                <td colspan="4" class="text-end fw-semibold">Page Totals:</td>
                <td class="fw-semibold"><?= e((string)$sumFee) ?></td>
                <td class="fw-semibold"><?= e((string)$sumCompany) ?></td>
                <td class="fw-semibold"><?= e((string)$sumPaid) ?></td>
                <td class="fw-semibold"><?= e((string)$sumPending) ?></td>
                <td></td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div class="text-secondary small mt-2">
        Tip: switch to Monthly for trends; Teachers for risk table.
      </div>
    </div>

  <?php endif; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
  const labels = <?= json_encode($chartLabels, JSON_UNESCAPED_SLASHES) ?>;
  const company = <?= json_encode($chartCompany, JSON_UNESCAPED_SLASHES) ?>;
  const paid = <?= json_encode($chartPaid, JSON_UNESCAPED_SLASHES) ?>;
  const pending = <?= json_encode($chartPending, JSON_UNESCAPED_SLASHES) ?>;

  const elCompany = document.getElementById('chartCompany');
  if (elCompany) {
    new Chart(elCompany, {
      type: 'line',
      data: {
        labels,
        datasets: [{ label: 'Company Share', data: company, borderWidth: 2, tension: 0.25 }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: true } },
        scales: { y: { beginAtZero: true } }
      }
    });
  }

  const elCash = document.getElementById('chartCash');
  if (elCash) {
    new Chart(elCash, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          { label: 'Paid', data: paid, borderWidth: 1 },
          { label: 'Pending', data: pending, borderWidth: 1 },
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: true } },
        scales: { y: { beginAtZero: true } }
      }
    });
  }
</script>

<?php require __DIR__ . '/_layout_bottom.php'; ?>
