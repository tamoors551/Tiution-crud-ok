<?php
// /public/login.php
require_once __DIR__ . '/../app/bootstrap.php';

$pageTitle = 'Login';
require __DIR__ . '/_layout_top.php';
?>

<div class="row justify-content-center">
  <div class="col-md-6 col-lg-5">
    <div class="card p-4">
      <h2 class="mb-4">Login</h2>

      <form method="post" action="<?= e(url('actions/auth/login_post.php')) ?>">
        <?= csrf_field() ?>

        <div class="mb-3">
          <label class="form-label">Email</label>
          <input class="form-control" type="email" name="email" required autocomplete="username">
        </div>

        <div class="mb-3">
          <label class="form-label">Password</label>
          <input class="form-control" type="password" name="password" required autocomplete="current-password">
        </div>

        <button class="btn btn-primary w-100">Login</button>
      </form>

      <div class="d-flex justify-content-between align-items-center mt-3">
        <div class="text-secondary small">Default admin: admin@local.test / admin123</div>
        <a class="btn btn-outline-light btn-sm" href="<?= e(url('register.php')) ?>">Register</a>
      </div>
    </div>
  </div>
</div>

<?php require __DIR__ . '/_layout_bottom.php'; ?>
