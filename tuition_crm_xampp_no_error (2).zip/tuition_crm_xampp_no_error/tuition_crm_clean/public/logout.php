<?php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$pageTitle = 'Logout';
require __DIR__ . '/_layout_top.php';
?>
<div class="card p-4">
  <h4>Logout</h4>
  <p>Are you sure you want to logout?</p>
  <form method="post" action="<?= e(url('actions/auth/logout_post.php')) ?>">
    <?= csrf_field() ?>
    <button class="btn btn-danger">Logout</button>
    <a class="btn btn-secondary" href="<?= e(url('dashboard.php')) ?>">Cancel</a>
  </form>
</div>
<?php require __DIR__ . '/_layout_bottom.php'; ?>
