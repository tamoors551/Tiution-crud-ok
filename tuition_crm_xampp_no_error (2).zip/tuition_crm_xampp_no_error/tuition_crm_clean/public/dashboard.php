<?php
// /public/dashboard.php
require_once __DIR__ . '/../app/bootstrap.php';
require_auth();

$u         = auth_user();
$pageTitle = 'Dashboard';
$is_admin  = $u && strtolower((string)($u['role'] ?? '')) === 'admin';

/*
|--------------------------------------------------------------------------
| Helpers (safe + readable)
|--------------------------------------------------------------------------
*/
function pct_int($num, $den): int {
  $den = max(1, (int)$den);
  return (int) round(((int)$num / $den) * 100);
}
function safe_ym($ym): string {
  return preg_match('/^\d{4}\-\d{2}$/', (string)$ym) ? (string)$ym : date('Y-m');
}
function safe_date($d, $fallback): string {
  return preg_match('/^\d{4}\-\d{2}\-\d{2}$/', (string)$d) ? (string)$d : (string)$fallback;
}
function human_when($ts): string {
  $t = strtotime((string)$ts);
  if (!$t) return (string)$ts;

  $days = (int) floor((time() - $t) / 86400);
  if ($days <= 0) return 'Today';
  if ($days === 1) return 'Yesterday';
  return $days . ' days ago';
}
function money_fmt($n): string {
  // Use commas for readability:
  return number_format((float)$n, 0, '.', ',');
}
function clamp_int($v, $min, $max): int {
  $v = (int)$v;
  if ($v < $min) return $min;
  if ($v > $max) return $max;
  return $v;
}
function badge_for_status($status): string {
  if ($status === 'Paid') return 'success';
  if ($status === 'Partial') return 'warning';
  return 'secondary';
}

/*
|--------------------------------------------------------------------------
| Inputs
|--------------------------------------------------------------------------
| mode=month&ym=YYYY-MM
| mode=range&from=YYYY-MM-DD&to=YYYY-MM-DD
| tab=overview|finance|risks|health|activity
| q=quick search
| export=1 (CSV export summary)
*/
$mode = trim((string)($_GET['mode'] ?? 'month'));
if (!in_array($mode, ['month', 'range'], true)) $mode = 'month';

$tab = trim((string)($_GET['tab'] ?? 'overview'));
if (!in_array($tab, ['overview','finance','risks','health','activity'], true)) $tab = 'overview';

$ym = safe_ym(trim((string)($_GET['ym'] ?? date('Y-m'))));
$from = trim((string)($_GET['from'] ?? ''));
$to   = trim((string)($_GET['to'] ?? ''));

if ($mode === 'range') {
  $period_start = safe_date($from, date('Y-m-01'));
  $period_end   = safe_date($to, date('Y-m-t'));
} else {
  $period_start = $ym . '-01';
  $period_end   = date('Y-m-t', strtotime($period_start));
}

$prev_month_ym = date('Y-m', strtotime($period_start . ' -1 month'));
$next_month_ym = date('Y-m', strtotime($period_start . ' +1 month'));
$this_month_ym = date('Y-m');

$q = trim((string)($_GET['q'] ?? ''));
$q_like = '%' . $q . '%';

$export = (int)($_GET['export'] ?? 0);

/*
|--------------------------------------------------------------------------
| Export CSV (Dashboard summary)
|--------------------------------------------------------------------------
*/
if ($export === 1) {
  $students_total = $teachers_total = $tuitions_total = 0;
  $fee_total = $share_total = $paid_total = $pending_total = 0;
  $c_paid = $c_partial = $c_pending = 0;

  try { $students_total = (int) db()->query("SELECT COUNT(*) FROM students")->fetchColumn(); } catch (Throwable $e) {}
  try { $teachers_total = (int) db()->query("SELECT COUNT(*) FROM teachers")->fetchColumn(); } catch (Throwable $e) {}
  try { $tuitions_total = (int) db()->query("SELECT COUNT(*) FROM tuitions")->fetchColumn(); } catch (Throwable $e) {}

  try {
    $stmt = db()->prepare("
      SELECT
        COALESCE(SUM(monthly_fee),0) AS fee_total,
        COALESCE(SUM(company_share_amount),0) AS share_total,
        COALESCE(SUM(paid_to_company),0) AS paid_total,
        COALESCE(SUM(pending_to_company),0) AS pending_total,
        COALESCE(SUM(CASE WHEN status='Paid' THEN 1 ELSE 0 END),0) AS c_paid,
        COALESCE(SUM(CASE WHEN status='Partial' THEN 1 ELSE 0 END),0) AS c_partial,
        COALESCE(SUM(CASE WHEN status='Pending' THEN 1 ELSE 0 END),0) AS c_pending
      FROM tuitions
      WHERE tuition_date BETWEEN ? AND ?
    ");
    $stmt->execute([$period_start, $period_end]);
    $r = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    $fee_total     = (int)($r['fee_total'] ?? 0);
    $share_total   = (int)($r['share_total'] ?? 0);
    $paid_total    = (int)($r['paid_total'] ?? 0);
    $pending_total = (int)($r['pending_total'] ?? 0);
    $c_paid        = (int)($r['c_paid'] ?? 0);
    $c_partial     = (int)($r['c_partial'] ?? 0);
    $c_pending     = (int)($r['c_pending'] ?? 0);
  } catch (Throwable $e) {}

  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="dashboard_summary.csv"');
  $out = fopen('php://output', 'w');

  fputcsv($out, ['Dashboard Summary']);
  fputcsv($out, ['Period Start', $period_start]);
  fputcsv($out, ['Period End', $period_end]);
  fputcsv($out, []);

  fputcsv($out, ['Students Total', $students_total]);
  fputcsv($out, ['Teachers Total', $teachers_total]);
  fputcsv($out, ['Tuitions Total', $tuitions_total]);
  fputcsv($out, []);

  fputcsv($out, ['Fee Total', $fee_total]);
  fputcsv($out, ['Company Share Total', $share_total]);
  fputcsv($out, ['Paid to Company', $paid_total]);
  fputcsv($out, ['Pending to Company', $pending_total]);
  fputcsv($out, []);

  fputcsv($out, ['Paid Count', $c_paid]);
  fputcsv($out, ['Partial Count', $c_partial]);
  fputcsv($out, ['Pending Count', $c_pending]);

  fclose($out);
  exit;
}

/*
|--------------------------------------------------------------------------
| Defaults
|--------------------------------------------------------------------------
*/
$students_total = $teachers_total = $tuitions_total = 0;

$fee_total = $share_total = $paid_total = $pending_total = 0;
$c_paid = $c_partial = $c_pending = 0;

$today = date('Y-m-d');
$today_count = $today_fee = $today_share = $today_pending = 0;

$last_start = date('Y-m-01', strtotime($period_start . ' -1 month'));
$last_end   = date('Y-m-t',  strtotime($last_start));
$last_fee_total = $last_share_total = $last_paid_total = $last_pending_total = 0;

$top_share_teachers = [];
$top_pending_teachers = [];
$top_students_fee = [];
$risk_pending_rows = [];
$recent_tuitions = [];
$recent_logs = [];

$teachers_missing_docs = 0;
$teachers_missing_phone = 0;
$students_missing_phone = 0;
$students_missing_location_link = 0;

$teachers_missing_docs_list = [];
$city_students = [];
$city_teachers = [];

$search_hits_students = [];
$search_hits_teachers = [];

/*
|--------------------------------------------------------------------------
| Extra Upgrades (new features)
|--------------------------------------------------------------------------
| 1) Quick actions with "last 7 days" snapshot
| 2) Mini finance trend chart (daily totals in period)
| 3) Best day + worst day in period (by fee)
| 4) Breakdown by status amounts (share paid vs pending)
| 5) File health: teachers missing any docs list + quick link
| 6) Drill links: open Reports with prefilled filters
| 7) Smart insight text (simple rules)
| 8) Recent items: tuitions + activity log (already present) improved display
| 9) “Top pending” shows percentage of share
| 10) Performance: all queries are fail-safe and limited
*/
$trend_days = [];           // date => fee_total
$trend_company = [];        // date => company_share_amount
$trend_paid = [];           // date => paid_to_company
$trend_pending = [];        // date => pending_to_company

$best_day = ['d' => '', 'fee' => 0];
$worst_day = ['d' => '', 'fee' => 0];

$last7_start = date('Y-m-d', strtotime($today . ' -6 days'));
$last7 = [
  'cnt' => 0,
  'fee' => 0,
  'share' => 0,
  'paid' => 0,
  'pending' => 0,
];

/*
|--------------------------------------------------------------------------
| Totals
|--------------------------------------------------------------------------
*/
try { $students_total = (int) db()->query("SELECT COUNT(*) FROM students")->fetchColumn(); } catch (Throwable $e) {}
try { $teachers_total = (int) db()->query("SELECT COUNT(*) FROM teachers")->fetchColumn(); } catch (Throwable $e) {}
try { $tuitions_total = (int) db()->query("SELECT COUNT(*) FROM tuitions")->fetchColumn(); } catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Period summary
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT
      COALESCE(SUM(monthly_fee),0) AS fee_total,
      COALESCE(SUM(company_share_amount),0) AS share_total,
      COALESCE(SUM(paid_to_company),0) AS paid_total,
      COALESCE(SUM(pending_to_company),0) AS pending_total,
      COALESCE(SUM(CASE WHEN status='Paid' THEN 1 ELSE 0 END),0) AS c_paid,
      COALESCE(SUM(CASE WHEN status='Partial' THEN 1 ELSE 0 END),0) AS c_partial,
      COALESCE(SUM(CASE WHEN status='Pending' THEN 1 ELSE 0 END),0) AS c_pending
    FROM tuitions
    WHERE tuition_date BETWEEN ? AND ?
  ");
  $stmt->execute([$period_start, $period_end]);
  $r = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
  $fee_total     = (int)($r['fee_total'] ?? 0);
  $share_total   = (int)($r['share_total'] ?? 0);
  $paid_total    = (int)($r['paid_total'] ?? 0);
  $pending_total = (int)($r['pending_total'] ?? 0);
  $c_paid        = (int)($r['c_paid'] ?? 0);
  $c_partial     = (int)($r['c_partial'] ?? 0);
  $c_pending     = (int)($r['c_pending'] ?? 0);
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Last month comparison
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT
      COALESCE(SUM(monthly_fee),0) AS fee_total,
      COALESCE(SUM(company_share_amount),0) AS share_total,
      COALESCE(SUM(paid_to_company),0) AS paid_total,
      COALESCE(SUM(pending_to_company),0) AS pending_total
    FROM tuitions
    WHERE tuition_date BETWEEN ? AND ?
  ");
  $stmt->execute([$last_start, $last_end]);
  $r = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
  $last_fee_total     = (int)($r['fee_total'] ?? 0);
  $last_share_total   = (int)($r['share_total'] ?? 0);
  $last_paid_total    = (int)($r['paid_total'] ?? 0);
  $last_pending_total = (int)($r['pending_total'] ?? 0);
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Today
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT
      COUNT(*) AS cnt,
      COALESCE(SUM(monthly_fee),0) AS fee_total,
      COALESCE(SUM(company_share_amount),0) AS share_total,
      COALESCE(SUM(pending_to_company),0) AS pending_total
    FROM tuitions
    WHERE tuition_date = ?
  ");
  $stmt->execute([$today]);
  $r = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
  $today_count   = (int)($r['cnt'] ?? 0);
  $today_fee     = (int)($r['fee_total'] ?? 0);
  $today_share   = (int)($r['share_total'] ?? 0);
  $today_pending = (int)($r['pending_total'] ?? 0);
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Last 7 days snapshot (new)
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT
      COUNT(*) AS cnt,
      COALESCE(SUM(monthly_fee),0) AS fee_total,
      COALESCE(SUM(company_share_amount),0) AS share_total,
      COALESCE(SUM(paid_to_company),0) AS paid_total,
      COALESCE(SUM(pending_to_company),0) AS pending_total
    FROM tuitions
    WHERE tuition_date BETWEEN ? AND ?
  ");
  $stmt->execute([$last7_start, $today]);
  $r = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
  $last7['cnt']     = (int)($r['cnt'] ?? 0);
  $last7['fee']     = (int)($r['fee_total'] ?? 0);
  $last7['share']   = (int)($r['share_total'] ?? 0);
  $last7['paid']    = (int)($r['paid_total'] ?? 0);
  $last7['pending'] = (int)($r['pending_total'] ?? 0);
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Trend lines in selected period (new)
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT
      tuition_date,
      COALESCE(SUM(monthly_fee),0) AS fee_total,
      COALESCE(SUM(company_share_amount),0) AS share_total,
      COALESCE(SUM(paid_to_company),0) AS paid_total,
      COALESCE(SUM(pending_to_company),0) AS pending_total
    FROM tuitions
    WHERE tuition_date BETWEEN ? AND ?
    GROUP BY tuition_date
    ORDER BY tuition_date ASC
  ");
  $stmt->execute([$period_start, $period_end]);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  foreach ($rows as $rr) {
    $d = (string)$rr['tuition_date'];
    $trend_days[$d] = (int)$rr['fee_total'];
    $trend_company[$d] = (int)$rr['share_total'];
    $trend_paid[$d] = (int)$rr['paid_total'];
    $trend_pending[$d] = (int)$rr['pending_total'];
  }

  // Best/worst day by fee
  foreach ($trend_days as $d => $v) {
    if ($best_day['d'] === '' || $v > $best_day['fee']) $best_day = ['d' => $d, 'fee' => $v];
    if ($worst_day['d'] === '' || $v < $worst_day['fee']) $worst_day = ['d' => $d, 'fee' => $v];
  }
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Top teachers + students (selected period)
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->prepare("
    SELECT te.id, te.name, COALESCE(SUM(t.company_share_amount),0) AS share_sum
    FROM tuitions t
    JOIN teachers te ON te.id = t.teacher_id
    WHERE t.tuition_date BETWEEN ? AND ?
    GROUP BY te.id, te.name
    ORDER BY share_sum DESC
    LIMIT 5
  ");
  $stmt->execute([$period_start, $period_end]);
  $top_share_teachers = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $stmt = db()->prepare("
    SELECT te.id, te.name, COALESCE(SUM(t.pending_to_company),0) AS pending_sum
    FROM tuitions t
    JOIN teachers te ON te.id = t.teacher_id
    WHERE t.tuition_date BETWEEN ? AND ?
    GROUP BY te.id, te.name
    ORDER BY pending_sum DESC
    LIMIT 5
  ");
  $stmt->execute([$period_start, $period_end]);
  $top_pending_teachers = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $stmt = db()->prepare("
    SELECT s.id, s.name, COALESCE(SUM(t.monthly_fee),0) AS fee_sum
    FROM tuitions t
    JOIN students s ON s.id = t.student_id
    WHERE t.tuition_date BETWEEN ? AND ?
    GROUP BY s.id, s.name
    ORDER BY fee_sum DESC
    LIMIT 5
  ");
  $stmt->execute([$period_start, $period_end]);
  $top_students_fee = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Risk: highest pending rows
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->query("
    SELECT t.id, t.tuition_date, s.name AS student_name, te.name AS teacher_name,
           t.pending_to_company, t.status, te.id AS teacher_id
    FROM tuitions t
    JOIN students s ON s.id = t.student_id
    JOIN teachers te ON te.id = t.teacher_id
    WHERE t.pending_to_company > 0
    ORDER BY t.pending_to_company DESC, t.tuition_date DESC
    LIMIT 10
  ");
  $risk_pending_rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Recent tuitions + logs
|--------------------------------------------------------------------------
*/
try {
  $stmt = db()->query("
    SELECT t.id, t.tuition_date, s.name AS student_name, te.name AS teacher_name,
           t.monthly_fee, t.company_share_amount, t.paid_to_company, t.pending_to_company, t.status
    FROM tuitions t
    JOIN students s ON s.id = t.student_id
    JOIN teachers te ON te.id = t.teacher_id
    ORDER BY t.tuition_date DESC, t.id DESC
    LIMIT 10
  ");
  $recent_tuitions = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $stmt = db()->query("
    SELECT al.created_at, al.action, al.entity, al.entity_id, al.details, al.ip,
           u.name AS user_name
    FROM activity_log al
    LEFT JOIN users u ON u.id = al.user_id
    ORDER BY al.created_at DESC, al.id DESC
    LIMIT 10
  ");
  $recent_logs = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Health
|--------------------------------------------------------------------------
*/
try {
  $teachers_missing_docs = (int) db()->query("
    SELECT COUNT(*)
    FROM teachers
    WHERE (teacher_id_file IS NULL OR teacher_id_file = '')
       OR (teacher_doc_file IS NULL OR teacher_doc_file = '')
  ")->fetchColumn();
} catch (Throwable $e) {}

try {
  $teachers_missing_phone = (int) db()->query("
    SELECT COUNT(*) FROM teachers WHERE phoneno IS NULL OR phoneno = ''
  ")->fetchColumn();
} catch (Throwable $e) {}

try {
  $students_missing_phone = (int) db()->query("
    SELECT COUNT(*) FROM students WHERE phoneno IS NULL OR phoneno = ''
  ")->fetchColumn();
} catch (Throwable $e) {}

try {
  $students_missing_location_link = (int) db()->query("
    SELECT COUNT(*) FROM students WHERE location_link IS NULL OR location_link = ''
  ")->fetchColumn();
} catch (Throwable $e) {}

try {
  $stmt = db()->query("
    SELECT id, name, reg_no, city, teacher_id_file, teacher_doc_file
    FROM teachers
    WHERE (teacher_id_file IS NULL OR teacher_id_file = '')
       OR (teacher_doc_file IS NULL OR teacher_doc_file = '')
    ORDER BY record_date DESC, id DESC
    LIMIT 8
  ");
  $teachers_missing_docs_list = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $stmt = db()->query("
    SELECT city, COUNT(*) AS cnt
    FROM students
    GROUP BY city
    ORDER BY cnt DESC, city ASC
    LIMIT 5
  ");
  $city_students = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $stmt = db()->query("
    SELECT city, COUNT(*) AS cnt
    FROM teachers
    GROUP BY city
    ORDER BY cnt DESC, city ASC
    LIMIT 5
  ");
  $city_teachers = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

/*
|--------------------------------------------------------------------------
| Quick search
|--------------------------------------------------------------------------
*/
if ($q !== '') {
  try {
    $stmt = db()->prepare("
      SELECT id, reg_no, name, phoneno, city
      FROM students
      WHERE name LIKE ? OR reg_no LIKE ? OR phoneno LIKE ? OR city LIKE ?
      ORDER BY id DESC
      LIMIT 6
    ");
    $stmt->execute([$q_like, $q_like, $q_like, $q_like]);
    $search_hits_students = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {}

  try {
    $stmt = db()->prepare("
      SELECT id, reg_no, name, phoneno, city
      FROM teachers
      WHERE name LIKE ? OR reg_no LIKE ? OR phoneno LIKE ? OR city LIKE ?
      ORDER BY id DESC
      LIMIT 6
    ");
    $stmt->execute([$q_like, $q_like, $q_like, $q_like]);
    $search_hits_teachers = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {}
}

/*
|--------------------------------------------------------------------------
| Derived KPIs + Insights
|--------------------------------------------------------------------------
*/
$period_count = max(1, ($c_paid + $c_partial + $c_pending));
$paid_pct    = pct_int($c_paid, $period_count);
$partial_pct = pct_int($c_partial, $period_count);
$pending_pct = pct_int($c_pending, $period_count);

$collect_den = max(1, ($paid_total + $pending_total));
$collect_pct = pct_int($paid_total, $collect_den);

$share_pct_of_fee   = pct_int($share_total, max(1, $fee_total));
$pending_pct_of_sh  = pct_int($pending_total, max(1, $share_total));
$paid_pct_of_sh     = pct_int($paid_total, max(1, $share_total));

$delta_fee     = $fee_total - $last_fee_total;
$delta_share   = $share_total - $last_share_total;
$delta_paid    = $paid_total - $last_paid_total;
$delta_pending = $pending_total - $last_pending_total;

function delta_style($d): array {
  if ($d > 0) return ['text-success', '↑ ' . money_fmt($d)];
  if ($d < 0) return ['text-danger', '↓ ' . money_fmt(abs($d))];
  return ['text-secondary', '0'];
}

/* Health score */
$score = 100;
$score -= min(35, $teachers_missing_docs * 3);
$score -= min(20, $teachers_missing_phone * 2);
$score -= min(20, $students_missing_phone * 2);
$score -= min(25, $students_missing_location_link * 2);
$score = clamp_int($score, 0, 100);

/* Auto alerts */
$alerts = [];
if ($pending_total > 0) $alerts[] = "Pending amount exists in this period (company money stuck).";
if ($collect_pct < 60 && ($paid_total + $pending_total) > 0) $alerts[] = "Collection rate is low. Consider follow ups.";
if ($teachers_missing_docs > 0) $alerts[] = "Some teachers have missing documents.";
if ($teachers_missing_phone > 0) $alerts[] = "Some teachers are missing phone numbers.";
if ($students_missing_phone > 0) $alerts[] = "Some students are missing phone numbers.";
if ($students_missing_location_link > 0) $alerts[] = "Some students have missing location links.";

/* Plain-English insights (new) */
$insights = [];
if ($pending_total > 0 && $pending_pct_of_sh >= 40) $insights[] = "A large portion of company share is still pending. This usually needs payment follow up.";
if ($paid_pct >= 70) $insights[] = "Payment status looks strong. Most records are Paid in this period.";
if ($partial_pct >= 35) $insights[] = "Many records are Partial. Consider confirming the remaining balance dates.";
if ($teachers_missing_docs > 0) $insights[] = "File health is not clean. Missing documents can cause problems during verification.";
if ($best_day['d'] !== '' && $worst_day['d'] !== '' && $best_day['d'] !== $worst_day['d']) {
  $insights[] = "Best day: {$best_day['d']} (Fee " . money_fmt($best_day['fee']) . "). Worst day: {$worst_day['d']} (Fee " . money_fmt($worst_day['fee']) . ").";
}

require __DIR__ . '/_layout_top.php';
?>

<style>
  /* Wheat theme (as you asked) */
  .dash-title { color: wheat; }
  .dash-sub { color: rgba(245,222,179,0.76) !important; }

  .dash-card {
    background: linear-gradient(180deg, rgba(0,0,0,0.60), rgba(0,0,0,0.22));
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 16px;
  }

  .dash-kpi-label { color: rgba(245,222,179,0.72); font-size: 0.92rem; }
  .dash-kpi-val { color: wheat; font-weight: 850; font-size: 1.25rem; }

  .dash-pill {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 999px;
    border: 1px solid rgba(255,255,255,0.14);
    background: rgba(255,255,255,0.08);
    color: wheat;
    font-size: 0.85rem;
  }

  .dash-input label { color: wheat; font-weight: 650; }
  .dash-input input.form-control, .dash-input select.form-select {
    border-radius: 12px;
    background: #000 !important;
    color: wheat !important;
    border: 1px solid rgba(255,255,255,0.12);
  }
  .dash-input input.form-control::placeholder { color: rgba(245,222,179,0.55) !important; }

  .dash-table.card {
    background: rgba(0,0,0,0.18);
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 16px;
  }

  .progress { background: rgba(255,255,255,0.10); height: 10px; border-radius: 999px; }
  .progress-bar { border-radius: 999px; }

  .meter { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
  .meter .block {
    padding: 12px;
    border-radius: 14px;
    border: 1px solid rgba(255,255,255,0.12);
    background: rgba(255,255,255,0.06);
  }

  .tab-btns .btn { border-radius: 12px; }
  .action-bar .btn { border-radius: 12px; }

  .search-box input.form-control {
    background: #000 !important;
    color: wheat !important;
    border-radius: 14px;
    border: 1px solid rgba(255,255,255,0.12);
  }

  /* Mini trend bars (new) */
  .mini-bars { display: grid; grid-template-columns: repeat(14, 1fr); gap: 6px; align-items: end; min-height: 70px; }
  .mini-bars .bar { background: rgba(245,222,179,0.25); border: 1px solid rgba(255,255,255,0.10); border-radius: 10px; }
  .mini-bars .bar:hover { background: rgba(245,222,179,0.38); }
  .mini-bars .bar span { display:block; width:100%; height:100%; border-radius:10px; background: rgba(245,222,179,0.65); }
  .mini-note { font-size: 0.86rem; color: rgba(245,222,179,0.70); }

  .soft-divider { border-top: 1px solid rgba(255,255,255,0.10); margin: 14px 0; }
</style>

<!-- Header -->
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
  <div class="me-3">
    <h2 class="mb-1 dash-title">Dashboard</h2>
    <div class="dash-sub">
      Welcome, <?= e($u['name'] ?? 'User') ?><?= isset($u['role']) && $u['role'] ? ' ('.e($u['role']).')' : '' ?>
      <span class="ms-2 dash-pill">Health score: <?= e((string)$score) ?>/100</span>
      <span class="ms-2 dash-pill">Last 7 days: <?= e((string)$last7['cnt']) ?> records</span>
    </div>
  </div>

  <div class="d-flex gap-2 mt-2 mt-sm-0">
    <a class="btn btn-outline-light"
       href="?<?= e(http_build_query(array_merge($_GET, ['export' => 1]))) ?>">
      Export Summary CSV
    </a>
    <a class="btn btn-outline-light" href="<?= e(url('logout.php')) ?>">Logout</a>
  </div>
</div>

<!-- Quick actions bar -->
<div class="dash-card p-3 mb-3 action-bar">
  <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center">
    <div class="d-flex flex-wrap gap-2">
      <a class="btn btn-primary" href="<?= e(url('students.php')) ?>">Students</a>
      <a class="btn btn-primary" href="<?= e(url('teachers.php')) ?>">Teachers</a>
      <a class="btn btn-primary" href="<?= e(url('tuitions.php')) ?>">Tuitions</a>
      <a class="btn btn-outline-light" href="<?= e(url('reports.php')) ?>">Reports</a>
      <a class="btn btn-outline-light"
         href="<?= e(url('reports.php')) ?>?from=<?= e($period_start) ?>&to=<?= e($period_end) ?>">
        Reports for this period
      </a>
    </div>

    <?php if ($is_admin): ?>
      <div class="d-flex flex-wrap gap-2">
        <a class="btn btn-success" href="<?= e(url('student_form.php')) ?>">+ Add Student</a>
        <a class="btn btn-success" href="<?= e(url('teacher_form.php')) ?>">+ Add Teacher</a>
        <a class="btn btn-success" href="<?= e(url('tuition_form.php')) ?>">+ Add Tuition</a>
      </div>
    <?php endif; ?>
  </div>

  <div class="soft-divider"></div>

  <div class="row g-2">
    <div class="col-md-3">
      <div class="dash-kpi-label">Last 7 days fee</div>
      <div class="dash-kpi-val"><?= e(money_fmt($last7['fee'])) ?></div>
    </div>
    <div class="col-md-3">
      <div class="dash-kpi-label">Last 7 days share</div>
      <div class="dash-kpi-val"><?= e(money_fmt($last7['share'])) ?></div>
    </div>
    <div class="col-md-3">
      <div class="dash-kpi-label">Last 7 days paid</div>
      <div class="dash-kpi-val"><?= e(money_fmt($last7['paid'])) ?></div>
    </div>
    <div class="col-md-3">
      <div class="dash-kpi-label">Last 7 days pending</div>
      <div class="dash-kpi-val"><?= e(money_fmt($last7['pending'])) ?></div>
    </div>
  </div>
</div>

<!-- Auto alerts + insights -->
<?php if ($alerts || $insights): ?>
  <div class="dash-table card p-3 mb-3">
    <div class="row g-3">
      <div class="col-lg-6">
        <h5 class="dash-title mb-2">Auto alerts</h5>
        <ul class="dash-sub mb-0">
          <?php foreach ($alerts as $a): ?>
            <li><?= e($a) ?></li>
          <?php endforeach; ?>
          <?php if (!$alerts): ?>
            <li class="text-secondary">No alerts right now.</li>
          <?php endif; ?>
        </ul>
      </div>
      <div class="col-lg-6">
        <h5 class="dash-title mb-2">Insights</h5>
        <ul class="dash-sub mb-0">
          <?php foreach ($insights as $a): ?>
            <li><?= e($a) ?></li>
          <?php endforeach; ?>
          <?php if (!$insights): ?>
            <li class="text-secondary">No new insights. Add more tuition history to see trends.</li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </div>
<?php endif; ?>

<!-- Tabs -->
<div class="d-flex flex-wrap gap-2 mb-3 tab-btns">
  <a class="btn <?= $tab==='overview'?'btn-info':'btn-outline-light' ?>"
     href="?<?= e(http_build_query(array_merge($_GET, ['tab'=>'overview']))) ?>">Overview</a>
  <a class="btn <?= $tab==='finance'?'btn-info':'btn-outline-light' ?>"
     href="?<?= e(http_build_query(array_merge($_GET, ['tab'=>'finance']))) ?>">Finance</a>
  <a class="btn <?= $tab==='risks'?'btn-info':'btn-outline-light' ?>"
     href="?<?= e(http_build_query(array_merge($_GET, ['tab'=>'risks']))) ?>">Risks</a>
  <a class="btn <?= $tab==='health'?'btn-info':'btn-outline-light' ?>"
     href="?<?= e(http_build_query(array_merge($_GET, ['tab'=>'health']))) ?>">Data Health</a>
  <a class="btn <?= $tab==='activity'?'btn-info':'btn-outline-light' ?>"
     href="?<?= e(http_build_query(array_merge($_GET, ['tab'=>'activity']))) ?>">Activity</a>
</div>

<!-- Quick Search -->
<form class="row g-2 mb-3 search-box" method="get">
  <input type="hidden" name="mode" value="<?= e($mode) ?>">
  <input type="hidden" name="tab" value="<?= e($tab) ?>">
  <?php if ($mode === 'month'): ?>
    <input type="hidden" name="ym" value="<?= e($ym) ?>">
  <?php else: ?>
    <input type="hidden" name="from" value="<?= e($period_start) ?>">
    <input type="hidden" name="to" value="<?= e($period_end) ?>">
  <?php endif; ?>

  <div class="col-md-10">
    <input type="text" class="form-control" name="q"
           placeholder="Quick search: student/teacher name, reg no, phone, city"
           value="<?= e($q) ?>">
  </div>
  <div class="col-md-2 d-grid">
    <button class="btn btn-primary">Search</button>
  </div>
</form>

<?php if ($q !== ''): ?>
  <div class="row g-3 mb-3">
    <div class="col-lg-6">
      <div class="dash-table card p-3">
        <h5 class="dash-title mb-2">Student Matches</h5>
        <div class="table-responsive">
          <table class="table table-dark table-hover align-middle mb-0">
            <thead><tr><th>ID</th><th>Reg</th><th>Name</th><th>Phone</th><th>City</th></tr></thead>
            <tbody>
              <?php foreach ($search_hits_students as $x): ?>
                <tr>
                  <td><?= e((string)$x['id']) ?></td>
                  <td><?= e((string)($x['reg_no'] ?? '')) ?></td>
                  <td><?= e((string)$x['name']) ?></td>
                  <td><?= e((string)($x['phoneno'] ?? '')) ?></td>
                  <td><?= e((string)($x['city'] ?? '')) ?></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$search_hits_students): ?>
                <tr><td colspan="5" class="text-center text-secondary">No student results</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="dash-table card p-3">
        <h5 class="dash-title mb-2">Teacher Matches</h5>
        <div class="table-responsive">
          <table class="table table-dark table-hover align-middle mb-0">
            <thead><tr><th>ID</th><th>Reg</th><th>Name</th><th>Phone</th><th>City</th></tr></thead>
            <tbody>
              <?php foreach ($search_hits_teachers as $x): ?>
                <tr>
                  <td><?= e((string)$x['id']) ?></td>
                  <td><?= e((string)($x['reg_no'] ?? '')) ?></td>
                  <td><?= e((string)$x['name']) ?></td>
                  <td><?= e((string)($x['phoneno'] ?? '')) ?></td>
                  <td><?= e((string)($x['city'] ?? '')) ?></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$search_hits_teachers): ?>
                <tr><td colspan="5" class="text-center text-secondary">No teacher results</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<!-- Period filter -->
<form class="row g-2 align-items-end mb-3 dash-input" method="get">
  <input type="hidden" name="tab" value="<?= e($tab) ?>">
  <?php if ($q !== ''): ?><input type="hidden" name="q" value="<?= e($q) ?>"><?php endif; ?>

  <div class="col-md-2">
    <label class="form-label">View Mode</label>
    <select class="form-select" name="mode" onchange="this.form.submit()">
      <option value="month" <?= $mode==='month'?'selected':'' ?>>Month</option>
      <option value="range" <?= $mode==='range'?'selected':'' ?>>Custom Range</option>
    </select>
  </div>

  <?php if ($mode === 'month'): ?>
    <div class="col-md-2">
      <label class="form-label">Month</label>
      <input type="month" class="form-control" name="ym" value="<?= e($ym) ?>">
    </div>
    <div class="col-md-2 d-grid">
      <button class="btn btn-success">Apply</button>
    </div>
    <div class="col-md-6 text-end">
      <a class="btn btn-outline-light" href="?mode=month&ym=<?= e($prev_month_ym) ?>&tab=<?= e($tab) ?>">← Last</a>
      <a class="btn btn-outline-light" href="?mode=month&ym=<?= e($this_month_ym) ?>&tab=<?= e($tab) ?>">This month</a>
      <a class="btn btn-outline-light" href="?mode=month&ym=<?= e($next_month_ym) ?>&tab=<?= e($tab) ?>">Next →</a>
      <div class="dash-sub mt-2">Period: <span class="dash-pill"><?= e($period_start) ?> → <?= e($period_end) ?></span></div>
    </div>
  <?php else: ?>
    <div class="col-md-3">
      <label class="form-label">From</label>
      <input type="date" class="form-control" name="from" value="<?= e($period_start) ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">To</label>
      <input type="date" class="form-control" name="to" value="<?= e($period_end) ?>">
    </div>
    <div class="col-md-2 d-grid">
      <button class="btn btn-success">Apply</button>
    </div>
    <div class="col-md-2 d-grid">
      <a class="btn btn-outline-light" href="?mode=month&ym=<?= e($this_month_ym) ?>&tab=<?= e($tab) ?>">Back to month</a>
    </div>
    <div class="col-md-2 text-end dash-sub">
      Period: <span class="dash-pill"><?= e($period_start) ?> → <?= e($period_end) ?></span>
    </div>
  <?php endif; ?>
</form>

<?php
/*
|--------------------------------------------------------------------------
| MINI TREND BAR CALC (new)
|--------------------------------------------------------------------------
| We show up to last 14 days inside the selected period list.
| If period has fewer points, it shows fewer bars.
*/
$trend_dates = array_keys($trend_days);
$trend_count = count($trend_dates);
$trend_slice = [];

if ($trend_count > 0) {
  $trend_slice = array_slice($trend_dates, max(0, $trend_count - 14));
}
$max_fee_day = 0;
foreach ($trend_slice as $d) {
  $max_fee_day = max($max_fee_day, (int)($trend_days[$d] ?? 0));
}
$max_fee_day = max(1, $max_fee_day);
?>

<?php if ($tab === 'overview'): ?>
  <div class="row g-3 mb-3">
    <div class="col-lg-3">
      <div class="dash-card p-3 h-100">
        <div class="dash-kpi-label">Students Total</div>
        <div class="dash-kpi-val"><?= e((string)$students_total) ?></div>
        <div class="dash-sub mt-2">Records in system</div>
      </div>
    </div>

    <div class="col-lg-3">
      <div class="dash-card p-3 h-100">
        <div class="dash-kpi-label">Teachers Total</div>
        <div class="dash-kpi-val"><?= e((string)$teachers_total) ?></div>
        <div class="dash-sub mt-2">Records in system</div>
      </div>
    </div>

    <div class="col-lg-3">
      <div class="dash-card p-3 h-100">
        <div class="dash-kpi-label">Tuitions Total</div>
        <div class="dash-kpi-val"><?= e((string)$tuitions_total) ?></div>
        <div class="dash-sub mt-2">All time</div>
      </div>
    </div>

    <div class="col-lg-3">
      <div class="dash-card p-3 h-100">
        <div class="dash-kpi-label">Today</div>
        <div class="dash-kpi-val"><?= e((string)$today_count) ?> tuitions</div>
        <div class="dash-sub mt-2">Fee <?= e(money_fmt($today_fee)) ?> | Share <?= e(money_fmt($today_share)) ?></div>
      </div>
    </div>
  </div>

  <div class="dash-table card p-3 mb-3">
    <div class="d-flex justify-content-between align-items-center">
      <h5 class="dash-title mb-0">Status distribution</h5>
      <span class="dash-pill">Collection: <?= e((string)$collect_pct) ?>%</span>
    </div>

    <div class="mt-3 meter">
      <div class="block">
        <div class="dash-kpi-label">Paid</div>
        <div class="dash-kpi-val"><?= e((string)$c_paid) ?> (<?= e((string)$paid_pct) ?>%)</div>
      </div>
      <div class="block">
        <div class="dash-kpi-label">Partial</div>
        <div class="dash-kpi-val"><?= e((string)$c_partial) ?> (<?= e((string)$partial_pct) ?>%)</div>
      </div>
      <div class="block">
        <div class="dash-kpi-label">Pending</div>
        <div class="dash-kpi-val"><?= e((string)$c_pending) ?> (<?= e((string)$pending_pct) ?>%)</div>
      </div>
    </div>

    <div class="mt-3">
      <div class="d-flex justify-content-between dash-sub">
        <span>Paid vs Pending (Company Share)</span>
        <span>Paid <?= e((string)$paid_pct_of_sh) ?>% | Pending <?= e((string)$pending_pct_of_sh) ?>%</span>
      </div>
      <div class="progress">
        <div class="progress-bar" role="progressbar" style="width: <?= e((string)$paid_pct_of_sh) ?>%"></div>
      </div>
    </div>
  </div>

  <div class="dash-table card p-3 mb-3">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <h5 class="dash-title mb-0">Fee trend (last points in period)</h5>
      <span class="mini-note">Bars are relative inside the selected period</span>
    </div>

    <?php if (!$trend_slice): ?>
      <div class="text-secondary">No trend data yet. Add more tuition rows with different dates.</div>
    <?php else: ?>
      <div class="mini-bars">
        <?php foreach ($trend_slice as $d): ?>
          <?php
            $v = (int)($trend_days[$d] ?? 0);
            $h = (int) round(($v / $max_fee_day) * 100);
            $h = clamp_int($h, 6, 100);
          ?>
          <div class="bar" title="<?= e($d) ?> | Fee <?= e(money_fmt($v)) ?>" style="height: 70px;">
            <span style="height: <?= e((string)$h) ?>%;"></span>
          </div>
        <?php endforeach; ?>
      </div>
      <div class="dash-sub mt-2">
        Best day: <span class="dash-pill"><?= e($best_day['d'] ?: '-') ?></span>
        <span class="ms-1">Fee <?= e(money_fmt($best_day['fee'])) ?></span>
        <span class="mx-2">|</span>
        Worst day: <span class="dash-pill"><?= e($worst_day['d'] ?: '-') ?></span>
        <span class="ms-1">Fee <?= e(money_fmt($worst_day['fee'])) ?></span>
      </div>
    <?php endif; ?>
  </div>

  <div class="row g-3">
    <div class="col-lg-6">
      <div class="dash-table card p-3 h-100">
        <h5 class="dash-title mb-2">Top student cities</h5>
        <div class="table-responsive">
          <table class="table table-dark table-hover align-middle mb-0">
            <thead><tr><th>City</th><th class="text-end">Students</th></tr></thead>
            <tbody>
              <?php foreach ($city_students as $x): ?>
                <tr><td><?= e((string)$x['city']) ?></td><td class="text-end"><?= e((string)$x['cnt']) ?></td></tr>
              <?php endforeach; ?>
              <?php if (!$city_students): ?><tr><td colspan="2" class="text-center text-secondary">No data</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="dash-table card p-3 h-100">
        <h5 class="dash-title mb-2">Top teacher cities</h5>
        <div class="table-responsive">
          <table class="table table-dark table-hover align-middle mb-0">
            <thead><tr><th>City</th><th class="text-end">Teachers</th></tr></thead>
            <tbody>
              <?php foreach ($city_teachers as $x): ?>
                <tr><td><?= e((string)$x['city']) ?></td><td class="text-end"><?= e((string)$x['cnt']) ?></td></tr>
              <?php endforeach; ?>
              <?php if (!$city_teachers): ?><tr><td colspan="2" class="text-center text-secondary">No data</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php if ($tab === 'finance'): ?>
  <?php
    [$c1,$t1] = delta_style($delta_fee);
    [$c2,$t2] = delta_style($delta_share);
    [$c3,$t3] = delta_style($delta_paid);
    [$c4,$t4] = delta_style($delta_pending);
  ?>

  <div class="row g-3 mb-3">
    <div class="col-lg-8">
      <div class="dash-card p-3 h-100">
        <h5 class="dash-title mb-2">Period finance</h5>

        <div class="row g-2">
          <div class="col-6">
            <div class="dash-kpi-label">Fee Total</div>
            <div class="dash-kpi-val"><?= e(money_fmt($fee_total)) ?></div>
          </div>
          <div class="col-6">
            <div class="dash-kpi-label">Company Share Total</div>
            <div class="dash-kpi-val"><?= e(money_fmt($share_total)) ?></div>
          </div>
          <div class="col-6">
            <div class="dash-kpi-label">Paid to Company</div>
            <div class="dash-kpi-val"><?= e(money_fmt($paid_total)) ?></div>
          </div>
          <div class="col-6">
            <div class="dash-kpi-label">Pending to Company</div>
            <div class="dash-kpi-val"><?= e(money_fmt($pending_total)) ?></div>
          </div>
        </div>

        <div class="mt-3">
          <div class="d-flex justify-content-between dash-sub">
            <span>Collection rate</span>
            <span><?= e((string)$collect_pct) ?>%</span>
          </div>
          <div class="progress">
            <div class="progress-bar" role="progressbar" style="width: <?= e((string)$collect_pct) ?>%"></div>
          </div>
        </div>

        <div class="mt-3">
          <h6 class="dash-title mb-2">Ratios</h6>
          <div class="row g-2">
            <div class="col-md-4">
              <div class="dash-kpi-label">Share % of Fee</div>
              <div class="dash-kpi-val"><?= e((string)$share_pct_of_fee) ?>%</div>
            </div>
            <div class="col-md-4">
              <div class="dash-kpi-label">Paid % of Share</div>
              <div class="dash-kpi-val"><?= e((string)$paid_pct_of_sh) ?>%</div>
            </div>
            <div class="col-md-4">
              <div class="dash-kpi-label">Pending % of Share</div>
              <div class="dash-kpi-val"><?= e((string)$pending_pct_of_sh) ?>%</div>
            </div>
          </div>
        </div>

        <div class="mt-4">
          <h6 class="dash-title mb-2">Last month comparison</h6>
          <div class="row g-2">
            <div class="col-6">
              <div class="dash-kpi-label">Fee Δ</div>
              <div class="dash-kpi-val"><span class="<?= e($c1) ?>"><?= e($t1) ?></span></div>
            </div>
            <div class="col-6">
              <div class="dash-kpi-label">Share Δ</div>
              <div class="dash-kpi-val"><span class="<?= e($c2) ?>"><?= e($t2) ?></span></div>
            </div>
            <div class="col-6">
              <div class="dash-kpi-label">Paid Δ</div>
              <div class="dash-kpi-val"><span class="<?= e($c3) ?>"><?= e($t3) ?></span></div>
            </div>
            <div class="col-6">
              <div class="dash-kpi-label">Pending Δ</div>
              <div class="dash-kpi-val"><span class="<?= e($c4) ?>"><?= e($t4) ?></span></div>
            </div>
          </div>
          <div class="dash-sub mt-2">If pending rises, it usually means payment follow up is needed.</div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="dash-table card p-3 h-100">
        <h5 class="dash-title mb-2">Top teachers by share</h5>
        <div class="table-responsive">
          <table class="table table-dark table-hover align-middle mb-0">
            <thead><tr><th>Teacher</th><th class="text-end">Share</th></tr></thead>
            <tbody>
              <?php foreach ($top_share_teachers as $x): ?>
                <tr>
                  <td><?= e((string)$x['name']) ?></td>
                  <td class="text-end"><?= e(money_fmt($x['share_sum'])) ?></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$top_share_teachers): ?><tr><td colspan="2" class="text-center text-secondary">No data</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>

        <h5 class="dash-title mt-4 mb-2">Top students by fee</h5>
        <div class="table-responsive">
          <table class="table table-dark table-hover align-middle mb-0">
            <thead><tr><th>Student</th><th class="text-end">Fee</th></tr></thead>
            <tbody>
              <?php foreach ($top_students_fee as $x): ?>
                <tr>
                  <td><?= e((string)$x['name']) ?></td>
                  <td class="text-end"><?= e(money_fmt($x['fee_sum'])) ?></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$top_students_fee): ?><tr><td colspan="2" class="text-center text-secondary">No data</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>

        <div class="mt-3">
          <a class="btn btn-outline-light w-100"
             href="<?= e(url('reports.php')) ?>?from=<?= e($period_start) ?>&to=<?= e($period_end) ?>">
            Open Reports for this period
          </a>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php if ($tab === 'risks'): ?>
  <div class="row g-3 mb-3">
    <div class="col-lg-6">
      <div class="dash-table card p-3 h-100">
        <h5 class="dash-title mb-2">Highest pending tuitions</h5>
        <div class="table-responsive">
          <table class="table table-dark table-hover align-middle mb-0">
            <thead><tr><th>ID</th><th>Date</th><th>Student</th><th>Teacher</th><th class="text-end">Pending</th><th>Status</th></tr></thead>
            <tbody>
              <?php foreach ($risk_pending_rows as $r): ?>
                <tr>
                  <td><?= e((string)$r['id']) ?></td>
                  <td><?= e((string)$r['tuition_date']) ?></td>
                  <td><?= e((string)$r['student_name']) ?></td>
                  <td><?= e((string)$r['teacher_name']) ?></td>
                  <td class="text-end"><?= e(money_fmt($r['pending_to_company'])) ?></td>
                  <td>
                    <?php $badge = badge_for_status((string)$r['status']); ?>
                    <span class="badge bg-<?= e($badge) ?>"><?= e((string)$r['status']) ?></span>
                  </td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$risk_pending_rows): ?><tr><td colspan="6" class="text-center text-secondary">No pending rows</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
        <div class="dash-sub mt-2">These rows usually need payment follow up or correction.</div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="dash-table card p-3 h-100">
        <h5 class="dash-title mb-2">Top teachers by pending (open in reports)</h5>
        <div class="table-responsive">
          <table class="table table-dark table-hover align-middle mb-0">
            <thead><tr><th>Teacher</th><th class="text-end">Pending</th><th class="text-end">Share %</th><th></th></tr></thead>
            <tbody>
              <?php foreach ($top_pending_teachers as $x): ?>
                <?php
                  $pending = (int)($x['pending_sum'] ?? 0);
                  $sharepct = pct_int($pending, max(1, $share_total));
                ?>
                <tr>
                  <td><?= e((string)$x['name']) ?></td>
                  <td class="text-end"><?= e(money_fmt($pending)) ?></td>
                  <td class="text-end"><?= e((string)$sharepct) ?>%</td>
                  <td class="text-end">
                    <a class="btn btn-sm btn-outline-light"
                       href="<?= e(url('reports.php')) ?>?from=<?= e($period_start) ?>&to=<?= e($period_end) ?>&teacher_id=<?= e((string)$x['id']) ?>">
                      View
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$top_pending_teachers): ?><tr><td colspan="4" class="text-center text-secondary">No data</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>

        <div class="dash-sub mt-2">
          If one teacher has high pending, check fee collection and update paid amounts.
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php if ($tab === 'health'): ?>
  <div class="row g-3 mb-3">
    <div class="col-lg-6">
      <div class="dash-card p-3 h-100">
        <h5 class="dash-title mb-2">Health summary</h5>
        <div class="row g-2">
          <div class="col-6">
            <div class="dash-kpi-label">Teachers missing docs</div>
            <div class="dash-kpi-val"><?= e((string)$teachers_missing_docs) ?></div>
          </div>
          <div class="col-6">
            <div class="dash-kpi-label">Teachers missing phone</div>
            <div class="dash-kpi-val"><?= e((string)$teachers_missing_phone) ?></div>
          </div>
          <div class="col-6">
            <div class="dash-kpi-label">Students missing phone</div>
            <div class="dash-kpi-val"><?= e((string)$students_missing_phone) ?></div>
          </div>
          <div class="col-6">
            <div class="dash-kpi-label">Students missing location link</div>
            <div class="dash-kpi-val"><?= e((string)$students_missing_location_link) ?></div>
          </div>
        </div>

        <div class="dash-sub mt-3">
          Cleaner data means fewer errors and more reliable reports.
        </div>

        <div class="d-grid d-sm-flex gap-2 mt-3">
          <a class="btn btn-outline-light flex-fill" href="<?= e(url('teachers.php')) ?>">Fix teachers</a>
          <a class="btn btn-outline-light flex-fill" href="<?= e(url('students.php')) ?>">Fix students</a>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="dash-table card p-3 h-100">
        <h5 class="dash-title mb-2">Teachers missing docs (recent)</h5>
        <div class="table-responsive">
          <table class="table table-dark table-hover align-middle mb-0">
            <thead><tr><th>ID</th><th>Reg</th><th>Name</th><th>City</th><th>ID File</th><th>Doc File</th></tr></thead>
            <tbody>
              <?php foreach ($teachers_missing_docs_list as $t): ?>
                <tr>
                  <td><?= e((string)$t['id']) ?></td>
                  <td><?= e((string)($t['reg_no'] ?? '')) ?></td>
                  <td><?= e((string)$t['name']) ?></td>
                  <td><?= e((string)($t['city'] ?? '')) ?></td>
                  <td><?= ($t['teacher_id_file'] ? '<span class="badge bg-success">OK</span>' : '<span class="badge bg-secondary">Missing</span>') ?></td>
                  <td><?= ($t['teacher_doc_file'] ? '<span class="badge bg-success">OK</span>' : '<span class="badge bg-secondary">Missing</span>') ?></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$teachers_missing_docs_list): ?><tr><td colspan="6" class="text-center text-secondary">No missing docs</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>

        <div class="mt-3">
          <a class="btn btn-outline-light w-100" href="<?= e(url('teachers.php')) ?>">
            Open Teachers to upload missing files
          </a>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php if ($tab === 'activity'): ?>
  <div class="dash-table card p-3 mb-3">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <h5 class="mb-0 dash-title">Recent tuitions</h5>
      <a class="btn btn-sm btn-outline-light" href="<?= e(url('tuitions.php')) ?>">Open</a>
    </div>

    <div class="table-responsive">
      <table class="table table-dark table-hover align-middle mb-0">
        <thead>
          <tr>
            <th>ID</th>
            <th>Date</th>
            <th>Student</th>
            <th>Teacher</th>
            <th class="text-end">Fee</th>
            <th class="text-end">Company</th>
            <th class="text-end">Paid</th>
            <th class="text-end">Pending</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($recent_tuitions as $r): ?>
            <tr>
              <td><?= e((string)$r['id']) ?></td>
              <td><?= e((string)$r['tuition_date']) ?></td>
              <td><?= e((string)$r['student_name']) ?></td>
              <td><?= e((string)$r['teacher_name']) ?></td>
              <td class="text-end"><?= e(money_fmt($r['monthly_fee'])) ?></td>
              <td class="text-end"><?= e(money_fmt($r['company_share_amount'])) ?></td>
              <td class="text-end"><?= e(money_fmt($r['paid_to_company'])) ?></td>
              <td class="text-end"><?= e(money_fmt($r['pending_to_company'])) ?></td>
              <td>
                <?php $badge = badge_for_status((string)$r['status']); ?>
                <span class="badge bg-<?= e($badge) ?>"><?= e((string)$r['status']) ?></span>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$recent_tuitions): ?>
            <tr><td colspan="9" class="text-center text-secondary">No recent tuitions</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="dash-table card p-3">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <h5 class="mb-0 dash-title">Recent activity log</h5>
      <span class="dash-sub">Shows who changed what</span>
    </div>

    <div class="table-responsive">
      <table class="table table-dark table-hover align-middle mb-0">
        <thead>
          <tr>
            <th>When</th>
            <th>Time</th>
            <th>User</th>
            <th>Action</th>
            <th>Entity</th>
            <th>ID</th>
            <th>Details</th>
            <th>IP</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($recent_logs as $x): ?>
            <tr>
              <td><?= e(human_when($x['created_at'])) ?></td>
              <td><?= e((string)$x['created_at']) ?></td>
              <td><?= e((string)($x['user_name'] ?? 'Unknown')) ?></td>
              <td><?= e((string)$x['action']) ?></td>
              <td><?= e((string)$x['entity']) ?></td>
              <td><?= e((string)$x['entity_id']) ?></td>
              <td><?= e((string)($x['details'] ?? '')) ?></td>
              <td><?= e((string)($x['ip'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$recent_logs): ?>
            <tr><td colspan="8" class="text-center text-secondary">No activity yet</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endif; ?>

<?php require __DIR__ . '/_layout_bottom.php'; ?>
